// src/mobile-design/live.mjs
async function startLive(host, source, helper, signal, onEvent) {
  let child, buffer = "", resolve, reject, readyDone = false, stopped = false, queue = Promise.resolve();
  const ready = new Promise((yes, no) => {
    resolve = yes;
    reject = no;
  });
  ready.catch(() => {
  });
  const stop = () => {
    if (stopped) return;
    stopped = true;
    reject(Error("Preview closed"));
    if (child) void child.kill().catch(() => {
    });
  };
  signal.addEventListener("abort", stop, { once: true });
  const timer = setTimeout(() => {
    reject(Error("Preview startup timed out"));
    stop();
  }, 2e4);
  try {
    signal.throwIfAborted();
    child = await host.spawn("preview", { onStdout(data) {
      buffer += data;
      if (buffer.length > 256e3) {
        stop();
        return;
      }
      let end;
      while ((end = buffer.indexOf("\n")) >= 0) {
        const line = buffer.slice(0, end);
        buffer = buffer.slice(end + 1);
        try {
          const event = JSON.parse(line);
          if (!readyDone) {
            if (!/^http:\/\/127\.0\.0\.1:\d{1,5}\/[A-Za-z0-9_-]{43}\/$/.test(event.url)) throw Error("Invalid preview URL");
            readyDone = true;
            resolve(event.url);
          } else onEvent(event);
        } catch (error) {
          if (!readyDone) reject(error);
        }
      }
    } });
    signal.throwIfAborted();
    child.exited.then(() => reject(Error("Preview process stopped")));
    await child.write(JSON.stringify(source) + "\n");
    await child.write(JSON.stringify({ helper }) + "\n");
    const url = await ready;
    const write = (message) => {
      queue = queue.then(async () => {
        signal.throwIfAborted();
        const line = JSON.stringify(message) + "\n";
        for (let i = 0; i < line.length; i += 65536) {
          signal.throwIfAborted();
          await child.write(line.slice(i, i + 65536));
        }
      });
      return queue;
    };
    return { url, close: stop, exited: child.exited, control: (action, value) => write({ type: "control", action, value }), update: (html, source2) => write({ type: "document", html, source: source2 }), marks: (notes) => write({ type: "marks", notes }), ack: (id, error) => write({ type: "note-status", id, error }) };
  } catch (error) {
    stop();
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

// src/mobile-design/annotations.mjs
function validateNote(note) {
  if (!note || typeof note.id !== "string" || note.id.length > 80 || typeof note.page !== "string" || note.page.length > 120 || typeof note.selector !== "string" || note.selector.length > 500 || typeof note.comment !== "string" || note.comment.length > 2e3 || !note.comment.trim() || !Array.isArray(note.rect) || note.rect.length !== 4 || note.rect.some((n) => !Number.isFinite(n) || n < 0 || n > 1) || note.rect[2] <= 0 || note.rect[3] <= 0 || note.rect[0] + note.rect[2] > 1.001 || note.rect[1] + note.rect[3] > 1.001 || typeof note.revision !== "string" || !/^[a-f0-9]{64}$/.test(note.revision)) throw Error("Invalid design annotation");
  return { id: note.id, page: note.page, selector: note.selector, comment: note.comment.trim(), rect: note.rect.map((n) => Math.round(n * 1e4) / 1e4), revision: note.revision, label: String(note.label || "Selected area").slice(0, 160), source: note.source && typeof note.source.url === "string" && /^https:\/\//.test(note.source.url) ? { url: note.source.url.slice(0, 2048), message: String(note.source.message || "").slice(0, 64) } : null };
}
function formatNotes(notes, source) {
  if (!notes.length || notes.length > 50) throw Error("Select between 1 and 50 notes");
  return ["Please apply these design changes. Preserve the remaining flow and the agreed Ayo reference mappings.", `Source: ${source?.url || "Local imported HTML"}`, `Source message: ${source?.message || "local"}`, "Coordinates are fractions of the selected phone screen or reference image (x, y, width, height). Each note includes its original document SHA-256; check the current page before applying it.", "", ...notes.map((raw, i) => {
    const n = validateNote(raw);
    return `${i + 1}. Page: ${n.page}
   Element: ${n.selector}
   Area: [${n.rect.join(", ")}]
   Label: ${n.label}
   Source: ${n.source?.url || source?.url || "local HTML"}
   Source message: ${n.source?.message || source?.message || "local"}
   Document: ${n.revision}
   Change: ${n.comment}`;
  })].join("\n");
}
function appendToComposer(editors, connection, channel, text) {
  const matches = [...editors.values()].filter((e) => e.scope === connection.scope && e.session.viewer === connection.session.viewer && e.channelId === channel && !e.threadRootId && !e.disabled);
  if (matches.length !== 1 || matches[0].insertText("\n" + text + "\n") !== true) throw Error("Open the bound execution chat to add this note to its draft");
  return true;
}
async function submitNotes(session, channel, prompt, check) {
  check();
  if (typeof session.messages?.send !== "function") throw Error("Message sending is unavailable");
  const id = await session.messages.send(channel, prompt);
  check();
  if (typeof id !== "string" || !/^[a-f0-9]{64}$/.test(id)) throw Error("Submission was not confirmed. Check the chat before trying again.");
  return id;
}

// src/mobile-design/binding.mjs
var key = (value) => typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
var COLLECTION = { name: "mobile-design-workspace", type: "opcb.mobile-design.workspace", version: 1, project: () => [] };
var PREFERENCE = "execution-binding";
var MAPPINGS = Object.freeze([
  { reference: "Social feed", target: "Home", page: "home" },
  { reference: "Conversation & status", target: "OPCB Agent chat", page: "agent_chat" },
  { reference: "People discovery", target: "Create with your photo", page: "ready" },
  { reference: "Profile", target: "Save & publish", page: "detail" },
  { reference: "Live / route result", target: "Invite", page: "invite" }
]);
function canRead(channel, viewer) {
  return !!viewer && !!channel && !channel.archived && !channel.cached && !channel.pending && !channel.metadataPending && !channel.metadataCached && Array.isArray(channel.members) && channel.members.includes(viewer);
}
function canBind(channel, viewer) {
  return canRead(channel, viewer) && !channel.readOnly;
}
function validateBinding(value, viewer) {
  if (value == null) return null;
  if (value.schema !== 1 || value.owner !== viewer || !Number.isInteger(value.revision) || value.revision < 1 || typeof value.channel !== "string" || !value.channel || typeof value.label !== "string" || value.label.length > 100 || value.source && (!key(value.source.message) || typeof value.source.url !== "string" || !isHtml(value.source))) throw Error("\u6267\u884C\u4F1A\u8BDD\u8BB0\u5F55\u65E0\u6548\uFF0C\u8BF7\u91CD\u65B0\u7ED1\u5B9A");
  return value;
}
function isHtml(file) {
  return typeof file?.url === "string" && /^https:\/\//.test(file.url) && (/\.html?(?:[?#]|$)/i.test(file.url) || /\.html?$/i.test(file.name || "") || /^text\/html(?:;|$)/i.test(file.mime || ""));
}
function chooseSource(row, url) {
  const candidates = (row.attachments || []).filter(isHtml);
  for (const match of String(row.content || "").matchAll(/https:\/\/[^\s<>"'()]+\.html?(?:\?[^\s<>"'()]*)?/g)) {
    if (!candidates.some((c) => c.url === match[0])) candidates.push({ url: match[0], name: "\u8BBE\u8BA1\u8BA1\u5212\u4E0E\u6210\u679C.html", mime: "text/html" });
  }
  const found = url ? candidates.find((f) => f.url === url) : candidates.length === 1 ? candidates[0] : null;
  if (!found) throw Error("\u8BF7\u6307\u5B9A\u5F53\u524D\u4F1A\u8BDD\u539F\u6D88\u606F\u4E2D\u7684HTML\u9644\u4EF6");
  if (found.size && found.size > 50 * 1024 * 1024) throw Error("HTML\u9644\u4EF6\u8D85\u8FC750MB");
  const parsed = new URL(found.url);
  if (parsed.username || parsed.password) throw Error("\u9644\u4EF6URL\u4E0D\u53EF\u5305\u542B\u51ED\u636E");
  return { message: row.id, url: found.url, name: found.name || "\u8BBE\u8BA1\u8BA1\u5212\u4E0E\u6210\u679C.html", mime: found.mime || "text/html" };
}
async function exactMessage(session, client, channel, id, check) {
  if (!key(id) || typeof client.effectiveEdit !== "function" || typeof session.thread !== "function") throw Error("\u9700\u8981\u539F\u59CB\u6D88\u606F\u53CA\u5BBF\u4E3B\u8BFB\u53D6\u80FD\u529B");
  check();
  await client.effectiveEdit(id, channel);
  check();
  const thread = session.thread(channel, id, { exact: true });
  try {
    await thread.refresh();
    check();
    const s = thread.snapshot(), row = s.target;
    if (s.targetStatus !== "ready" || row?.id !== id || row.channelId !== channel || row.edited || row.delivery && !["accepted", "seen"].includes(row.delivery)) throw Error("\u539F\u6D88\u606F\u5DF2\u53D8\u5316\u6216\u65E0\u6743\u8BFB\u53D6");
    return row;
  } finally {
    thread.dispose();
  }
}
function agentContext(ctx, client, context) {
  const relay = ctx.agents.relay(client.key), connection = relay?.snapshot(), owner = ctx.relay.snapshot();
  const check = () => {
    client.signal?.throwIfAborted();
    const now = relay?.snapshot(), human = ctx.relay.snapshot();
    if (!client.signal || connection?.status !== "ready" || connection.cached || owner.status !== "ready" || owner.cached || now?.session !== connection.session || now.scope !== connection.scope || now.generation !== connection.generation || human.session !== owner.session || human.generation !== owner.generation || human.scope !== connection.scope || human.session.viewer !== client.owner || connection.session.viewer !== client.owner) throw Error("\u5F53\u524D\u8EAB\u4EFD\u6216\u793E\u533A\u5DF2\u53D8\u5316");
    for (const session of [connection.session, human.session]) {
      const list = session.channels.list(), channel = list.channels.find((c) => c.id === context.channel);
      if (list.status !== "ready" || !canBind(channel, client.owner) || !channel.members.includes(client.pubkey)) throw Error("\u53EA\u80FD\u7ED1\u5B9A\u672C\u4EBA\u548C\u672CAgent\u5747\u53EF\u8BBF\u95EE\u7684\u5F53\u524D\u6267\u884C\u4F1A\u8BDD");
    }
  };
  check();
  return { connection, check };
}
async function bindFromAgent(ctx, client, context, args) {
  const { connection, check } = agentContext(ctx, client, context);
  const request = await exactMessage(connection.session, client, context.channel, args.request_id, check);
  if (request.authorId !== client.owner || !/绑定|执行会话/.test(request.content || "")) throw Error("\u7ED1\u5B9A\u9700\u672C\u4EBA\u660E\u786E\u8981\u6C42\u6267\u884C\u4F1A\u8BDD\u7684\u539F\u59CB\u6307\u4EE4");
  const row = await exactMessage(connection.session, client, context.channel, args.source_message_id, check);
  if (![client.owner, client.pubkey].includes(row.authorId)) throw Error("HTML\u9700\u6765\u81EA\u672C\u4EBA\u6216\u5F53\u524D\u6267\u884CAgent");
  const source = chooseSource(row, args.attachment_url);
  check();
  const collection = ctx.artifactStorage.open(COLLECTION);
  try {
    const old = validateBinding(await collection.preferences.get(PREFERENCE), client.owner);
    check();
    if (old?.request === args.request_id && old.channel === context.channel && old.source?.message === source.message && old.source.url === source.url) return old;
    if ((old?.revision || 0) !== args.expected_revision) throw Error("\u7ED1\u5B9A\u8F6E\u6B21\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u8BFB\u53D6");
    const binding = { schema: 1, revision: args.expected_revision + 1, owner: client.owner, channel: context.channel, label: args.label || "\u6267\u884C\u4F1A\u8BDD", source, request: args.request_id };
    if (binding.label.length > 100) throw Error("\u4F1A\u8BDD\u540D\u79F0\u8FC7\u957F");
    await collection.preferences.update(PREFERENCE, (current) => {
      check();
      if ((current?.revision || 0) !== args.expected_revision) throw Error("\u7ED1\u5B9A\u5DF2\u88AB\u5176\u4ED6\u64CD\u4F5C\u4FEE\u6539");
      return binding;
    });
    check();
    const saved = validateBinding(await collection.preferences.get(PREFERENCE), client.owner);
    check();
    if (saved?.revision !== binding.revision || saved.channel !== binding.channel || saved.source?.message !== binding.source.message) throw Error("\u7ED1\u5B9A\u4FDD\u5B58\u672A\u786E\u8BA4\uFF0C\u8BF7\u56DE\u8BFB\u72B6\u6001");
    return saved;
  } finally {
    collection.close();
  }
}
async function readAttachment(connection, binding, check) {
  check();
  const source = binding?.source;
  if (!source) throw Error("\u5C1A\u672A\u5173\u8054HTML\u6210\u679C");
  const thread = connection.session.thread(binding.channel, source.message, { exact: true });
  try {
    await thread.refresh();
    check();
    const s = thread.snapshot(), row = s.target;
    if (s.targetStatus !== "ready" || row?.id !== source.message || row.channelId !== binding.channel || row.edited) throw Error("HTML\u6765\u6E90\u5DF2\u53D8\u5316\u6216\u65E0\u6743\u8BFB\u53D6");
    chooseSource(row, source.url);
    return connection.session.media(source.url);
  } finally {
    thread.dispose();
  }
}

// plugins/opcb.html-reader/0.1.0-rc.2/source/reader.mjs
var MAX_BYTES = 50 * 1024 * 1024;
async function readSource(source, signal, request = fetch) {
  const response = await request(source, { signal, redirect: "error" });
  if (!response.ok) throw new Error(response.status === 401 || response.status === 403 ? "\u65E0\u6743\u8BFB\u53D6\u6B64 HTML\uFF0C\u8BF7\u786E\u8BA4\u539F\u804A\u5929\u4E0E\u767B\u5F55\u72B6\u6001" : `\u8BFB\u53D6\u5931\u8D25\uFF08${response.status}\uFF09`);
  if (Number(response.headers.get("content-length")) > MAX_BYTES) throw new Error("HTML \u6587\u4EF6\u8D85\u8FC7 50 MB");
  const reader = response.body?.getReader();
  if (!reader) throw new Error("\u5F53\u524D\u5BA2\u6237\u7AEF\u4E0D\u652F\u6301\u8BFB\u53D6\u9644\u4EF6\u5185\u5BB9");
  const decoder = new TextDecoder("utf-8", { fatal: true });
  const parts = [];
  let length = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      length += value.byteLength;
      if (length > MAX_BYTES) throw new Error("HTML \u6587\u4EF6\u8D85\u8FC7 50 MB");
      parts.push(decoder.decode(value, { stream: true }));
    }
    parts.push(decoder.decode());
  } finally {
    await reader.cancel().catch(() => {
    });
  }
  if (!length) throw new Error("HTML \u6587\u4EF6\u4E3A\u7A7A");
  return { html: parts.join(""), size: length };
}

// src/mobile-design/phone-icon.mjs
var PHONE_ICON = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAfQAAAH0CAYAAADL1t+KAAEAAElEQVR4nOz9ebAlWXofhv2+k3nvfWtVdVdX9V49vfdUr4OZwUADDLoGswIkIZJCtU2ZQYYsUrYsk6aDYnCzWV0OhShFEAQgEJAA0bREm1REly0qTDtEE6bRbZGWhNln0D2YGQAz3bV1ra/edpfMPOfzH2fJc07mve+9Wt67973z66i+9+aeJ/Od37d/QEJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQsLtg/b6AhJ2FQQAHC/QYCQkJCQkzCwSoe9TnAHEqddfFzh1CtdefJFPnz6tKMs44G2G9wYQCICSkgDQuXPn6DSAt999N3xH3gauHX/PHeTdkycZZ4E3cZZRHy4JBwkJCQm7jETo+wgM0Nuvv56devttSUStpHoS6J4A6FkAawB9BVDvARUAdUcnJ/M/IrARCnDuHAUCwdu1MHD65El+MwkCCQkJCXcNidD3Ac4A4sXTp+mN/+s5aSnxN9B7+r6XP/Gppaef/LHu8WPP5IeXH8znF5aoky1QlhGYNekyS4AKVZUlyqpQUo6geEMVRV8Vow0uqw0uyg1VletyMFqVw9EqbQ5vVetra9XGcL24fn1jcPP8xiaG/T8E+r8EDHZ08U4QAFiqpiDwtv7ftePH+fTJk/wmgDfPJiEgISEhIUYi9BkGA3Tu9GnxxrlzEgB+EXj08Wc+9QuLr7zwC4c++uwnjp18fm7hkYcgFuaghACDIZUCGGBmdxQy5nYwg4ggAEAxiBlQCqwUUEmoqoIsSsiyRDUcohgMUY5GiotipMpqwGW1LofDDVUUa1wUt+SwvMXFaIWHxU056K/wYLBSrA9X1ObmTbmysrr5o8trA1xZ/z1gc+eCgH51We1YCEgCQEJCwr5EIvQZxVtA9gYgAeDXsfz8/c9+9H9z/098/H/62KlP37fwwrOQc11UZSVlf8DVaEiqrLR/XDEMowOwxE7uTSAiBmnTuQAYggASIEEgEoAgIiFAQhCISAhBQggIISCIIEgLBwIAKQakAssKXFZQowLVaIRiOMSo34ccjkaqKPpqVGygKFblcLQmi3IFw+FNORrdVMPRDfSH14t+/2a1sX6zuLWyUly6utpfv7h2C9j4K1oI2L6rgJwlQJw7d46OBe4ALQAA1h1wFm8CnKwACQkJs4JE6DOIt3A6ewPn5H+Mo8uPPPDAXz/8iVf/4tO/8McWe6+8AM6yqlzfoHJjU6iyJLYaNrMmb+VzE7dTFbPTgN0G4yiNwOZ/RhgAhBAMIpD9zASIhP7MMoIQRERCZAIZecIACAJsBAEJVZZQRQk5HKEcDjDq91EOBhWX5aYaFhtqOFpTZXGLh6MVNRreUMPRDTkc3eDh4Hqx0b8hN9Zu8M3Vlc1rH65urF5duwRsnAWG2x7oiVaAt3Hq+HE+ByMA4CzePJsEgISEhL1DIvQZg9XMf/3Ik585ct/9/9mTf/xnTx75+S8iP7xcFSu3smowJFWWYKnASoKZwVLBkbdnatfqasQ98e8dog6cD0LoG2thr4gAQYJ1PJ1gCAESxCScAAAIQWT+ZVlmLALaGpBBgMAgqQApwVUJNSpRjYYoB1oIqIajgkfDDVWU66oYrfKoWJGD4U0uihtqNLxWDdZv8GB0XW0Orstbt1aKldWV4fs/WO0D638O2MQOrQCtAgDexqn3kgCQkJBw75AIfYZgNfPfuO+Zf/fwA/f/J0/+2/9mfuTzn6nUYJhVG5skiwKqqqCkNL5vrjVzZqtHG/pg+wHrRwchoBZGTf4EMlzfwj2+EOC+U/u28a4AqP6f59vXCrI9JVnZg8Dka/9EDEEQWc4QBC0IZM4SIIQQIhMQIkMmCJl1C0gFUlLHBpQF5KhANRyg6A9QDAZKFaO+Go3WeVSscTFckUVxUxXDG6o/vIaiuIbh8Lrc3Lw+XF+/Wd68uYKr79+6tTJc/5G2AlRb3rh3k9sRAPDmWfY8I0kASEhIaCAR+ozgDJCfBar/9P5n/taxo/efffDP/5t87NRPstrYFNVwBFkUqDVzpQkd0CxoSdKa0pV2kzuzumIwK/PJoRbv87N7XfRxyGMYvY1HN47PQ8HBXYcFh18CpvK38+UDGrsoOhbVBKhN/wwQSOg4AZFlrMlfAFlGQlsDRJYJ0gKAcQeAIRgQrICqAlcVVDFCNRyhGPQx6m+Ci7KvitGGGg3XuBiuqLK4oUbVDS7613gwvKpGw+sohtfk+sYNuXZzRV5+/9b5i4P1fwxsvnMbAsC5c+fEMY/8AeDaeykIMCHhICMR+gzAkvmvHn3mrx7vzf9HD/yZX6ge/vkvZjwYUjUcQRkyV0rpIDRWoXm9xYxOILDUkesiExC9HrJeD6LTgejkWtOFOYxiQEmwlGYfCVYKqqq0mVspJ0hogUB53G3JHzXhN37Dkx3qa24IJBYckz83yN2FAbQKBd41NQfGHFAHBpIQbAMFRW4FgNzFA5DISAgSIrMCgLECwBMAyhKqLCFHQxTDgREARn1VFetcjFbVaHQLZXFDFcV1LobXUAyuqtHwmhwMrmFz/fpwuLpS/ejCrc77/fUvAX1sm6QJzLH2/zYAjNP+E/knJMwwEqFPOU4D2TlA/tLxp//4/Sr7J0c+86nqI//un83yPCc5HKIaFVBFqcnWpJkBbLy+fkCb+U4ElgpKVsiXlrD48IOYf+AoOkuLEN0uSIiQaH0/u2e+1755CUgFJaXWWssKLCsdyFYU4LKCHI20sGEC3FRZQlU66p2VrH39LljPELk2p4NEZi4hJvY4oM//ze6enVDgQfO8IXVmjOOxWkjgYDhidwJZAUAH/jMJHQsgsoxhLAAi7+jMgEwIkWWUCYEsy3QcABEEAUJJQFZAVUGVBcrREOWgj9FooLgsNrkYraMsVlQxWkFVXEdVXJPl8BqK4VVVDK6qweC67N+6zqurK6M/eH/t/QtY/18AZevNtd4wgf/W3xJ48cWQ/F88zufO6aqAbybyT0iYWiRCn2KcAcSbAP/H9z/z6GGobx46duz+J/7Sn+f7Tj4nZH9gyLwwmrPWzCkIfIOn6eocLFlVEHM9HHnmKRx67FGIbhc2El5r2Dpmvd2UjQbZk/lNVqM1n24bS6wMLWwYzd4KAJr4S038I+vLHkKNtEm7XF+v1W1mz5zPHn+3afCedYI1tTfuxRMS7NHI0/4J3vnqnerbDwSlaJjGCQnEYJAhRe0GICJGJkBZri0AWhjQcQBZJrI8JyEEskwgEwIZAYIZAiYQUJZQxQjlaIDRYABZDEeoinVVFmuQxU1VDq+zLK9zMbrCZf8aZHmFi+Ial+vXeWP9RnX5vdWNf4m1nwNGrRfdvAswKzp37g1x7N2Ttc/fEH/S+hMS9gb5Xl9Awni8aDzev8TVLy1l3aMLr56slj7yeC4HI8hSm3JZanM3rA8cNdmwJVIwmAhlWaB73314+MdeRW95GbLQeeGw+xgzdE19XJNzDHtck9e+VRi487cTgfIc1O0iA9ARwggB9ZbwLA2blz7E1f/f/+il27HH1xySqlmn798j6nG+fF+rD7b3vxNADGLvWFSPq923Vtzb3QH2woxlgPS1GlsExQGE7AQlMANCB/5p07/QaYGCQLkRALQQQJT1iA4tiDzLelmW9bJMPJAJ8VQmjPlfVoCqoKoSshigGA1RjAYVyT+yfvjnq9VvlMUKydE1xcU1lMUVlsUVLodXRTm8gmJwvVq9fqO6/oNb3/nnvE5EJUwdhFactZfPhvivuid87cXjfPrdRPoJCXcbSUOfUtj0tL99+MTP3Jd1/kVnaUk+8W/9T7LjP/nj2mc+KiCL0pmt2/zlbEhIEVCVJbpHjuDRT30CebcLWZaONFxxGf2r5WpCjdsqyz7X29OO4/8GIq05Pqu9NtHt4sO3/zv0z1+E6HR0fIDbgb3bjci9LX4gSNlD+/b+cbz1bEk7WD7uOBz666Pj10MUXo+1jJCTShDuYxMRzDm8kASz0j0EkwHAJg0w5zoAMANIEOUZKMu0+T8TyLNMWwAIyIhBrMCqAssSVTlCMRqiLIYFqnKdZbECObwBJa+AyytcFh9CjT5kOfyQh6MrxeDmNaxdv5H9ny+tfWIbJv8zZ86IN198j942pH/tveN8+q1zityAJyQkbAdJQ59SvGt0QSL+D3IQOvcfRu/4MXAlwVUdmAbFTfJiTXTKaM6VUhC9Lo6/8iLyTseRuZ8iNnne9ImLnADgB7w5i3hE7A2LtYUxOXs/m2c1B5w7fgz9Dy7AkmmtRfvRdOMI2B0MtZneas0I/fMN8g/HhxvnaVoIgmthS9Th9hwdtzbzM+q10TMlINzTs0oQeSZ+o/WDwbair1OB7bE8i4IxP+jIfwHKMhZCaN+/yIAsI8pyIjFH2cJiN8+zo1mWHc0EnskEQRCDoMCyhKwKFNr0X0GO1vgT1c3fldU1qPJDVKPLxOVFVVXnodYvoNz8cNRfubb+d79/67Nnz1ZnEcE8vLfeOp0de/cqnXrxOOP0OUXjfBkJCQmJ0KcRVjs/s/zIH52n7F8bEcu5uV7GYMiyBFc6oMwFqQFWHYclHgWGYoYkQFUVjjzzNLrLyzoyHYjI3GKsvhwts7/JkGQjxlwvqzcxOeV6wXaVeALASqF39H5Qlmkfv728mHDdvdfCR0Ccdnu7nV2uAB2VH99zm8bP9SmtFt3Q+mOiD60I5IQRuP3Z3w/+tvY6WFegMee0nOb8/tDP21do2dPgncXAv06jzbtgf4/8pb3OwAIAlGAm4UX+i0wLAob8SeQEIUTWXc6z7Mj9eUb353n2jBCEDApgCaUqlMUQw9FAZbJcXfzVn77+XVldYpQ/RFX8oZKjP+Ri/YfZYO2HH/0Pv/YhvXEuMOsznxE49x4lck9IaCIR+hTiXTN1nyH+39kJXxUlytU1qAcfAFd1EJvTPLnWOtkQmwJDSoXu8jLmHzyuA6i2PHvbFp42bL8HHO/tYzRvpxGyIXiug+WYPR/xJOhWrOgePoR8aRHl6pomduaQf9tI1b+2hhZdr6997HX0QCg0RLfoCVDW/O377K1QoZf5kQW15SA2y1P94PQ+ZMcMhngZZLMWIiuDX/yH4R/L19xt5oAVAMLfAMBUWzSI9GOzHXjZC3+ABFhWdYK/2c/07gMASHNxRGASgpmEFgK0+Z8oE0TZvMi7S/fleXZfLvBsnuF1goJSJUbDIYrRYP17v/bS+d+TxfdIDb8K1f+dcvX814nO3nTX/Nbp7M13z/HZs3fY+jchYZ8gEfqUwWrnw+UH/8gy06cGrNQCkMnBEMWNFchRCUFUV4FT9Vzma90MQFmT9YPHAEHbINJJdM8Tf3oXEWnszcNQ5Bz17QLx1TEzRK+H3rGjKG6uaB8wfF+y2TMgbe97RO6WI60fWngCEaD91/bqiOsrZB0VF54hipAPrB6epcC/JmdeZ3Z8ak35dfl8/9q5dgsEWvgY87u5QStkWDO+H5jnj40l63qd0e6dhUU/FROb74QA/S55gpG1HBh93wgWxMpa9o2g6aQGcAWABBiUMQnS/n7KCZkQeWdxuds5dLKb4aRA9SdGxQDoHr36g1994V+iGrx149aN/5beOLcGJGJPSLBIhD5lsNr5X2P8De0DZ2Yw5GiE4tYqZFGAut26qhsQapIGinWr1HxuDjQ/D1mWwNzcXbrKSCNuXR9p9B4bMpOnSRqKopDMQx5kLDz8MDa+/weO5Px7D8rFIiQ/5/d2HzaXXp/zVt6FvO8BULcLaVLpICVIVhBVCaEUhJIQskJmvysJwcp0lJNOCKgL2cRecjjN2r9SxVzvE5OtN15+rnzD/x4sq4USra3Xgg77VgC7nRVSqBbByMXWGUuBrMBSggTpZyS06u0C8QBAOB73xpqN5ARnBXHXo29aH0IxAcplS1jrRAHiUoA3Sei8fhKi21k+Pt9d/pOQgz95NF/40fd/+dg/6vDG36c3zv0I0MSON84pQjBICQkHBonQpwhWOy8PPfyljuJPD1ipRc4yxQxVVihX1yGHQ+SdDlxgWKgywhlUCZr08wySFaQpPLMtU/ddQTynhlq771f29c7A5G01xkpi7sHjyJeWUG1uAraKnSM6T1iw/2f/e6TBM6Cg8L1bm7h6+DheOfEUut0OyrJEVUlIpSBN1Ttl8/NtfXypCR+VBMkSVJWgqkImJYSqkJWlIf8KmZJ6OVfIWIFYmU99TX4gGxOBDcmLQFP3/OfQz49YpylaWlROoPCJ3bg5rIbua9dmWy1D1IKCJWX3XZYQC4vIlu8DqhJcjcDlCJAlWJaAqsBs6h846UOTPgtTk0AI/bzca0fwLiJ8Lt61EymCIgIpl7I4KsGjgVAkCL3u8kcWFxb/5ma/+xe+/8s/+1/0y41fpjfO/RDQxB773hMSDgISoU8RTGQ7JKu/aZUbG6nOUqJaW0e1OUB3acljxFoLqn25DBJCVxrbFJhXrLVPpSCE2IM7s9caa+3eejPB1yl0loQJrCTyhXksPfkEbn79WxBzvUCYqRVRbh6zhdCJgLWixG996130HlzFoUOHsbS0BGYFKbWNmEwTF93Ypf5HnR6oa+IBbH91EEpzPsXKK5WrACWNAKCJX1Sl/lcWyGWBrCzQqQp0ZIFeNUIPjJKFCT43Y6W05kqsC8mUeRcq6wKqQqcq0BVARQSlGMIza1v/uTV3kzcGbKwDmufZmfWV9furCtmhIzj8R/8tLDz4sC5hKytwVYDLAjwagIshVDGCGqyDR32o4SbUcB08GoJHm+Cir4WAYghWFVAVAEv9VhMDZFR7IXSpYSFgBt8j/OD6CZAZJGM0LNVoRCrLFg4dWlz4i2LY+TM/+JUv/cqNmyt/l944t8Z8RgBnOQXOJRwkJEKfEljt/K8ffuRzQsrPDFipDlHGxqQspUS10Yfs9xsR6nVgl12gNbnBzVuQgwGOwBB6a2T7biLWxCJf+7jrI4IqSxz+6HPY+IM/RLmxCcpzBEFnvrWCfDK3H0bwYUav28GlKxfx/vsfoNsfYTAY4P77jyLPc6MhkyZvW50ty5BlGfIsR55n9e88Q57nZp3J485yZJmu9JaZLm+Ud4C5eX0fRFCso9KZGUpK/WxGI5S3VnD46nk8nY0gEaUVViXWsh76jz+PzqNPQGU5Bhub2PjwMnrXLuAjah3zGaOQrgy9072NGxyBPx21EOjXA6hKiVFZAVWJ5U9+CqPOHHqjIUTeAfIOqNODWCCAhDa/w2jh7vGyZ8kwAkAxBJfDmvj7a1CjDaj+Gni4boSADXAxAFdDrf2zVrBJCLBNoROizixgFmAlpJK8IoXMs4UjywvzZ4g6f+q9X/r8Xyc6+18DOu3tjaStJxwQJEKfEjjtXKq/IYxSoif+evKX/T7K9Q2wUrXJ2dM+AzpUCsOVFRQbHbBiqErqtqqdzu7fnIPz1KLW1FtWt5jrWUpk83N44F/7FC7/83+h/dwkdFCgU/Y9u3sU+V4HoGnCLq5fhypLzHV7uHjxPG7duoWjDxxDp9N142qDCu3YumI3prqdEGQ0d92YJcsyQ+QhwWshIDcCgFmXZ8iE3l4YoioXlvE7dAgXr36AUw8uYGRN4kriciVw8YGP4KnnX8VCr4OqLCG6cxhQht8vCN+5+D5+Ml/Ho/PASAHCc2TYISWy9+LnIVg/PlwoezkYYO6pj4LvO45idQVyfg5C2QA75T0dX5D0rC4EEAmtgffmIeYWAdJla8kKAO7dVeCq1MQ/6muC769CbdyA3LgOtXZVf/ZXwCPdmp46PUB0jOCmCKzyqmJe2SQ511l8bjHP/2/f/+Uv/cO1leFf/sQb567/9pnX88+efWf7He0SEmYUidCnAE47X3r4MwT1M0Mdup4BmlQUszYHD4ao1jegqgpZnjfM7u47tIlejgr019YgZQUhhPajw2squuuITe0tqxuhcWYfISBHBRYefwTHX/8pXH37XwJQoEx4qWCox8EXDNwyTXKVVHhiaQlLm+vodXsoigKD/iYefvhVPPTQg1BS+9CrqkJVlfqzrFBJiaqqIKWElPZToiwrjJQy/mRbDre+FTI17oXu3mYsABmEqc0uMgEigUwQRkWB3762gYc6jOfvW0AhGUPJ+O+vbiLrruGRtTUMSUCZaxmsbaDDEhepg7c+lHjjGOORpRyFhPPFN/3ktiJAPVj2yQgi5J0u+L7jkGUBWXQgqwp5nkfFiNzN1VozPFHNCBAsFXRmuz6f8p8LGQ2fCJR3QJ37IQ49gExktjquLlVb9KE2bkLePI/y8vdQXfke5NoVbarvzNlnSwDnw0Ipog4fmc//jBDiJ7/ztz/3517+6//i7RQwl3AQkAh9CuC0c6i/0eGanq0+pSPWWeeir21AlaUmdKDhHwZMlLNSyLIMo9U1VKMCeZbvQWBcG7aaT1tM8W6xgByOsPzMU8h6PVx951+iWt/QPnXABE+1VXRDQDhVVeHoQw/jZ5YX8X///ns4/MTToKrEYHMTzIyFhQV0urnToOt0Mp09oJSCUjrQUJO+/awgZYWyrFCZALtK6uWVrLR5Xer9yqqCKnTAnTKaqmJtrh4UBX7nqsLzh+eRE+FGf4hvfe/7WNwokHe6OHL4EEgQiqLEoD/AxuYGqs0NrFYV/unFEf7nTy1BCJ3a6LujoWAi2qnpljAmDEGELMvQv/A+uo8/DVUWqKoK3bGPLXT3+Nq7PpMN0iT9CISXDucuDFpTVwosfSGMtaafdZDd9yiyB55A97mfgtpcRXXpXYx+/1+hvPyejjfozFsXjGAorPS5mu8uPD2/QP/vd//Oz/xleuPcr5w5c0bwm2eR/OoJ+xWJ0PcYp4HsLCD/2vKjnyKuvjQw2rmlNJO6pomkqlCtbUAOhujMzQdauZ7/vFQtpdDp9VCsrWG0sYG5hQVdZU4xkO3Jre4A/nzrk4/WcOVwiIXHHsGjf+xncf1f/Q/Y/NEHmhvyDETCZkXB5VBHed3EjLLXxadefRXr7/x/8d9f+CG6jz2JC5cu4cbKCrrdDrqdLrqdLjqdHJ1OB91uB3neQafTQafbQZ7n7t/8/Jw2t9vAOZvWZXz3VgBQUqEyPnOr7ZeltgKUZYWy1EVV+kWBC2srGJQVFua6KDc3cevGDfQ78/jmN76Oo0cfwPzCAoiAqpIoigLDwQCZrPAHG0N872aGV44tYKDYPWr2o+q9dDJbwc+Vgc903MDo0vuoihE63a6pLhhz4BjBK9jEcwPFKZaR1aQ+iqiv0V6xUmA5AsqhXtWdQ/eZT6P71I+jvPguht/+f6K88l2trYvM+N8p7xesMvTEkaXsl7/7i59/9qN/+exfOHsWOHMGIuWsJ+xHJELfY5x02nn117sm2Qyop0tltUIYQl/XhM73GTNq6CquiZ2BfH4OalSgf3MFhx88jspEumfZ1DO6Bwa4nvJ1/XgBORohX1rAQ1/6HPrvn8f6938fw6vXIft9TUB+XrPf1tWmTjMjf/pJvD4Y4KFv/y6++4PvYv3wEYzm5rCWdyHzHCrPgSwDslyXNvV85FmmNfg8z9DJcxcg18k7yDv6s9PpoNPJjSCQI+90XBBdt9tFlmshwHaiY8UYDUe4dvMmBjevgpghGXhwvou5YhOKCIP+Jj7Y3MCRI/djYWFRu1KUtrxIpVAphfMbI7z6wLwjVJsyHijGbfELZrgzIcAbayjXVrFw+Ihud9tq2blTRdeG5G3jmCTqdUpCjTZAJJA//gqWHvkoRu/9fzD41n8DLofax84KxCQkwKuDrLpvcfHf+72/88UHv71+4X/2xtn3ikTqCfsRidD3EEY7V3/18CMfIyn/6EApBaei1B5khk6HUkpBbprAOG7p/hUptp1eDwLAxtVr4I++AFlWkEphL8Pibg/c/CSCqiSICItPPYHFp55AtdlHtbaOcm0d1fo6qvVNVJubqPoDqOEQqtD91llKcFVBSInuUx/B8/PzeOzyh9jc3MSwv46RlCigm4MPARQkMMoyFCRQCIEyy/SnyNDPcqgsgxIZVJYBIgObT9vXXGS5CZKrA+U6ee6i5nMjEAih69VvbGzguYUOuplAUVa4b2kZn7lvEf98bRXHnjyGq9euYHNzA0ePPoAHjh8DgbC+vo7r165ifbOPUmpfNdkh83zcfkR7TJ6a8LWZO1cVypvXIJ58Gi6bwKaR3fXnurNttbFG6M/RJkACc6/+HPKHnsPmf/efQ946D+ouAix1th9TvtLn8sjS3C+8zI8t/PaZY//GqTffGb35pg4LuIs3lJCwp0iEvvdgluqvdhhZAVQAm2dShy9JVjraXSnIwQDl2jq4kqBM1Pq8b343fvW820W310P/ylUwK6iqhJoKP/oOsYVlV44KAEDW6yJ/8DjmHn6oLi9risJwWUIVJeRoBDUcoer3dZDh5ibKfh/FYIBidQ3VuhUINlBtbkL2B5DDgRYGhiNUZQlVFShHFSQzKsUomVESUDBQCtLEb8i/EBlKoYWBMstQkkCRZdgUGZQQYJEDQoBtLjYByzev4eNPPgAJglAKIyHwhReexqWvfxc/XLkfh5cOoSwLDIcDHL3vfhw79gA+vHIV66u3MJ9nOJJ74QOEQPiztQrqynzs+bHhCDvLMsiV6yDhuRImP4a9AWn5V/VXkT3wESx/+a9h47d/DdWH74J6i7Dpb0zUWdnk8r6l3s8ppd56+83X/+QpnFKMs9Z4kZAw80iEvkc4DWTnAPWX73/opCj4Tw51aHQWR4G71DUT7S5HBSoTGCcyEwzWCALTE3fe6WBuaQkbH15BVZagXEcsW0KPYum238t8tzHRTeuMylBSAa43fH0zJAjIc2SdDrLlJWd+J7/IjglIY2aosoQqKx3lPRxqIu/3UW1sour3UW5saMLv9yE3NlBubqJaX4fsD6BGI6h+XwsOVQlZlJDlUPvPCwUJbUYvwahAqIRABUASgYkgZIVHHzyKB489AKkYuUnx6j74MN546hb+Hx/8ED944AnM338Mw34f3333XVw6chij4RBlWeK+qsCJXg/Sa6trR8J/vnUxGWN+r53+ADOyThflxhpElqHT7UEIUUfvTyNEBi76oN48lr7wl7D+W78MaUidVWXGQHRW+rK8b7n3x5jV/5H+2tk/+9tnXs9x9h2JROoJ+wCJ0PcWLAr8+znQ0dp583m4zmmmipcqKlRr65CjEbK5HpxR3o85Mt9FlmH+0CHcvHgBxeYm8sOHURlCt2TuinFZH+uu3PadItYV4yA6881EVrva7dCV1vQuLfM3kcuTzuZ6yObnQEeOGPInHXHtnd52vGNZQRUlVFmiGo20Vj8aouoPUG2so9zoo9rYgNzUQkC1vg456GsBYDgAFwVUUYBlpa0MR46AhiOwKKAy4VK4lh47gX9dVvj2hz/Eu8NVrB4+hpvDIW6t3ETOjN7adXxyrsLxQ/ehUjrfntyQWOd5XeJV/z8KUoMeL9HpgaRE3umgt7BgtpxylzMJcFWA8i6WPvu/xvo/+4+gbp0Hcu1TNxEFnVsDKu9f7v2Zb/+HP/2Hr/yNd86mPPWE/YJE6HuAM4A4C6gzh088NaiGf2qg1cyxkWo60l2nNSlZolrfhBwMgUPLjpeCQjOAix6eO7QM+YM+Nm+sYPHwYa2hK+WqezE7w2sdF2WPObXsPkmZ8nyt/o0wnPSi24MKM0YU3jsAUtrFUUcojgvUsoRJEN0uRK+HzvKyqV0eWQGsD9u6AEydAFWMoIpCa/vDIdRwCLmxATUaQg364P4AqhhB9vuo+psQhw7hk0cv4NkPP8TVtQ9w6xYwUoxeNcLDh+bx0KNPQBUFhKxMHXWqK6z5BE9U34MgnU3GdS05ZoU8E1i67z50ul1INSPF1kiAywJifhGLn/nz2Phv/zaYS/28zbuhmPLVIVVLC703v/F/eP1bH/tb7/w3b50+nb1xLlWUS5htJELfA7xouKIvi/9tDzTXh6oAip6FDWIio6EbYpdK+33XN3RbVLNpW+tOIsLc0hKEYmxcvYbjTz+FqiwhlUJm1Uz/w5qqbcZXC2bO/w54Qg5Qp7GZWG9f2XesTpHFwjQsMRp/2+1z3Gt+khBgDuCsAFYAMMRL0OTD5jisFFBVUFWl4yBGI8jBAGpjHXL1FsrNTchipAsQlRUwGoCHfXBhyq4Wpv56VQJV4SwLuq66fviSjdCoGKVi0NwiHv7M5zB/6DDK4eA2B36PIAR41Ed+/Gn0XvojGHztvwL1luACBxhUMQmBjOd6+Pvf+A9+5iuv/c1zl/hNCEqR7wkzjETou4wzgHgDUH9l/vFHiEd/ZqjzsIx2Hhu9jW8YcLnoUinIvq4Yx5Vuaxnm+NZEAAI6C/Po9XpYv3QZCgxZlpDScxlyTVTu3GxioWOTPCMk823Y6KfDjF+zdiNQ2wgxfg/wIKDM7E4g55pntsVZ/FNE9feIJt87ayHAnsoVw4mv3NOkkWXI8hzZwiK6R4Wub25N8kDdUtcKAUpH87t/pbYIcFlC2QYrZambrkhtuWEA6M1j4fEnMXf8QVTD4bZGeOogMnDZR/e5z2D0vd8GD1dMjrpeTSREKVV1aK53dDja/BUi/MJbb50WwLm9ve6EhDtAIvTdhwBQIS/+l12mQ332tXNLPCENMEx/c1sCdjRCubqmK8b1et5WltNtMBTpwLjFJWxeuQJZVaAsCwLjALQok+Rze301Lm6KUffEnoy9J3Og1QwfLGdvnaeye0KO1dCDvZy7Q48He5KAS3lvYfVay/cC96Lf7bdhiFrK0BUQ+0iMAGLN7Oh0Ibo9QCwh83LyXUxAJJwQAFUWKPv9afa7bI2qQrZ0PzpPfAKj3/2noLll3f3OPWKRrw8rudDL/o2v/O9/4ic/+ca5f5VM7wmzjETouws6C1R/5ejRZR7xv10oMNclt+0mtbZozcI2KA5aQ1dFgXJ1QwfG9brG5A7UZWANGBBZjvkjh3Dr6lWMNjaRLy+jKivTpETAVQvzuKwt3diRkCWLtnXbwHRo7JPg+91r0zwQCgPs/k+1j77taJEiv5OxagV5IW3bORADgGnpKr1F4BZBzj8NzTaZA/r6VYXOEx9H8Xu/pckc8J4VQbFAt9uBEOXfBPBzp0+enBSgkZAw1diL5tgHFmdM4BsXnT/RY3qkhFJkEmn9WSTUA42GjpaKcf2BWe8Fw5ExuRrNWmQCi4ePoNrYQP/mTYAIVVXqvt8BnFTgEVdNW20szI4UJpODj5mhiIk35DveuSFHBePB8aHqMXUyWKRox5fRPH60zYR19SVT9K/uQd72b+bJHNBWk6pAfuxJiKNPgqsRjD3F/QOJbLMA9/Ls8//DX/7xk3T2rOIzZ9K8mDCTSC/u7kKzqJR/Wrn4co3m9EnBUjb/6Uh3Bbm5iXJjM5ztg5mfnZm4t7SETDLWP7wKEEGWJZSS1tseEYk9r7Mn1ynKHBNMbDKucVcLiu054puxWjuFywKzeS0YubotjNo07z0nf6xjAq+tIuPhzrivxvwugRWoO4f80VeBqgJA+q/QDbsAI5NL891OPkd/DgDw4nv7QJpJOIhIhL5LOGNS1f7SwgMPK+DTJTNxY/xDE2+gzRkfug2Mq/pDXWBG2n7g7LZzZABtOu3Mz6HX62HtwkUwoEvAShmd1+7B4W9u8Tt7m/lkFcsF+4ZfWrVVf5x8FbtJ/sy+xu6r7vbwXv1R8j5atPfojFtfZnTFBw8EyBKdx14GOgtgZQJCAzVdiKEESNCf+pd/5flleuOc5MkyVELCVCIR+i7hvVp/+1iHaFHCpjp7Zu1Y4/M0Zb9JCysFNRqhXFuHKkvARmC7XTlggLzXxfzyEtYvXUZVFlBKmkYt3HJORL+tn3jMVXr2eAK2pSXOHLHcFdU3EgC86HX2nhV5Lgw2Yx5r4NxyTW2yBCNcdiAZigiQBfL7H0N2/0eAaoTmtEeilCQPLXQeysTyFwHQ22den6UORgkJABKh7xpO1pT4iCnp4rqqAdaz14Y6ylpB5wtL1r3Rq7V1yOGo3tQjcl/Xz/IcC4cPY3TjJoYbmwBDt1Jla3vcCqEjOPaxW7OwH/DlG+7b9NbbxWwIA9sJVostIfq3N8rhpvawDbeKec6kBYC6OAzCwdrmwN2J7LJnz2aLE7OyZveXwVVV7+O/xpRxluWc5/SnAPC1947PxquWkOAhEfougxlL4RIKpvEw4MrbD2ayttHuVaW7ifX7rSfxZ2YhBBYOH4bq97F5/YYJjNOtVLePmKRaCCc6tSUV4rZ92ufLrWbR2dAyd8AFDdU6Gkx/mT9mvi/ejnmdKG+28XjL9k1tOZR/6klm++0+m11nwq1eChvt/uiLoM68qdlv/6a0DYSZskEFyij7wv/473/yoTfOnZNnzqT5MWG2kF7YXQZDVZGx1KSB+UQeB1xpKKOlK2ZtNt/YRLWxqTXt2MkKuGUuME4B65cvG7diGfnRJyG+tvD6HaNQuNT+z9ESU0g8Y860v3G7dxiNf0D2MYUSYmGATf6cHf4JmXZj0awe2H6ExhuyQzfMNm1G2waRAKoC+dHHQYcf1fXeG+YjokqRPLzUPUTEPw8Ap/B6mh8TZgrphd1tCHHdUFwQEx2aW5uwGrq0qWuKIQcDVGvrYKng5023FU/pzPXQm5vD6oVL+jiG0Mdpys2zb9eMrLenmtH1Z3SINkLZrrn3bpvx7w62S9RtV70DkvdiGcYfN1pvhC0nEniqdLDlViTfuMxwwbh9b7cA0aSUvXY71vhrYSVBvUXkj7wIrkqwk27qIxIyMARTRqcB4BROpTKwCTOFROi7hPesvsryltKT1NjpkcfQlS0BK1npzmujAuXqOlRRmP18Tq1nQoLujb5waBmblz9EOdL1vG3ntZ1j0gzN3j2Ed0Xus27dGlmRW2fpWBcl71+8zd7hTq5gJyb66Dd5IxEPoJMbKRw8RG6S6KCRx6YWoBjGR1/n3tdm6+b2mPDZdluep0BfqkmZHO/sGY/mHxcBLNF57CVAdADf3WSNTBBiUIGyLPv0b/3Fj5+gs2dVMrsnzBLSy7rLqJBdqzS5ebpWPdPWVeKapMlc90VXiiHLCuXaRh0YZ52qZoa1bUNtYNzi4cMobqxgsLYGACYffbtKyCQT7zi4qRk6Et8je64DAesjsg7siu7Zt+i3NY0JjAH7Hi3atx3jWDgLXiF229tiQLYIEZgcSetUx3AvJ0ARTCtXaiXaNnnMLTOCgH8HNp2v1f4TyyXeJ0WfbWjaK3S0e+fYk6BDD+lGNWZlbbkgUorkoYXOwmIXPwsks3vCbCG9rLuEt0xRGQlcUsA6OXWqpjWf1tuJ05aAhe6MZSrGVZvNwLhQyycIITB36BDUYICNa9d0YNyOCD3GdszEMcGELOCmd0fahGgRQJHJtuW0t3Els43WG+bmBhy/R9E2Mes5HzvXu6NeFpe+bU27t2fnSO/3UiEcyXv9AHRvAU/YC2P7AotObFUaZ5YPLhYAywpi4RDyh17Q3eciS5E+rACTQJ5lfwIATuGdZHZPmBkkQt8luDm4f/06mK+a7syGs2xnLjKG6Tajsp2aWZvbmaGkhOwPdGCcJWY78bK/l9as5hYXkJPA6oVLADShaz/67dzRTnbyLQdkrmfM8SIrg7U02Ameo0m91q4mX9W+Crbbcui53XHtO89b2dx7I4NNm1aW4EKMnGbfO9fkxj67YPOWLnRWcoNd71kR7Ond5bM7hne5DY2+effkjt59/GUAoq4Y5w8JCTGsAJHRT/32X3j5MToL5d9CQsI0IxH67oHPAOI3gZKBCxnclAeAPVKfPFvXBWYAxQpyONQFZkx+baBDuXlbz0iduTnMLyxg7cJFKCWhqgqyqoK97j3sJN1CKADCqZjDsqmo/ao2bevAaefbRZuUFiS0N1Z6n35tfv/Z+KxZL6f4Wfqt5hrMHQpiDr5GTuG7QL7AgNrcH1tu4rsLKvSBARJgWSB/6BnQ4lFAFvW9OMlAkGQhD893Fxc63S8DoLffTEVmEmYDidB3F7YRy4+oVjeiiWh8qFetoaMRGCcL6xP0tFtf0wWQdTomMO4KRoMhwHwb+ei3i0l2c6tixZqjrxHW2prv6/WNEaFJmL2jbI3bs1LMGlqIOVg3KcyQPaK1ZG6eCUUCmrNf11o6WO9PvoTG0X7m0L7C7gffBef0riJ+ddwRHfPrfQkEripkS0eRHX8GqizMxXvWB3tyEmAh/iQAPpWi3RNmBInQ9wBM/H3AJ/K4uEwwXTno6Yy1/5wZSgGq1H50NRzWfkpzDL+uO0j70eeXl1HeuoX+rVsAcId+9J2gxVTb+ju8B7ssbtka7suw/d21JgeQ1/omtqq2XcF+aC62NSZJLbEw5W8/zqpiPrcpDNUGI/+4+q0OYkesPd1naK63d7UMODTN+3531xgnOL+xhmUC3cdfcpHu7G2v/5+JoQSyDD/12/+rkw/R2bPqTJorE2YA6SXdRbznZkZ6zzjmCAGZ+7p6k2HsWr+uu5IV5EYf1eag3sppRXATIwEQIsP8oUOgosL6h1dQd16bJgWknVjcGHlBVLWvlpwJvg7kClu6crj7RKPz/sck6WW7kk37OzoRY80g1tHUdsw2EYxbtm0XMGofvrEwkNDNWh5+Aegd0s1aAolP236kInlovrvc683/DAA6dSZFuydMP9JLuos4aaYOJdQPRmBFoAwmtrsOiLNon/w0TxsyZwUlFarBANXGBthUfqtNh6ENkgSht7iITp5j9cJFAARZVqi2XWBmLxBN8Pa+yK7ztDp/ZqY6j8D8dH7Y0Ixbf2lLiduf2EpT3+4xttq2Zf04P34QMj/5+sg82GbLXkP07t3Q/ng/SA8AuCqR3/8wsgeeABejep3T/AFQxiLLWAj8PJBquyfMBhKh7yLOmilluCk+sJHugNafawP71hMls/WjG1IfjnQr1UpG23lmUvPZ6XUxv7iI9QuXtP9cSsjbLjCzG2hzRcBoUvU6iiZxCrb2/0+Ba9UG3nO9+5ZXkYC74KOoze3jRzf22UdH8IWAoPxdLeQFVhr37ihQp4fOoy+BZdV6CcyUDSsQkfiZ3/p3Pn74jXOppWrC9CMR+u6CGaB/gBvrTPRDM/gqnFHGG4XtEhvhrkvAKsiiQLm+4SrGmVO52cz3J4osx+KhZQyuXsNocxPMjKos67S3mUFodvWjmZ05nsOIeLuLn1/tB2RPEmq2O5MfGOK/KwLgGG29sd5+t8FrW2waLGxZYZq1dB9/EcjnwErVyrn7syEqJaml+c6x3hx/BgDw1uk0XyZMNdILust4E8gAgJm/L+oYXcQRvDF8fbRupar/2cC4ajCEZSxXvsMFD+m9RSYwf+gQqvV1bNy4ATJ+dBkECN2LO78XiM20zQtnN0OHpvl6uX+/NLZIyXaHJKlwt4Ft+zq859i6bqt9a2GZqwKdYyeQHXkEXBathyUSqptnnAv6+W1eYELCniIR+h6BGe8Cdpqpje3wfgfbRz8Uu3h3bTbf6OsCM3ZLpRp8pwPjBOaWliAqhbVLHwLCLzDDzfzemUObZaMtNqElmj6w2ta19lpTuu/GpR4IbONlil/uewj3LigJMb+E/OHnwVWhg+Xs6Z3sR2IkQUT0xbdOPzZPb5yTSDJbwhQjEfouw0W6C/W7UuvRYhKRt0HPN1xHuyupO6+tb7SYzq12bszuROjOzaHX62L1/AXtj68qVzFuaw/+NGBnc2qzj13of7d+9YDXTQ4UGcXOeXt9e4o1gHjLZ8e6sVu4vQG5N6zJ4bvAjO6JlwFk+u/GVY6zYapCjCTxwlz+xKPHjn0SAN46nczuCdOL9HLuMmyku5TqewW4IK0aBKE724Fi23XN+NFHI5Rr6+CyClTsJpUR8m4X84tL2Lh0GeVopCPlqwrMXvnYMeedDsKa5Htt87v6iDKT2f/0jmAio5ngepjAI22OdrDtYP1c6ITbx/aHcCvqH7eegKpA56FnIBaPArKqBbPaGwOBTC70clCOPwYAx05eTRp6wtQiEfouw0a6Xx+tXgD4fAZLJ+N143HZuQxAQjdskUWJan0TcqQ7r/mBYXYHS15ZnmPx0CEMr19Hf3UdAJt89BYftHdV00dU27mgeBv/jrxRJV8OCgWBMLKhtnTY7YPuZHz7LoupG96ZQGhpmbze35TAskS2fD+yh54J0td8UmdAFJIAiJ996zSyU2ffSWb3hKlFIvTdB58BxDmgUIzvZdrQbqgWaE3PMZ+xJ9i1UmWGqiTkxiZkfwAbEue2jILCRCawcGgZanOA9atXQUKYinEysB2zNTlbM7OXy70/wHVAFo8hBhdXYHPdwngHR/dunDiIlm4rbjMOiSXuFDt/LynL0D3xsueq8h8aASAxqsCdTvbRo/e/9hIBzGfSo0qYTiRC3xvYCJxvm5mBdXHT2Ldbo6G/WyKHrRgnIft9VBt9y9tOxWDPAKDL1xB6C4vIGVi7eBG2YpyUsnleijRQPw3sNjB1okBAuJ7g461kE4fgW0pqwSYu22vW2429QLugjPkOiH4n95CwExAgS3QffQHoLYFtHIn/GpAAQPLQQkf0OvQlAHg79UhPmFKkF3MPwSy+LesoHANqaH/1GgRrGJ6GrhSqwQjl+jqUlJGGDrDbQxNLPtfF3Pw81s5fgqwkVCWNH91vwoHa9OjlsseR8DshpFlWbepxiLp4scfarlKZzW9n98P6aCkSkvye4OEJPdfJJMzyoO4liHTVuKMPIz/6BLg0Znd47zQDTIIkE0DijwDA26lHesKUIhH63kBPCILeK8FMoKxp8G2SeTytWzKXhtDVqEC5tgFVlrVp2KuaVSufhDzvYPHQMjYuf4hiMAAzQ1aVTocLCMQTL5gD7TJoT7mvtMRxgXQcfYf33a5j466oXSixRg54YxidJ8iDJ2vq3yKNMeH2wQqiO4fO4yfBVQUneXmRLWAhRpLQyfDJ3/p3Tp44exbqzJk0dyZMH9JLuQewgXErc/KHypWAtSFrFmEoXNsE7vzoxuwuyxJyYxNqODLzUkQ6QcW4DAvLh1DcuoXNlVsgMp3XWszuY4O8TGAYhZe6DxA7OMZ9txhz837sgRdAxy3bBNtx8yyxQEAtyxJuE0qi+8TLQNYN6zcwjOhNJBXk8nx3vpd1PgeATiWze8IUIr2UewMGQP/o5s01AD/INHkrgMfyYmukuyVza3aXEtXGJqp+3/MD1tFZPsELITC3uAgxKrB6+RJAYmznNdfcwruYuNLabBVf2an0MWl733bS1Npdz/Y4ngGwmXFBPrsPu1/s4nBn3uFtJAGgBSR01bjjH4E4/CC4LLw/G1+8zphEhizL/giQmrUkTCcSoe8RztgSsETv1hq6K18SbOsbedsmfZu6xkpCDoao1je9nHLUyrlnAyAidOfn0M1yrH5wUZvcy8r50RvwU7o8t3/N9c1c7untXrbTC5u0/eRj1WPZHvDoguzi1Rxu4UhmzNlbLTixVh+GRiRYKIls8RA6jzyv3VXO7E713w+QjSQAotf/yZ999Uhq1pIwjUiEvsdQzN8ITePj7dfxGmdyt5q6UpDDkS4Bazqv1UJA6LQlAJ1ez3Reu+jM7WM7r7X41f2Ib6Ka4B3HH6jpbtLN+j52/buR/OaC7TyxjQAQO1HP7uLHMvjPQB+nPqorcjNJPvMu48CSPOv3t/eRV1CTOWALLOmfgioJtTzXeeBIh38KAN5+/fVsby44IaEdidD3CLYELLP6dgkAoMyrHh5sO1k/5Nr0rhiqLFGtb0AVpbe3neV9dR3I8hwLS0sYXLuO4cYGANYtVbfVec2KIV53M+/4vkGAvQlyf2J8umG9HsE2bvTcuGlxLSj/y3CpjL6e7xe1caZ8exRquRpyh6sPHcuQCIWGAwUiXTXukedAi0fAVVkPqP/naJu1dHW0+6l/L5ndE6YLidD3CG/ZSPdO9f2KeSVz83C7hj5u5mDovujSknpZodrYhBwO6wgsw6y+r9sGxs0fWka1to71a9dBJCCLdj96AIr1wmAlLA1ZYneERDbiO7AZ7ANsdSct7Nm6TVRrHF7GQTRmDXsJI2Rp73tgNbFXsVVYwEGCSV/rHDmOzvGndPc1Xwpygy5EoUAAfeGt0ye7qVlLwrQhEfoewVAt/dr6+g2QDoxrcZH627dCT9Zc13aXEnJzgGqzb7eA8297BWYArenNLS0hU4zVi5cAIlRVe4GZ4CoamnaLAGKc6zYC3vcVW/N8M8hvzGlnGhR938r+jcihHjpZKAhI5Folhx7XWmCihhgRn/lOxnvfPSpmUN5B54mXdIGZIN2QACYwSIwq4vlO5+mHlvKPAalZS8J0Ib2Me4gzJjBOMX9H6HlZjZsqx0+gng+dTee14VD70ZVyWnF4JOsDJ3R7Pcx1e1j94AIUK915bZwfvUEysb4YB/WxmxADq3u7IjlWa9wOeUyvMNDQpSNosgh/m8/GPuSZ4UOhqBFUZ8RDitd5/nJnwGkw/fjx9H33UzvktwMCoEr0TpwEdeYBWXljFTwDuTiXgzv0c0Bq1pIwXUiEPgUg4Ovb8cBaxBTBsPnogFIMOSq0H91G7Pq+bevvNsqd9qMvYuPyZRTDIVgpVJVsbdTSfgVxmF7Ltu701qxsiYS3NFhaU/FWhL23Pdxv5+RthG1/j7lZskZ55zGvLS+oR5Y8sndjbX6wOYbLQDADHPvUG+PprDr1pe/krtvucqpAAlwW6Bx7HNnRR7Uf3Q6M8jR1IqoYEEJ8GQCdevOdceashIRdRyL0PYQNjKtYfLvSM0YWT5Nt3urYIMt+pDsrExi3WQfG1XzuQf8QWYb55WWMrt9Ef2UVAEw++nbnqXFTc5PoXdUz8pwLNoCOufVIgQY6tbgdemrT3FuEo6jGrg6I8+IUzH6+RYWJ/SPUrhb73ZzKP6sLsvP2C6+wWRWwLY2ucXf16QJs53Fueey7DSWRzS+h89jJ2o/ujxsDzEKMKkKWidf+2Z8++TQROFWNS5gWpBdxD2ED41TW/37JvJqBiFtptwlfv3MauiX1qkK12YccDOutrK3bq2JCAAQR5hcXwcMh1q5cAZFAVRbbjHSfhFiL99q5ckTQLQFcfllZ99m+yz5Cy01FN+rXdo+zIhzFW3u6A4VaN5N7Hewp7HjHIZmO/720xGB529V7JnkO5ZFxd7kj+PLg3QSDAFboPfkymHIwq9qP7g2zAslD853u/HyqGpcwXUgv4h7CBsb9Z5ubV0H4/czEho/bfpLGElaMU5D9AarNTdRGawRk7q6BBHoLC+iQwK0LF8EEyGpCgZnbQqyNWo2SGpv5oVyxVr7tKO19DV+UCwchTG6z25hPZwGhaDePqah+RYLdgTq9ztu38Xzsq0X1b3clXPvsJ7/l3vEmrLjbj19fN4GrAt2Hn4FYPgouTW13FdbmJxATCQiinwPAp3AqNWtJmAokQt9jvGWeAZvAONh0tha0TmLGwczMkGBIhmvUUq1v6trsFFNqnR4liNDpdTE/N4+1D87rgLhJBWbuGJN87uaqPLK3yqaTRSLT/CSz7/5Em6m+ZZtWVo4+3aPQZnzfUK9Lztrv8Jzn3OgW5/aimqztI4yv0DMSuP22CsADNy+9ce47hHY7EFhWyA/dj85DzwTd1+qLBRRTNqoAkPipf3b65P109qziuy9jJCTsGInQ9xjvmolAgb5xWwdwJtDQjy6LAtXGJpTVMvztfb+gFxjXv3wFw41NMNsCM/fGsLn1FOyZdz1usilvbTPn/jTB3020xKV7NnIbXEfeCo4CKvXCOp3L+tUjk3RgZrdHcFXr7G/vs3k99Xcy/2uLJWndbwdoFY2YQVmuze6S6/sKrFpEpYJanuvc31nOUtW4hKlBIvQ9hg2MI8a3ShcYV2O7wUMMz4/OpmLcxibUaORt5e1h/egMCBJYWF5GubaG9evXQUQ7DIy722iZRVGbPa0fWfduR8AUsRDgH3E7Z519tL0xPpk33R/+PtzwosMLxPP2I+Oz9+znbdp23ZQmuhpvuQvI8+XOaJl7G1osMo0OdttEHGiqvwhAFjp9bW4JLCu4nHRlX0ACQahOLjhD9nMAUtW4hKlAIvQ9hg2Mk4K+VzKvx4Fx25klnB5lNHRmhqp0gRnZH9YHYmNqj+zUgghzCwsQpcTa5Q8BEqgKXWDm3pjddwJ2Whqo7kYXBmnVKpwrZBMFY8Ve5TbMvs20RQsHvGVxKGX8vW2UyAvE87bzgvPclr7D3Gr93oOo895r3XxsLnx0RebxB8v8u5v47Hb4CnNZIH/gEeTHHjfR7vYYvnWCRKGIRIbP2apxyeyesNdIhL7HsMrFr/evXSHw72v1fGd9yuyEaLVzibpRS2lM6LBR47653QVDETq9Hnp5XheYkdWUEDqMEAKj0Rlt0Lsu590lgNtm721Os3t/p3eKre6gbX1M8jG5+99blvnxDk5y8mrSs79pKEg6zTom6lBuCE8ZeY9iaaD1dfUuJfwSHQvGj84K2dw8uide1LUcGmYCACBRSHA3z5++f77zGgCcS1XjEvYY6QWcArylzezMoG8LbUMOAuNi43MMMmZPWwJWMYNZQY1GkJubYCm1KdEczQaW1alHhLzTwfzCAtYvXEQ5HIGlQlWVU0HoTUZuRndzrTrpZRF52NXkfW/c2TTc6q5j0k3XJO9M7g3W9bdDrZ3HhwlkVC/gEZ7JPVztPbDweQUB94TAHRB7BgIBwvsSv9YU/1I6fY2yricM23u0e5Bcmsspy/hLQKoal7D3SIQ+BbCBcRLq623rm17NEP5EJ6ErxkllC8z0dYEZF36MSKvRM6MQAovLhzC4fgObq2sAAbLYbue1e4VxhvKYTMzWzgyvqYKpnvzboq8CCzHQiNw+WGgzZNfrnMmdubFu3LGsoKn3a/HNB0Rdk6UjbE+IcF3kjFreeCMYAd/6wkH8umtLQtwGx78wApcjdB95CuLIg87szm7/ekPJBAj6WQBIVeMS9hqJ0KcANjBOsfimDoyjIDBuS8XR8bTxn7MCQ+eTy03Tec0dKNKmjKYjsgzzS4vgzT7Wr1wBCaEbtSi1h1r6zs6rg+RqIcDpgQT4SVm2JWm4b6QB7vz0M4y2mPNJ0k0cIBftZy1G7nno47tCgeYf148Kzi/vvZ9WKw6i6WGfH7zgSIT72C9esJyvnetMCaqD8+K7JYClRL58BN3HnoPyqsbVcg1BV40DciF+7P/1p195MlWNS9hrpJdvCmAD47I8/27FvFq3Uq2xFbfYHVxNd9YFZqrBEFV/EPqeA5VFQ5BAd24OOYBb589rgaAsoarqbtzirqHVh240dgp4i5zrwdcAAY+fDozG3vZ2jdVfm785os3Ap81hWVlfK4/z3cwxKBYQojw49n84awCFSyM7vrXWOC2eawHQX14fgXXRpSdf0Q4wholy983upmrcXLeXCdZV495OVeMS9g7p5ZsCmDmKfnXjw2tM+EFGdStVgj9tTYbVWCQrbXqXUvvRNzYBazoPtJmwUUun08Vcr4fV8xchKwlVyUbFuKlwqU+CN2p+NHVYSjYikVm6v3uKhm/iNvaPzfFenXmfwCcMdBDwGLtK2M+VD4UFp/mbY9hlgQAb+M+9ToQe4ZM5MVcFeieeh1g4DK7qeg7+/rpqHKGTiZ8FwNeOp/S1hL1DIvQpwRmTf07M3zIPZUfOa2e1hJeLzkp3Xtvs64pxwp+QwnmHQMjyDAuLS9i89CGGm5sA2wIzyuzHDT/zdBKgrzH6JOVma7feanNujwOjlY/DdmxBW8G3pccEv9V57fMyTqQWLZ6dmT/07YeavzWpe8c2h21eRds9E1CV6Bx9GPlDT4KLEQBRm9xNTrpiykaSANBP/5N//Ykjb5xL6WsJe4dE6FMGBr52JzsHTVrYNGrZ6EONinBTxVpr97RVITShF7dWsXnzpikw4wXGWeLz5r/pJUCfBEIjbUAObN0QYfT/BCV+y7NO+j37GEN+W24zbp+2F2jc/hRtYsm/Dp6DF0fha9L+YX03C2B86v6ztp+sILpd9J58SWeK2JXBy0BUKajFufyBQ4eWPw0ASOlrCXuE9OJNCerAOPWtUpsVM2D7U6OvEynUhM6VhOybzmstmnkd6MMQgtBbmIcoS6xeugwIXTHO5qO780wtiQOBX7UlyCsM8GvRIM0Y2aCtOOgKmPxM4qGZ6qHadcRjj2Y0WmNhFIAXvOm1Jm8XkW9Gd+taTPjW3QQjwDnV3XcHECAl5p58Cch7gJJmlX457HciUt0sZ0Hi5wDg7aspfS1hb5AIfUrgWql2qu9VzCvCzFbb8p0jmiqNls4ApJKQg5EXGOc5ETncm0Dodnvoigy3Prigi9RU4yvGsXe+6VFF6/tp77DeAi8y3kZB658crI6Vs2Yw1bS6IO41dnrTvqbdQvIN4vb3C9fFJWmZ/H3GCXRtdhT7d+EH4Jn0tYeeQHb/w+CyhPO7u+BSgFmIkkEg+vxvfBydz77zTtRAISFhd5AIfUpgA+N+bX39Bgjfz/XEtKUfPa73UQfGMSQUWCmoooDc7IOVrEnOSwdyyhLpAjMLCwtYu3ABZVHoAjNlHRgXTIdOe6UZmL4mmHEjltbzdT25x0FdrgRpCy/5pUwPJrlPQhtJx+swYZumCyUUNH1StvEesT9/3Ivqa/G1lYeVRL54CN0TL0AVNn3N/7shwFaNy7Jnn3r2oy8BwFun09yasPtIL90U4YwxsyvgmwKBqjEWbaTh0tYYUIp157XNfp2CxvEBrIYOZJnAwuIihlevY7C2DgCoqrL2o3vcppt2zACXT0Q8gD7BtzA3AJvv72t7cbUzNy6J1D1MGow2rfp2j29N6RGJuwcSmfGDPMWobr3ZfO7pV8CRFm81df1BcmkuF5R3vwgAx66+Ptt/FgkziUToUwgCvlZT7JbbNsgkaKUK26ilDzUcGe3D7zvOgTophMD84iLkxibWTIEZ3XlNhRMdvDQwYB9poy03ssW9WT+7n+Pves6naX2H2PpFopZv4VqKvvsuJu+L1cSdpt12OJO+9vjzEEv36fQ1n++dzECkWEAQfxkA3j71zl6WWEw4oEiEPkWwgXGS1bcKExi31fTm3OCIfb1eXXcpIQdDyMEwTO3xJyXoKU0XmJlHzoxbH1wEEyBL3ailOdeyp7DwPiL1GNsgmTi4i8NI6/hze0dNCGFzFMb51+0ybvneQthBSlzkW69D4MFlic79x9F9+ClwMTKaOqK/IRIjCWRCfPKfnn720bNnoVLVuITdRnrhpgjnbMW4gfy+ZL4uAvViPJyC4RTESENXCnJoKsb5/sfAvGhNx4ROJ0ev28PqhQtQUndeq6oKyqbGe6xkTcuB5r8L2FsybJKDFmz8x8XudxxZ7wtQ4Oa9JKKfhHF/EluZ7GPy38J0EsVViE4HvadfdulrAZ+zjnWXgFzqdRY71DsFAKlqXMJuI71w0wUGQL+C1VtM/L1MawkTTXe+yd2PTXMFZqALzKiiRLXZB1dmQjKzEUXKifaj51iYn8fGpcsY9fuAYsiy1LnrsT/ZmZsNqTMamvq9IKi9sWSPC+rypCm73kbHkU2f4yDuwJroXX96PygrOktwtgPN9pEWPXYbH21vynaO4x+CwFWFuadeAnUXAKlqNjfSNINATJwJgU5H/CwApKpxCbuNROhThjMmMA6gb5qHM9GSbTWEtvQpPzBOlZWOdC/LmmxgiZ3rYwHIhA6MK27ewsbNmwARqrKCtBOZvj7EwUXW/O5nfTHQ6O4+u7Oc8y80l5P/iZqkmTy7RT3OYQS2Hkur9bWeFt6mBxK3e+PRgG6rEhKFn0RAVaD70AlkDzxiuq/V/i1bNY4hRKEAAk79wy+8spiqxiXsNhKhTykY9LWQZidtGwXqUq2hS2N2l7KC7A8gXcW4WktxWqLLuybMzc8DoxFWL14GCUJVllBKBmdtnaksj/lm5WjD2Z7hxjyPVnWaGt9tgR5nhievROkY/3qt0d/BZc887tLNx2luAcbbRlhK5AtL6D1x0qWv2aYtdWAdRCGJ57udR48dkp8EgHMpfS1hF5FetumDAgAJ/tZIN27OtiLAID2K6w/Ftp0qg6WCHI4g+4N6R65N777eLTKBTreHLgncOn9Ba/tVCVmFBWbYaazhZOsLGHvXenUa4LO0N26WBMz/2RPGPEt9KBh5lo/g8AlbYNJfzw6iF8xh5p55GSChtXJYl1P910OAnOtkyDviy0BKX0vYXSRCnzKcNbPKoM8/UMxXM22xbs40XmptqBSG5nSroStWUKZRCysFgEKy9SJ2iQQ6nQ4W5uexev48imIEVkrnozcImqPv+l9rZblY6NihK3N6sY0gqwD1QNRV9jR711+ttWTCECWq2AZu5wVreZ6matzciecgDh2t09fMKawFhSGEZIIg+sIZQJx65x0ZHz0h4V4hEfr0gc8A4h/gxjqA98YGxnHw0VwBY3ZXJjhOKajSBMZJGamAIdOSYp2PPr+A/pVrusAMQ1eMU5Ni9OIc4Pqo1r8e66uTatvODtdvLZnQRN+tZx9hq43XopozyW91Fa2SX3ObGRrYXUKb6SMeJB0Y17nvGLqPPaO7rxHVtRzdLkQmfe3ln/j5558lgDmlryXsEtKLNp2w8XDfsF/aNorLvvrzUF3P3WjpzJCV9qOrogTIe/RM9b5m/4wI8wsLkBsbWL96VTdqMXXdJ8OnbF/qqNUY9jfDNshqHxBQ02LRdlO1dcNwg+drt8MX5vu7bWEEgS3GilqUzwPtFQGw7ReMGZTnmHvmVWflsrt71idiRrU81+mg0/08ALyd0tcSdgnpRZtiMNNXWQefNdW7rTLUDdvr1DWtrbsCM8Nha51r6w8kAkhk6M3NIZeMWxcuAhR2XhtzxW0XAucVbmWTOuirbc/wywxhp9cc36yffWBTDM0zI2LPJB/2lPN/xM6QsaeexfHdCxABVYm5p06CeosmJ51qq4eTrAQBhE4HXwaAU6dOpapxCbuCROjTCQUApZTfHjFL6FS2RuRZEHxml1vONJqbYl2yVTJ0kZiR6bymosMFtliCIEKn00Gv08HK+6bATCVRVdUEQo/hkbk+iXcOz98e3sE9w64qots6mc++k3LczRpH8HCfjFprD5a7H95Rtmm2TxgDWwb2wceRH38MajTSy4NxJzCTSV8TP/lf//EXjtLZs4pnUyxNmDEkQp9C2MC4Xrn4hwxczHSOcutUG6SHNdbpPHTJSvvTTYEZuTkAK2nMuOybC2Hth0RAJjIszM1j4/IlDPt9wJjtm4Fx49Bifg+qqflEH+4Rf78bmL4Z1R+Hrawe/oP2yN8GJ1ixyAhNFPljGNx6hob4MH2DNFVgqZAtLGLuqZfAlW6n6oJEXLAIqGKSS738vnnQTwHAudOn01ybcM+RXrLpBJ8BxC/hwoCZ3zV5a+1+dPc/u2e4pSZyaD+6UrrAzGAAVfotm624wEE5S2ELzFxfwaYpMCPLEmpLP/qkOxtH2eSK3DCCybF544yGJnlwFMvQkqJN8PVPXYmOgjgFdts2xy1lwt0GlMLcM68AlIMV1xYStwEBTNzJBOd5btLXriZRKeGeIxH69MI+m6/HVnVgm9qmM73XZWBdgZmiqLdzVc0AqvNvIITA3NwcMBxh9ZItMFN5ndfuNlxVHAQaZ0zgXk62WzzTTLTVxceO8Wbsg/+s6+FjV8jGHqatSE00tLd9lQcCQoDLAnMnnkF25JiuvOi0dP9PiUShiCDw+bdOn+x+9p13fAk6IeGeIBH6lOJFM38q8NdMPG0wGXDbjxZ1y/VGh/7uCswMhjEvxMq98aN30SHCygfntQm/0o1a7g78FDeGfwVM8braN+zJHPURZnaq3M6Fx1TaQsHsSThRPIT/Uwc9Wo+ucbeMcXm4ZWb/mR3iuwyWJTpHjqJ74lldBpa8XBQnLJEoFLibZU/PDehVAHgrVY1LuMdIL9iU4l0zt1Yq+86IVUktgXGNKPDQEuuWK1bmnzG7jwrIIDDObxIC50MnIuSdHPO9OaxduIiyLMFKGj/63QjcjfzD8Srnb/cIn2rRZlKK1iRtcro0zdu9mvihtx3H5rHVzxWw5niGXwQg0NobjnW4tLkY0zWWuwNdvzHD/LOvghuNWuDLpnKx26Fuji8CqWpcwr1HIvQphQ2Mq0bX3mfm9ycFxtUM5y3yTaoMSKulsy4wI/sDV2DG97f6szYRIRMZFhcWMLhyDf21NQDQdd3lvcjEiW7ABXyFi33fsO/zbz1S4Ec262aehbbKWfQQ3LjZj+EVrtFCUhBDF8UqTrKCBE9s5sd1myACVyXmnz4Jml8GS1lbOoLxFqRAoEyXgT31dqoal3BvkQh9esGngew3gRJE32kLjKv9x549NJp9bYtOZlsCVpvN5WAIVZb1/r690PspTKOWan0d61evgYi0hj6xYtxt3zIaBN6yDXk5WFZhH8slkawTuKBnFttlTg6/G6uHDZrTY1E3h6Eo62Fi2dmWM82u22NnICJwWaB7/FF0HnwcbJu1wLN0mPS1kWRkgj7+1h996gQR+EyqGpdwD5FerinGSUM9EuprZpGbX8fOnb6mbfjRVo1z/6SEHA6hhkV4JKfN6v8IOjCu2+tBVBK3LlwCb6vAzO2ijZot9YTmYT+626ZqxRbjMUboyZh6LTO+g63uKLZ6wPOzk5Hh2AXL2TI1rnANLMmz27btuU9MvJv6Mb0NKIVsfgFzz7zkuq/5grAJRiQFksu9zvxiZ/4UAJxKVeMS7iHSyzXFeM9Zk8XXpZ4U6+c1bh5vWa7nb6OhwxSYGRaQw6Ejx3qy9naCCYzLO5jLO7j1/gemwEwFuaMCM9vFdj3fhsBbctfG6fixNXTspU+9lhnYdMdsEwcUhqTOwTr9yy8xqz+olgk9e7xNiwuuaMK4A7XmH199485miPgZAJTE/HOvAHkXUN4LZgVjJhATCxLImH4WAK4dPz5Dd5kwa0iEPsU4aaaGrpK/W0INhH5emuR933CbeuSC4vQ0a83trsBMWaIaDABWhs+92cgzwRMIeSYwPzePtYuXMBoMwAxU98zs3sSkxiYhqXOthLL2lY9Le98f5uGakJvL2z7r9e33z5G1g+vXAR4pe5/W20P+cu+U9syTm9PYbbbcZHpgzO5zjz+D/L7j4LIAe0KQ09RhqsYJ+um/9/qxpTfOnZM8A2JjwmwiEfoUwwbGLQ9XLjLjD3JqBsaNmZcd09u8cma4XHTFbALjhlBVNd5Zau0DlGFhfh6jmyvYuHkTRNAFZnaJ0HdmCeCITNhZl+PbnESFswka8z1e5LfO3cqEb14mF5OB4NPu4nt6AOh+P00Dyr5hMiICywqdI/eh98TzUMUIvtm9zv4nUSmohU72yGOLxz8JpKpxCfcO6cWabvBbQHZWG/S+LQCQqfMeFFbxFTE7axqnKBOZyZXrRi3MUJWEGg515zV3Nq7tpwzjRycIQej1ekB/gNVLlwESqMoS8p5Eut85XPygH7INa3jgFq/8eMwWwW8hrrTeTGzCb9ko6J7D9XZedHxwPE8FrYMRQ5P7bI1rO5gBEhnmn3tFt1G1piH7njnBktRcnqOX40tAqhqXcO+QCH3K8a6ZE5nxNX/51j7gWqsiEPxqcQo2MG5UN5gIEJpyBRG63S66RFh5/wN9rEpCyq36o+8NnPvABnY5norswN4YWlnmYMy0bdp5m2bufyUXMAdiZ+6wHBaYQYxVxFWlAwCm2gvU8BR4z2WWmN40a5l7+qMQC8uu+5q+DyNWKoCZRMUECPriGUCceielryXcGyRCn3LYwDjF/I1KE1TwzCYSkKdx6zmXIZWXjz4qIAej0KTtc6H5TiSQi8wUmLmEqizBUnde236jlr1D3ElOL0QweNRiknf7Y7Z4ZvuINfpxd2n96j7xWjNOtB/XXxiW39ljcjTcH2zJr80lso2BvxvP5nZeYwLAZYneg4+i8+hHwCNtdmff0gUApP3ouaCXPval558lpPS1hHuD9FJNOd6yJvY8e68Er/uBca1o0z4dh3kaumKdfjYYaC3bTLw2Z90/AAHIsgzzc/PYvHIVg/V1MKwfvb2L13SBgm91upvvYajrnsdGaBf0tVuXO21ojVajMcttp7c6c0Iv9kzQdrm1ikSClT6KWb8Nk8ndsKrEt7ItIY4IrCSyuXnMP/MyVFVq3znX75aOYwEYqA51u508yz8HpPS1hHuD9FJNOYzSQv/J5tWrYP5B1hIYN8la6sPPRWdmsCkww6UOjHMakZvNrMmakJFu1FKtrWPt6jUTGFdBKXl76s2OMIZQtgV7M5pkGF5qXh0sUJtIPcUz1hZ9b4b3MfHMs4e2vMcxdotoeVwXoPmakrcLGdN98/Bstm29mns0qPFhnXtgS5BOX3v+ZZO+puoDMutubACYdcBBlpGuGnfqnenzVSXMPBKhzwDOmDruDHzTPLBwMmhziVqQ83y6oiC6UYvnR/cD4/yJOCL1uW4Poiix8sEFQAjISheYufcYZwgfh3FTsW++GG9udpXoAg1z+2fZ7vrpxKSXCRPW+ZHzkcbra93eOchmYZBnlTerefxp6it1Gv8OWf42nuU4EBFUUWDu8aeR3/8gVKm1dLZCovlkkBgpAEQ/+dYXT95PZ6F4Vl+RhKlFIvTZwleAZgRxQ50I7MRhRy2npcNr1BIExnn2aM8WoDuvddDLc6x8cH5sgRnvVHuI2GgeL0O0vi3Fy4uORztBTTr7ng/BHSOwSXgY53zgYJNG/j/FP+pWr7XAaXY3yrsznkSHh7edNtnvkBd3uPnEZ2nT1w7fh96TL4BHozp4kG0rWwYxqJJQS938/l6mPg2k9LWEu4/0Qs0A6opx/I1Sz3pZY6N41nGTnkktMiZ1xaquGKcYsii02d05M9nPvHEBPq5Ry9w8Ni5dwmjQBzM3C8xEPtG9x3YM4yFb1PcMWOPvOH2+7ejbN9dOO7ZjGWkz0ds11FjWehYrPFqF1stOsCke9hDun5/BgOZTvBPEAumkZ2mvjARh8aOv1b5zJ0hb9w0BRKqbZdwR2ZeBlL6WcPeRCH0GYAPjbnXl9yrw9cxLxAphZ8A6jNhV/nLVvTSRKzCYjZY9GOg2kLCTmbNluk8CQRAwPz+P0fWb2Li5AiLSndeU0uZ8TBuZbwfjL9gfMyA0Rtvg7XGC1N5bKe4l/DEbp8n7JnZvP6/9bb3aZ2V9PEvadfW52lrkBFQ2er4VwPxzb3P827bb8TtMAlwWmH/mJMTSEXBVeeZ2c3/a9C5KBQLh87/x8Y93PqvT12buLyZhepEIfQZgLYv/5erqLYC+azqvuW7m9ZxaT64ETcJ6LvH86PCqxTGDpYQcGD+6a6/J8Mnc7pmRQK/XAw+GWL38IUgI16gF3vFni8zazPMt27io7LowzbijxJHbrRvNNMbdffv4WZO407bZ3z4SDmq13Gzhh8B7gpTdnvUx7Dl8sz2CbetT11q+k3ubd9TyrFrJ364rS3SPP4Teox/RVePagkx1+hp3s+zZB4/1XwLAfCYResLdQyL0GcGbxszOUN8wD605vQTORqo1JG/mYrZmd5hGLRJqNDIdo+LjebOfmTS7nS46DKx8cF4fq6pc5zU3PVN7Ktv089l2zPNUs0G41JE9WsgE3nK33/QPyA7RfsOBlt3YPqJTn/BNlUN3LKOx+/YpimQCXya1v+0hba2BYF+0u0iaZYLZExIioZUIzApZdw5zz7+ss0Zs+pp3/zo4DnKp2xEdEl8AgLdT+lrCXUR6mWYMEvhqMB/55ksv8IiNT1Jv6M1ciCvGKe1HHw5R24sBG9ATHAeEXAjMd7pYef88yqKAkgqVFxhnc29rRX88a7VpRrsPbzqvJRJvnb9CswFRaGb2FEr3hVss0Q3f7IHTzXYajeZr854AZUmdbDS5ZznhmIjtONfPpZFzPuYlDDbzEuKdNSDYlwAlsfD8K6BuT9d28IRhJ1QwkTat8ZcB4O13Uvpawt1DIvTZgQKAirJvjZgVETKnkMfzpGV8Q0J+oRirMVg/um7UUumKcao+WGhC1vvbfPSF+XkMrlxFf20NhLpRi567tEqkSQ/hsXyFH9MSPOZdkfvKzXW13dSLMzAiD0fap+d0HyfUhON7V25kCtGmke8UsfptjhQzN8LNrIZN1sduXVFGY/f3DfoiRFfqZIrI7289A85DQARVjDB34inkDzwENdI90l2GiVPSbfc18eP/+PPPP3IWKX0t4e4hEfqM4KyZEuRm9vsMvpTpOcBEspmNHFPWRE5Oww4nQxvprgPjpO6NXlWAiMmp/kqk09fm5+ZQra1h/do1QJBp1CI92yY80qvPaRku9IM2MX381jbVx6Dge2AK9nzI0bCEyw8k2rgsDrqD5zx3ZieP39kNot3Mvn/OYhQb/MnT6I3Q5TjbxUvUwkHE57HXBYBJXzt0GHNPfxRcFHA1IIKdiKQieajbWVwg+mkAePv115tZKwkJt4FE6LMDPgOI38TlPjPeNTNAOw9EkUEUTZo60l1BMUMCYCmhhiPIooTTm+v8m0BRFSTQ7XSRlRIrFy4CRJDWj+5OgGhO1mF55JyYLeZmX3DY7ojcU+zkKmrt3f5mp3bVZmPNMVwHd5nf3Aj28o68L5m+hbADtA2E3Y+DeBD3HrFP2r4NCGa8o7+CqHA8uah57zzwCB/1qd2KFuMBkUlfM9v7+3qn5owEciF+FgCuHT++L59ywu4jEfpswTwv+pqzEoaKofn0I4Nih6Ge9lwrVTCUkpBFoTuvedpI7L8kmAIzWY5elmHl/fOQUmoNv5KmJrxn7/Quyk8vsoeOLJ9Thp1cWRv51ylXsfZe+1NbjNIcapL708/eNrbbuVFrt7ZvTltGhX3n7eCSe+fbtvW1cq2Je/UHyCfw+hIZmrgbV2zT157+KLLlIyZ9DTWxaw0dYBIFA0Ti1Fs/8dj8G+fOpfS1hLuCROgzhLfNZwn5NQXDvT5nmMnDmfnITGT+QeykxDWpK6WgihJyOAIUG2XH7KUs8+pPEoRMCNd5bdQfAKwgq9KL5uVoJgwvoK2c6vQSO7bBqhx9TtjeW2XjrCgw7x7Uef1234B47Jvf3ZAGSrkRLCl8vMz1e+vy4M0fVPyn1no1Jn2te+IpIyBTLbka0z6IRKWg5vLsRL608HEAeOt0mosT7hzpJZohnDI+804n+/aIuYSp8R7n2LgqWjYQyC73PnVAnDJ+dNbpZ8MRlFTwWcfoQe47wRD63BxGN25gc8UWmKkglaoFgbG24nA5eV9aeH46sGO7d6Bjm0N4qhpqI4ovk7UEdE/MEjiwiGIT2lfW2wQCpGc1CbRsqoMdgzF3FitTMdBaUMYIo6wUsm4PCy+8CmUKzDSeKxMUoObzDBnyLwHAsauvH1RJLuEuIhH6DMEGxm2uXXsfwI8ynadbG25j63pEBhQRhUtfY4aqtB9dVVVzToy+CxKY6/aA/hArly4DpAvMqK0atQTBedb07tW7HqfU+/c0+Qx7iHHzse9YCLW/WHsEWuShMRr79I7DLoCjwQLaLULW9KF/eOvYCJDsmcI5GOq6GA5Fp7GSZ7PAkI0RYVlh4fmXQd25oPuai8xngFiQBCEj+iIAnNJV4xIS7giJ0GcLfBrIfhMoGfydHKjV56ZiYsLbqPZdR7FIirVBXoHBxo/OXuc1X2PxNUxBhG6ngxzAyvvnwWDIqgry0duvPrpOsjq/vgE9r/oFPJqH8GOSpgs7vSAXMgdfc/cFgIZi19j7oMEEbMZjHSzy7ef+Ru1Cb82wVpPX5+Bo3+Y7aU3pXHu7jN+EywLzJ55E5/gjumqc+xtEHWRHEIUCMkGv/leffuZpAvjMmTQfJ9wZ0gs0YzhZh+5+tfaW+0ZB6EkFtXPQjy7XMJ2uWEEyPD+66bxmtQlP+Te7mfMAucgw3+li7fwFlEWhBYK4UUsb/JnSzp/Wf+yO7m4j2DTUhiafZjrhSzRtrolovXPf+jIbu92mT6i514jfAqB2jLeJPTE811Q8eOy93A2Sry1JcapcZGDRa6oK+fJhzD970rQmJs+qYDciUgpyqdfpzc3lnwWAU6lqXMIdIr1AMwbbeU0BXzeJYqImXvaIEeFEFxCp7bzmlYFVpsDMcGS05FjT4YBYMiIszM1h88MrGKytA6BGK9XJsPYD2Iwjt3TcIbZhkZ9CjJM84uVxOLUelDiugKP9mnr9QcNO7jp6r2O4WJTmNnWteO/5NDISfCEaWPjoq952HBph9EYsQMiF+DKQ0tcS7hyJ0GcMJy2hs3y3YNUXgADreV6XkfEN2E0C8JVA34/O0IFxajQCS9lUgSP1WBBhvqcLzKxdu+Y6r8mt/Ojm6uxBrTvAWC9bfcnOXImm52B6MU78aMzqfoRcC+qBcMVPnKDGgfDmTL9wuyRECAXOMX8b5L18/n5G0K3jHqx5nsN0QyJwMcLCsy9AHL4PXEnYvHdWcA+JQdlIG7Q+8xuff+rwG+fOyZl5vROmEonQZwwmMI7uH9y8BMbvZ+RHxYV6GvtRcEE9d5gJxUtdY9N5bVSYwLjI4e7BBsZ18w6yssLK+QsAEWRZN2qZjBazqeE1P4apLllbT6JtCtZ0mp93cEHBppPnczbPzTfA25Q3FythXojZdEvcCdpueNIgcHM9c/g8IndVTdwcvKxktHsyD0NVJbrHHkLvxFPg0SiwDDjhlUEVQy108uP3y+6nAOBcSl9LuAOkl2f2wG8B4iygWOBbQQlYu4ElQcTTlU/wMFqf1c9Z+9FHBVRRGCXQMxVaLdrsLIjQzXP0shwr738AqSSUrHZgdo99mKg1ULuadH2vmqy8OdT7Tu5/s4jYWB7/Ju+fv8wjI2rhoHtxqTOJnQiXnjTpm4pirb7xfrOzLrk1ipF1u1j8qE5f48B/7x0LpObyHF2ilL6WcMdIhD6DeNfMNkrhq26h9f3tRNuD8Z0zQ5H1oxemsYSh7mC+s9oLOy19vtfDxsXLpsAMo9pOYFzrlVi9h+vfnpndvxcTJRykfFHjSDvSkfcIbX70phgWb2//7yz1kb+irRSAb4afPmvG3cJOb2zcOMdC1aRztEiY5tBcVVj86Cug7hzYlkZukrqoFCCIPn/6NLKUvpZwJ0iEPoOwgXHM9PVSB/pk1rlat3acNCnBbOOZ3RmoG7WYzmtELeRYf8sIWOjNY3jjpi4wA3Kd1+4Msf85vJegsm3Lnm2Rx9OJNnLw//m+9VjoiY4RFElhu8gRuO/2PXim+HHYiQAwSdBq21yAixHmTnwEnYce081aXKqb9w8kRgqcCXHy9OWTz5tHlublhNtCenFmEG8ZE/swz3+vYr4ldAwcW7P1eE0vDL6yEeW+H11VUgfGVVVI4nGRGhIQJNDrdMD9AVYuXgKE2IEffRJ806dvV7dF8ULCchEE3mXOrhbaFrsQ30xLEB17S7j2rwNRbELL0RK2A/Oi7YDTWUrky4cw/9xJU99B1HnoqN9dJsjlPM8zwZ8HgLdfT+lrCbeH9OLMIIycT7+5cfk6wL9nOq8pzeFRBHnb3m4LmEh3VbdTVSYwrqw8Fc/uwMG8RgA6eY6OAlY+qAvM3Dmh+1do79iak7lWXu19ej7MCZlH9b5Tje34fI2m7oQ3n/ib41QXCNJbTYqpT9gCvANGh5a0F0++anzoddU4J4QCgCJiEsiF9qOfOvXOnZq4Eg4oEqHPKM7oOu5g4JsZTKR74KTbHnQwnO2PznWjlmLUtjH82UiQQEdkmO90sHr+oikwo3aYj96CsJm4f3I4USKwRsCxlA3g0wF/4aXTfogWC8YGaGrxVuLy/e31tonIt4PxL0nTXTEh/YIIXBRYePYFZEfuB5dVvc4zuzORKHSjwk//o48/9wCdhdqZLSAhQSMR+oxDAV+xyimAmnQZ2+7cpUw+OtvAuKqCGhZw+VAGYXEMXQI2I8Jcr4fNDz80BWYY1Z360X07en1T0e+mybn+oknPiQKxRjRrCNuBIRRu/E/vmXPtUgkzEDnaY+eYyTHcEdpcHGZNS4S7WdE8DBFUWaJ77EH0nnhad1+DLStbm5KIiSRDLnU6R+YX8JMAcO706TQ3J+wY6aWZXSgAIOCbIyiGfZZGU93JhM1stXSjsVcV5Ghk+pu7jZzjz0aZ27Syhd4cqtU1rF69CiIBWZWQSt1Fs3t0N+QLK3o9kf3uBX555vdxss1MkNMOxrEec9s4lx2BkBkIv1jPjg7vhzMcKNgbv407Z5O+9uKrumCT8YHYxjDuGRBxJxMg0lXjjl29evCGOeGOkQh9RnHWTAVrff6BVHwlIxP7XU8QaNVkI5gpHwoqKDCjClNgBhRWwbJ7GaEhI4Fup4uslFg5fxG2wIze924h0tbZI67gttsc56HRvi1M0G26q+x+N+br2Nw+eVsTNWlCLUgXL/P8621vix8+cQCZPMTtvCBE4KrE0slXQHMLHqnDcxEBYBKlAojEz/zGxz/e+ew77+g/voSEHSAR+uyCzwDiH+DGOgjvhgVm/E7ok+cEq9g6PzrB+dFVWbZs7E4PWwqzIzJ0hdAFZqSEqiSquxYYtwUC86UJFkOtAfmpW3ZC9r7Wh9h13O5Zbycpzz9X3dXON91Pkv90/EGTz2bCunHXsUOONX70ucefQOehR036GoLBM19FocBdIZ493Ln1MgDwmUToCTtDIvTZhjWzf808SK45fHvTrdXQmZVpp+oR+qgIw6iiuCtAa3oZERa6PaxfvITRYACAtZZ+x/no278D33de29l9TV6v55jNzSEalb6mFjvRymP4/hibOeD3Aec6Kt6MCdV7JX0RwO2Mu01fW3jhJVO0qY5z8E0jDMilTk6dvPMFAHg7dV9L2CHSC7MPoBR9VenJmEINbmuTuzsGo27UYvLR5ajQBWYA3zYY7KfN7rrz2vDGTWzcvAmAUBk/+r3BOGYJTfN1lTvfXuwX34mOyAgq481uLnsLnAruFaBBLcW4jAFrxbCc48kPk9wVCePBAIgZSy++ChZZkIsOroPkCIIUCMKUgU1V4xJ2ikTosw3NmLn69oi5IlAGZr8bKcZOu7GS6vLRPT/6qACU13nN8Xl4dEGEXqcH9Ae4dekySJiKcffM7F6biietY387trfhpXPZ2ACq//lpxv5tTy+2Sat+sFxgbje+dY/w3fbRVxdMN+4UO15xMEBEUGWBhWefR37kfrB1ZSmu31EGGDp9TRD9+D/+9POPkHGr7d2VJ8wa0ssyw7CBcUfWb/yQwR+YAjNsLe8TJ/toVZ2PDtMf3QuM88rJWt+0m6OJdD56nqHDpsAMQ0fKb0Hodz7PjztCfN/GseB86nYipWBLgtXQm1aIrc641bp7h7az3oafvRH1RtF9s8keoOZuLWcLroomCwL7HkTgskTv2IOYe+pZ8GgEN/XW5nYAIMmQy53OYsb0OgCcSlXjEnaA9LLMNvg0kJ0FCga+k2mLe4txdIuDAABznY8O7UeXRQlZ1IFxoamW3X6CCDkJzHU6WPngPMpSF5ipqgqKx5vd753JditXQ8PoXJeM9bT4SVQZHGDcuj3Ddvzsk6wbxuwekbD9XWcw1oKSXW73bpjnD3oBeWaITgeLL70KJaVdFLg0TPQhZyQ4I/oyAFw7fvwAS0IJO0Ui9BnHyXru/KrxA9/WBKAnaGU6rxlNvJJBYFwwv3O4IANhsTeH/odX0V9bBwDTqKVl3z0AobYy1PoQarM7NEHVpmUEfDg2Kp6i7e7ydd9dbMfWEC93TKN/+axt7UAuDpEDUo/THad7bO4xCOCyxNLJlyHmF4P0tdADQqJgUC7o9V/8icfm3zh3Tu5YQk84sEiEPuN4r2anr5p2Kjt+pi5cLPKjK1np3uhKISiqwc39BQhz3R6q1TWsXTEFZpwfHXs+JTkib9OovZz2IL0dXvCS70/3OS1aN90z76TYg3i5HycxXpsnM2Z+YkX9venSOLAgAVWMMPf4E+g+8hg4inY3owmARMngXpY98SgWfgwAzp1O83TC9pBelBnHSTMXVCx/t2TVF0SCeaw+2QpfQw06r0kJVZTgygu2DeyrNfsJQehlOURZ4uaFCwCRa9RiffqTtLV7q8G3U4kWNAi2Jo9lJqdxGu+FJShL5nb9dn3rwTlv8w7uLsY5E2LCD10Pjp4p3t5q7uRiFOx2457r2HdhOgbonoCVRL60jIUXXoQqi/pFsrKmcrcv57MMGdEXAeDY1dcPtCyUsH0kQp9xnDWR7vcPbl5i4A8yACDakZ27TugCFCv9CYCVagTGhQ5ns4i1hp4JgTmR4daPPkAlK536Vnn56N71NH2sO7jpHWPSOPhNXDQDWVmFyP4O7e+tPuKWZW2Y3pnZJ/PYB2985Xa9Gw8a62evNXh/Xb1mnOY+sZnZzJO9Hrullz8GiEzninqCovvBRBJABvFFIKWvJWwfidD3Ad7SgXEKwLcyPWkop0ruBMxgxZBsG7UoXSCmKOq5tGWu1xHQOjBuvjeHtYuXMOoPAOY6MG4HNoPdm7eD2RQ11RgC49qsrFeHGmkk1+wTNO+GXIc3X7Ah7/Xy9/FzAPW74WISfJkQ7fLmxDd2eqWhbYGIwMVIp6/d/wC4LHWJZkZYW79OX/vYP3zluSdT+lrCdpFekn2Ad61VmHXnNQBNB+8YxPoYo/aj14FxpZYRArUq0sSgK8bNd3sYXr+B9Rs3tNm9LKGkAsOb0VsQUsVeonmd1jQfOtL1yLEXquyspztyeEw7qGGh0OCGdh6v1x8tY2l87rOR538XQQSuKvSOHcPcU8+67msWbMzuBBAzyeVOp9ebo88CKX0tYXtIL8k+gA2Mk0xfL/Ukm22XFmOFWyl2FeOsH10WBVgqt50lrdgQLUCY63TAg2FdYMb50T3ftB9Zbj5bTdbTNNM3yMv6jAl+5XwArXXPZxfjbqTN6RCLZf5vXwNtsYm0DNi+GUIPrBRE3sHSK6+BpaoDCD3Bh0FgAgsiZFlKX0vYPhKh7wOcM3502Rl+t2JeyYiIKXL6joFnIHUbK6W0yR11gRmuKkBEr4tnJtSFKwndLEeXGSsfnNcCgSF0xarWZp1vOjocIiLcNVU9PtE48oY3WGStyrXibm7A3uJ2MZszddsY+d/D34089CiljYgaR5xxC3srSAiTvvYSxMKiE5QbPimdvgYB+szff/755ZS+lrAdJELfH2AA9Gvr6zdA/HsZYPzoBhOmgYZL3PjzFGulgZUClxVUWdVbNhLS7WmM2T3vYvWD8yiLAkoqyKqqa8I39kH4fRvXevexHS3UMzHHg+Z9JaJ4t7CASHRW32u/t7hdrmjbT0s9Pok3NfDQ3h5EL+z9YNw7EEGZ7mvdRx93Znfn1ahfJFEx1HyWP7R4iH8cSOlrCVsjvSD7BGcAU/kV3xBae9TWbbvBhEnS9xrb8q4KdfqarCqdvuZHNvk2d6ulky4ws9Cbw8aHV9FfXQMBqMoSKnYsE3npYXDHnERuu6+etLNwoGyaKHgrjPjFaQCYcqntZnhCHYqw96rXTlg0Tthri1k3ApAfe0CIrBzhYRqu+rZld3jld3fn2zylrJAvLWHhpNd9zdyn+6PVph81l2XIhPgykNLXErZGIvR9B/qKmRRChdfPTYv3iH4rVpDG7K4D4yrIsvAmaIuQ0QkEAWCu24FcW8Pqh1cA40e35S79M9rJyym8FPqi3VmmSmNrprEBCIPjGI7UOd43/tYMoJ8BjDO3x35zaCHNj24PHOh2vMLjuWA5TwC4Z8OzFxRJBGLG8suvAlkOmwJgx0a/NwQGRMWAYHz+DCBS+lrCVkiEvn+g/ejANwsoJiKxLfZGy/TMCAvMmP7oXMkJk6teKkigm3WQlRIrpsCMKittdvdzlB3bcUjq0RH9+uHTgVigiZf5i+p7qyPlrU4b+oz3V6lzCj45IG6PtfTScBfU4+XLoC0hdpNGf6pBRFAjnb7WOfoAVFn3Swj/EIgKBWQkXnrmE88/m9LXErZCejn2Cc6aKeBGX/xAMi5n2po7tjNKm5HUgsG6qAzY+dFVUeoCM4AjYzepenOyIEJHZOhlGW6+f15Xm5NyTOe1dnuzPrzuZ05EAdntPa9bpqkvivwcLITmdfK5LfaTRl6I2Yex1FD4u8akAAmf7AHYfgLcstq4NYjrd2WmagK47mvHMPfMc1DDEQL/k/ujImKgWu7keQf8OSClryVMRno59g/4DCD+L7iySeB3s8BD27LxpN+sze5OS1cKqqpqTYJiBz3qedgGxnW6WL94CcPNPlyBGTVGvmA3M9czN/ur2Et5a7/+XUV087653f1GrZUSI2zLagjfVf6cCRbaPsbnp9fLKcivsDZ5TyePS8aRLyjo3HgGQuGKJ4oMUwVmhshznb6mVP3KN0wQRAQBQdqPfurUqfHtCxMOPBKh7y8IAFCMrwlg0szqQNGnhtaOJDOUIR/2AuNi7d7vqkUABAPz3R5GN29izRSYqcpyPKEHF+NFRnsztDW7zoZp2kR4WwewU75Ch7m9p3EstM94PoB7X8j7xf5b1NzYrxEfW25mDkZLX35Rp69BKm1xAOBJKmCY9DWiT/+jl0/cR2fPqhmSWxJ2GYnQ9xFedFOf+qoEgyY0obZ6URtpWN912HlNus5rbJuZwE/lqs2tGRHmOl2gP8Sti5d0gZmyHGN2t1djj+FpcS6aitzq2fCbsucDjoPojGrubplBUWS8x1uBsLQ/4L95XnndQLSMTD/uo15n3wUyP/Qab92UDxq59LUT6D12QqevuTKw9T8CUcWsFrPsKHV7nwaAc6dPp3k7oRXpxdhHeNfMdlKKb4+YSzAybFPRa5jgWdd1N9MulFRQZan7ODci5n0mMgVmhECXgZt+gZkgMG7S2fWkb3nQGWanm8UjeMKO19Et6OwWuw8833u9K4XbzDTGp1rUFnYeu004YPX4+cKAn4gx0a201yACS4V8aQmLL75s3Fm+H91acRgAqa7IkDF9CQCOXb06U38JCbuHROj7CDYwblg88SOA38/I6ooh2jTztlQxVwKWAGbjR69ky9bRsUyjll6e49YH51GOCt30ZSyhx+D6nzX5O42ltiBMuxYWo27yEhJb0FO8xQeyf2bv0ALTWAWg/W5b9qPalcHmv9CjwS7RIDz+FqffTRAApbD0yquAyOpYjMCPTgBIp6+R+NwZIP9sSl9LGINE6PsLfBrIfhNfKxn4Tq51l8ZcFc9x7ZMZ14FxZGq8Gz86gFDZCiykeiIVABZ6c+hfuYrN1VUQMDkwLoAf1s5NkmPPh+rIflrZXUsk7P1zZnfUZA6E9+Bu1Te/79o17wW2f3dk/RMt755b7wLtIo7k9jPthdCku68VWHzueeQPPAAuStQvtec2IBIFgztCvPDkx548CaT0tYR2pJdin+GkdSuCvqI/b9PkDhg/OoNtVHEltWmQFZqBS7V3WxeY0ZHucm0dq1eugoTQjVrUdpSL6Gq8yHef9Pz5fEK4wB7DJ+lIUPHXesHe3urAChvGj+0Heo9uGsB4uq23bXsD/LG1GnpIit6O05LjRgRVlug98ADmn3k+KAMbpOnr33Ipz0UXnZS+ljAW6aXYZ7Cd1xj4mtST2pbPuG1aBSyhK62hWz+6qc9utkBIq3DfBRF6eQeirLBy/jyYoAPjqnGBcS0X1byi4No8RbexxTQSHreRuyMfhinNB2dI1lJVMLy+ANN2h1N42xNg7zXOmxi3nVnfcpOhxT4SlryttKXeBJ/tIqOPPRMzRN7B8quvmUYtvh/dE1dIEIOQQXdfO/XOOyl9LaGBROj7DG+ZYjIDlu+OWG1mRGK7WnoDzNrUDs01SimostIFZgyhjDNhCiLkIPREhpX3z2sil1KXgVXbuJxJPtWWXK9YEZtejV2j2UDWgoKt/OpyOuYwZPdY2ZzNHuNNgVCjTXuP18emjTHHZXZCkPO5x5vfIRrH8haMfRsFgcsCSy+9BLG4pINO/X3Z/Y2JgoFMiE/9+itPHScgpa8lNJAIfZ/ByPf0G4Obl4jxg8yqLC1azfiYY7OcDYmzreuuA+PYdV7z0q+8/+splpCBsNjtYe3CRQw3NwGGJnTeiXIRa3BoarHWvBrt5TadKkyag/U9EUUk5caVQ7O9PVxtlo13mXFMIne7PrQSUes+9TuksyXIk3zu3kA1rrAtgKVlL1UUmH/8CfQeP6Gbtdiqze62tIhaMdRilh0+hOynAODN11/PJhw44QAiEfo+xFv6uTIEvikAEFjF001LMHUL2PnRFWk/uqokZFWCjfnSV5r8uZGg27/Nd3sYraxg/cZN6AIzVa2FbBvRtNjo4EWoq3K0bDpVmHSRRhsPiLkeXLeYrUsh7MBjS85yiww0e2jTzre+qVqkbO5XByYCNnizISDdZWx1dCICS4l8aRGLL70MVRTBXo7PGQBI5SJDLrIvAcCpe3LFCbOMROj7EO+aGUEpGxhHwczi8/CkaVLPe6ouMAMGKwlVVi5Hvd7Y6OiGeAjWj54D/SFWLl6sC8wodWc+7ihSnGO7Pzc19vbDTIka23oZbQut+d2OcC0AaDJnt9nM83l7hEDLstj/HkS/1VHjwba1Pckz8NzVK90RiAClsPzaa0CeA4rrzA3P8kI2fY35Z86cPNn97DvvVNgPjzrhriER+j7Ee26OkV8vNJ0Hpjl/ettqNtBmd1PTHYCSClyUYFltof7qaPeuyHSBmfc/0MeRFapt56OPObKf0xUdhm2aG4XTdxvnT4+fncd8AqEtxaa96e9+IT0/mns7cePjrmD2EDuqo7HjtjEN92fDmvEr2WYoCX5vdejtwqavPfscOkePgUuTvsa1MGL96CWDO1n29FNCvgI4a1xCAoD0MuxLnDOBcaorf08yXxeh2rKl79wHw5aA5VpjdwVmwi2DMmekNfQMhPlOB7c+OI9iNAJMgZnt5aOPuaZA4WpxHHs+ZT+NPcC0cHkAL8jL2NJD46sxEmtHcEucgCF974ixBSYgoujMM4+xb3jb3ZET6GrBjj3Bj+v3qO1chm/9ynT+deyE48l2X3vgGBae87qvgRE2qSEwQy7mOXUEfQEAjr3++r54dAl3B4nQ9ycYAP3K6uotAN/N9USv/JU7ORIrXWCGieoCMzYwriEd1EcnS+jdHgZXr6G/tgYQ7pjQ/WvzTuZdT6jBtk2644SavdVUPUeIsQVzQMl6ne9i8HuMB9blMWjE23lnnX3U1ovmcgufvPX2HEiI7dp6HEPnRK8gKLS2ENEOLVDMDNHJsfTaa/pvgz0N3X9ARDp9TeCLAPB2Sl9L8JAIfZ/ijDGzK+Dr+iGHrVS3Y27X8APjjMYudYEZNyH6E2ZkAbWNWqq1Ddy6/CH8zmt31YXdYv5kexHk+LEx1cdjEIdT7T7ankroJCErsPjbO429PfjRP1KbBj9bat6Eq514I23mmojMg9HggFPtZhMt7VFDocZ23gMI/yB1+trySy8jW1oCpBGYfQ2dAQaJQjEE8Mn/4tlnHz0LqDNpHk8wSC/CPgeT+ooR4W9rztZmdtbpa2QC46QygXHKmwdjtY8N9RB6IkdWVrj5wXndZaqqdF76XaXMiKaiIMCa0Z1BdUvtfG9IbtKYGA3d+VU5XuWVw+XGPfrapcVYfptqTLjIQEocY45Ac7FbQdGrHEmCFG7qXik/0iG+nOBw1H4JJATUqMD8iRPonbDpa6ZCI5P37IgUSC5l+WLWwU8DAFLVuASD9CLsXxgez79ZMEsTGOeUVmD7c7cldEsQSilwVYbpZ0HB7HqxIEIuCL0sw8oH51FVEkpKVNIIBPcKvvXamaXD2ZrCzSIbxrSCQA3G8Z6oISDnH27sHaJhJZktVX0LeM+9bRWABoM3Ai3r/R2p+ub3yBTvzlrLjoE53jfTx5fCUiJfXMTSy6+E6Wsug8S+y8SZyJAL8WUAePH48Zl4cxPuPRKh71OcNfPExc0rf6jAFw2buz/8ncwAdiKp89EVVGnS1wBnhmTYoKK64IsAkDFhodPF+qXLGGxsAAzI8i750SdfefvNmM+6F7felKmp1W51uL0Ax1qoUw/J8FMzYM4KNZavLOlMTaD/rmCMeMPh74blKOD7mqX9sSPUVhG3S6zto71cr9skSF/r6Fpw7sTeMYhEqRhEOPWLjz02/8a5c1u3QEw4EEiEvn/BZwBxDhgQ4TsZEchjgp36TW3nNSbTVlVWNaFPBJkCM12MbtzE+vXrICLIqnRa/+1hu1ffPANbKcTke9WZbnVUeaufdIxmtbtocRRY84IrnMI1Y0f+d98s4b7erqS3Z9jes/ej10N7TIzWp12fyxbxMSzdzJY0oYvmfSJ3Og7G2QmO4y8YXIyw+Nxz6Bwz6WuBNOG+iQLguSw/cezw4seAlL6WoJFegv0NAQCs8FU9ydyeUZnBup85K1cxjqWCqkpAqTano/5mJjMBwlzeAYZD3LxwESBTYEbKFpvv9q/qjvexNlOyVoWwZMsYY63D9KhEjDC9yQeFQ2w0yyjNuV49PTc1Adt79hzfeIBJBN8GPxreN4HDvf9sTR6RxcRtbDX2Me88EUGVFXoPPICF51+AHI1AfhlYe2otkMr5LEMH6otASl9L0EiEvo/hOq8Rf1UCYEvwt3EsZnbV4XSjFlkHxjVU13CiFEToUIYuE268/4HW9isJKbfZee2uIprI3QRbm1+dOXqXr2xnaHjDW37X90peNJcLq/MlFqs5sr/dfsZ2785n0lBwdWMajaOL22DfeG+bGXEd7NZ6OgZlGZZfe03/vdnjwRMgYIPjAIL4IgCceuedndZTTtiHSIS+j3HSzEZSlr9bsBwKW+P9tsCaxMFQID3Z2AIzWzAfmc5r83kHqxcuohiOwMwufW1P4duafW1q0qaYBrLb2RU4NwM4uFVfY4fZJEqIC84YjMHeD8KOsbPqgGYc/MHy4N+/HbF6W2PnsYKSbw0xWn0z0J4BEuCyxPLLLyFbWgJXUj8PO/jGjM8gUTAghPjY/+n5Jz5C0C62Hdxcwj5EegH2MWxg3KXR6nnF9IeZ1hI8HWz7cCVgnR9d6Xz0qvImqpajkja5CwALpsDM5q1VEO5igZkdIdS0rF9UT74eqwGtWlSc+tWmF08PYsbR7B34lr1AaqfEc/MIvivCHZKm7X63RiOgMABF32vTenM7CrZj5ro5Tn021OJRdFwXue69Y8ZEz6MR5h9/XKevFaOGEGJfQcWQS1k+l2XdUwBS+lpCIvR9Dj4NZOcAyYRvZQAIULdnSrYFZhSUIFPXXYKrShtwCaEvPeKSDMBcpwO5to5bH34IEsL50Xff7O5NuV6ltXid1bD0dnXksv3dPNpemOm3c0Yb2FVreuz9dmTkHc7PAGAGyOa1c+PIW2J6Sd8X7uKAAvaWb3WXWkiqx8a+T1GKoZGYbPvWIMvCbkIEVsqkr70MLmxdd9QPqJYAWBAhR0pfS9BIhL7PcdLMF4L4K773uCUeaiIYWiuXSnde04FxpmJcmx/dMYf+JUg3askqiZvvfwCG1tB9Qt/z2SgwrZp/3vzJPqPF8zT26vonnTW+Mn1PHlXDau1sorNruSy0YthO7LeT5rbTd2130SbIAZOf6hghMBgbq7nb96berC7dq4UFP9ZOLyZAKRz62Guu+1rj2rTZXpQABNFn/t7JY0tvnDsnufmHmHCAkAh9n8N1XpP4Wolm57XtwsX/KHZlppXSjVpsgRmXfx7Pkcbs3iGBOZFj5YMPUJYlWCpIr/Pa3s9E4cRJRjOyROaaonDE/Xb7XbrK7WMcjXLLT3KKvK1HXlek0xs1C6WMp7sY0zc2W2Gctu5/1usCYa+xP1rIvt6urgfvCVijERaffx6d48ejIjP+oUlUDDUnxCNL8tAnAeBcmtMPNNLD3+d4y1SMK/L8uyXzqu28djsaE8OUgHUFZhhcSahKuhSo1vgh1uSYsc5HX7/0IYYbGwDuvPPaXUUwKOTM8XqujoQOT8nyiW4cye0+2ig0Ni+T9529SmZUC3COy2rCt/fuZ2UdHPiM2iT25tP3fDbG3G4iNIK8dsCOu5YcVaXT1xaff96VgbXjzvUXMKDmsgy5ECl9LSER+n6HNc796saH1wj4Pd15TZP8Tv7yjZKmq8Sx6bzGXAfGAbANQupq48F16MC4ThfFzRWsXb8OIoEq8qNPBxlG8OZk9ufyoOCIWTw1JLcd3TlQ90CwqVUN2aZeaC0VbUffwcObyufcijbSjn+PC66zg1Xvp4Pg9EDa2AUtKEXvPzNElmH5Yx9zAi+b5QiejxASBAH6AgBK6WsHG4nQDwDOGDM7g74urHpwm1DMkEqBBQJCr+uye5MXEDCgAKGX5cBwhJvnL2hNpKygpBqfl7sXiBjLT+my8GnQ/z1V9zEWTSIKa+RZySWMyA5qprQcMSjMtgUm0eR0oU00bduGvH9cb+fGrmU/IwCTt54AU2mOoGz62vKy1zfBSgDuyqhgIBf08n/61FPPEFL62kFGevAHCvyVlpiunexvil0onYsOgJUCl1s1WtEntX70Lgg3PzgPpRSkrHSjFmvuva3rusuICuPU9butj9Ncp9G+AnoMTKPTiibz1s6F8VTrtHeug73G+st3cPNT8cy3jXEE3/bE6zejtl5EUqEdT38vE6uhRiPMn3gc8ydOgIe12T3Yn4iYIZeyTne5m50CQKdS+tqBRXrwBwPajw7+5khPLdlOycbztGo/OhgsdIEZVVVQUrbYYv2IakAQkIOwkHew+sEFjIYDgI0fnbmx17SAAhXdaOQ+o3k+dBPTND3CyZZoU6tjC4WzCwebBO4F32Ts3bwj/eiRTtcTvhOMI/GQef3iNIRg4MwH+x8aNn3t1VcgiwJkp+tGziRp+xfTlwHwtXfe2T/Dm7AjJEI/ADhr/uy7/ez7Cnw519NLIxlmu7CBcdqPbgvMxK67UH2zZsUMdYGZjZVbIJDuvObno4/R/PYKYQ1vjmZds9yqr+DgPqKtpgSxmhevC8mdubnMapYAjC/Yi8L2DuVIP5JupkPYuRtXMe4Y4XIOBFYEbgy7fWs9BpO+Rp0OmJXbNhAkiUQBQBD91K8888yhN4CUvnZAkQj9YIDPAOIXcWUTjPdM3tqO+nCw94W9SHdl8tHZSz9r7muNucaPnueoNjdx6/JlQHid1yJ3wO4XnLkdaFU1yN0mcvfsc/t2x3s67tr3B/vLQrgCNbDE7q3DmHuZjhvEji9k238wkR99YpBctN4IjEQECAE1GmHxedN9rSjNPhz8PRJAFbOaz/Ljh4GfAFL62kFFeugHB/pZE3/VNofa6QHsbsza7M6mEZTORzcadsPPF6rbGRF6IkNeSdx8/zwA0gVmjEBg+cG4Ecdib7k+8jNbbZU89mZ7E3U6mF21k6PvLVqu1kW5hyJKoIG6R66L1QT2jTEm+JnAjqWTSEIFWl5cav1qrR5s09c++gLUcASQNbvH5yLVEwKZSV97N6WvHUgkQj9gUIq+qnzH9jbQFtGsTMU4RVpj56oCKxnt0JzsCEAGgbksx8oH51GWhSkwI51JkTnWbFquaVemq/gk42jZV8PbVFRqWB/06rpl697zW9tTjuEJL+Z3o84410ooEbn6BHaPoHXrFmebLUyI2w9cNvX2tWDkuXKIwt2YIfIMyz/2Glgx/JclCEwkEhUIgujzZwBxNqWvHUgkQj84UOb/3yqgStKBcduaR33+t/4/23mNyQuMq9oC4+KjEHIAi50eNi5fRn9dF5ipXIEZ44fGNEzyY4h74i7h5E1e5FjTqmDM9ZgGrXz7o+0HCUYcFMoz1jJhCd4/xu1f6BRjZ06s1vchCjwEEVRR4NDLLyFbXjLpa7EVTG9YMnMOevEjTzzxHJDS1w4i0gM/ILCBcZuja+8rxo+sH337R6iTmhjQJK50pLvOR1fal+5rq96+zvpIQAbCfLeL0c1bWLt6FUS6UYstoFFX07Jm2u0Q6fbv5N7Daq5+9TUY83t9Tz6Rz0S4AICQiIzw5VXRq4vv6LelLpPbvMHYOz8bYzBJYN3pDTRGoGmeJwKPCsyfOIHeR56AGo1qqcmdUuvoDJJLeZ5nef45AEjpawcP6YEfHPBpIPtNoAT425meOXZcc9Vp6KygWGkNHQxWtlFLrV23TtCsk296IkM2KrBy4RJAOjAuqBhnXdKs03wagdbNw04V/LxjHRvg+ZytOdo3RZvl3scUwhOz4ibqpkiKT2yOd7xnGpiJ7bh4PvdJmI5xuVdXYd6P2G0DuO5ry6+8DFWUrsdAvYF7DgQiCJF9CQBOvfPOlNRUTtgtJEI/QLCd1xToK3fKfzYwThFBEaCkCYxTKvQDuv9paAu0KTBDhBs/et+kvtWNWuzk7nEiAnW2BXvP55N90OTMqaFk0uaV3/t7GQf2WRrkuxcaDysS6FwmQH0IAnl+9qY/PoazANzxfUwrPOd4DD99zQjNwbAzwESiZEAAn/71EyfuI52aOr2vU8JdRyL0AwTbeY2Ivlrpr7f//I2ZXRG0lm7y0V1gXL1hYwIWRNrsnnexeuEihv0BoFTdqCVkgiDfeXq12HFXxNGnJjy/oxn7q6YdcT41gMnCTC0ExO7hUJpp3nzriI4Zo+l7H3aCLR486fS1pReeR+f4Maii0IIQ4Exh1qNVAWohz492e/mnAeDc6dNpjj9ASA/7AMF2XhPM75asNgQgdqrwOB86YHLHTWAcM9gGxrXAmlgB40dnYL7TxeD6dWzcXAEReYFxwV7uq19ha/q5LzKb+nndMZH51mvMii85Riy41N+psU0TsRU53K/ee5yhZvrfh0nQd0bBy+3dKUGnrx17AIsvvAAeee1UYd8tC1JdkaHHpvva1auzPTQJO0Ii9AME66H7O/1rVwD6Xh54bnd0HG3iYwWpFJQJjGNlA+MQkVa8v/GjdzpQ65tYuXwJEDowzvejh5e3jYKwU0WErQEE3ocX+u4srRxtbWumT8uNjYtTn3B9xgphTeq+X90F0Pk8FspwY88+e9jq6r0ehbXq7cidle6+dujHXtVCr5WA3J+HlYhIVAwQic+9BWSf1elrsz10CdtGIvQDhjO68xoz4Rvm4W8ZOBNEY3vLdaS71DXdyRaYqTw/uj87h4QsQOiRQC51gRmGTn2TUQlYfQHkyGBccJxPDNMN8pirFlysLmuj39kEA+rYM5oSWaWpfW9rl/A1cNXR/JQ2uy237OMWTSD76cd2rzh6iY3HggRBlQWWX31Fd1+zLYubhxYlgC6JFzaeeuokAD4zI38ZCXeOROgHFJLpK3d2hLpinM4eJ10S1gbGjdvLKB2CCDkI83lHF5gpCrCqA+NqaBb3q8jpyb1Ol2I0AoPhVkwdGLFNPdBMbUvN2y3nN1UIfQltFgh45WLZbG6VTZfKZt4ZXymdlDw2u4iEYANbgVGNSiyceBzzH3lCm93bihjp96dayPIsQ0pfO2hID/qAwQbGKZbfKLT3Ldtqn4he3f9t5zUGoAR0XrqUtdm9Xa93BJwxsNDpYvPyhxisbQAMVFUFOUYgqGu01D5HP1Buum2046imrfmJp8n6Od738vLuClq83rFw5pinXl7fay3wuaQA77DRz8apxq6bGWzxhJVEvrSI5VdfhixKEInmLtr6QQAhE/QlAHg7pa8dGCRCP2A4Z0zsPODvSeYrAkG57VZM8pbqRi0KTEITvJS6laq/zRg/emY09OLWKm5duwoyfvRw/3ji9wkuZPJpy0XfOfwnUaulPpG5O95zv/rtmESi9caVYgnelYX1hLSgCt2YI86Ou+XOwAAgFQ59/GOgPDeuraYbiqG7rxHwE7/x8MMPnE3pawcGidAPHvgMIH4VN9cYeC/XvsyJEnyL/mg+GKwYUintR7epbJHZnKLd7DJBhG6WQ4wKrJy/AJBupRr40f39fXI3hKeryhm7QeCr3WvCuw2Qr8FSrbr6IQVsLRztfvXdu+u7cCbjNrH91mvBxbPssEfaHiv5xWnu4hVNFyI/EhHp9LXnn0P3weO6+xrXNiv3d0pEElCLWX4k6y78FJC6rx0UpId8MCEAQBF/TVCoF7aBon8+bFEYFuQ1apG19gB/4o2idwBdYAa6wIw0eeyyqqA8tav94ihQyQMtjWsfdL3BpDvcS3D0NXZTGFuEYTWK/KZT7WXYElG4pRNcPLs7ef5zT8Zxe/sFa3bz0ncD7kbJfer0taNYeOE5qFEBCDKCLNfBB/o9Uh0S6ArxJQA4lrqvHQgkQj/AIEW/s53Oa+Nc1FaL1I1aEBWY0WVhW5nUmc0JufGj3zp/EcN+H2DdqIVdoxZMiHirNbjgTD7neQrv9MOqoe336ywRgCb3cK/plVkaCK/cuVGsud2uQpS2523nb8v1KoftjsVMjJlvhVAMkeU49PGPmSJMbqgczFsiKgAk6Gd+4+Mf73z2nXcqJOx7JEI/mNAm9py/NQJXwqSyTdphHKkzYPzodaMWGxjnbxXuZ4mJXGDc8Np1rN+4ASLTH93fvxEVHhfhgBcSHWlxbWaFXcEOTjqx5GnkZvCWWjnFRsm3hSBOBSj+4qnYXiR8Xe+evCHRy6xpPihAQ3Vb2nGBc/5YtH2fCTnPh0lfO/Tqy8iXl4AoXsURPEEUDO6SeCa7vvoSAJxJ8/2+R3rABxBnzd/8+fXrP1KM9zPtv9wRDxjdCoDJP2cFFsLzo0tElONZ3WtNSxDQy3Nwf4CVS5cBElBlpfPbx/jB2fxHbkLnhmbXuNi249xT5tvBwdvUy1aSJ6exkkdFdnMryEwdSfEYUcOZimOqZVcatw6a8xr0uH/cMLe3OSywxfdZgvajF1h44gTmnvwIpEtfo7bhlQtZLjKizwMpfe0gID3ggwk+DWTngAJQ384muarbdkaoGTIzpJRQgozGLk2BGQ4058AwbFYJELokkEuFG+9/oKvPyQpVNZ7Q3XVEfnkynd/0d29D35Tr3cQWvUD2ED7JRTkGVJuZfW1Va2U1m0+Xln47V0Pu3XIvGrxqauQFBkYywVYy3XSNzW1AKp2+9tor4KIw6Wvh3xaYQGTS1wgpfe2AIBH6AcVJN/W7zmsT57nx3KdnU6WUjskRpL9Lr8BMGMcVnElAF5hZ6HRw64PzKEYF2HZeC/LRm1dAwbfa/GrbrbpiNPAjp7e8oSlD/Fhsqpe3xs3lWk2f9CA5Ir/pRczQ8CQwDrX1FnP7JGFtZh79GDBBp6/92KtA3gHs30ksxJBOXxOgH/97Tzzx0NmUvrbvkQj9gMIWmJHA1yo9EUx8F7x50/3WsOlqfmCczUdXaFMZdTCu1aRrP/rGh1ewubYGAlCVZVRgpslCbUss2ZH1z8LX8vYBXIU8dr8txpmU/XEK2ph766eX4z1jemS1YGsm4nDL+F7id3fWYdPXll94Dt0Hj0EVpReHEL4SiiEX83x5kTufAYA38fqWhaQSZheJ0A8oTpp5r2T1uwWrzUy/C1vO6+T90zCRyKbzmsqECYwz0e52L29G9fPFCbrl23zeQbW6jtUrV0BC6LrurX70cRHv5pvRUG1NdFsLfStML6FNAIcD2eaKt2Q27v4C98lUwadncweBsBZEZ4T3z5ErIviyD0AELkv0jh3D4skXoEYjgMKp3FXeI3CHBMhUjXsRx/fTSCRESIR+QHFWR7rTrw1uXAbT97cKjNsyalgxpMlH141aJFhWaBzSnaSmkIwIXZFBFAVufnABIOhc9Eq2XFCbb7ntypqFV1pS4Rv3N3OwQWN+fp71PQP1eI+xtU8axb1Fy5vmZTE4QTJgbnZBgX6QHAF1MzLvyH7V4KlGi0DKDFCe4dDHX9OxKmh7vwkEIUoAGejUrzzzTO8NnEvd1/YxEqEfYJwx6WoK6psmMK41aGbcpE/e/13+ORF0oxauG7UEgXH+ETQECB3o7ms33n9fB8RJhUpOavSy1VSsZzffl753KWx3E7G9vMXATMb1wB4XEMAtN98Ug/YKOzmzuVIKl9UR8THRh2cg7wV2guo0M3vbxQkCFzp9TSwvAZXH06F7S5RM3BHiqbmhfAUA3krz/r5FerAJIPDvTAykCraNp96aOJWSulqc0BXk6sC4ePKF20ebxQkZExY6XaxdvIRhfxMAQ5aVLp5x2/dVT/AUT/RoigRtJDB9KtykCzJtZpnqGDnYe699rOEe7d93HzsdaO9heTxWl8QNs/aDe6PgQ3+fqbgC60cvsPDE45j/yAljdo+jT+3GkIsip06WfwEAjiFVjduvSIR+sKEAoEL+jULP9K0BM01ze5umZwLhmHU+ulKuUYueHNtDljTVEDKYAjPXb2Dtel1gZjyhbzUnEeJCLPFeseHA12a3fZo9RdN2omMIjC3Z2KTZZzCq4wzqvWYNkSbq3Ox1/jqo7rfOXAsz4zTx4F2JzPbTCpYK+dKS131tjFRCRIoIOfBFAHgbKX1tvyIR+gHGm2ZKHMwVv1cxX8vQ3nktJsNmYpSx1yulU9aE0HOJIXVnBvUPGJlCMwC9TBeYuXnhIpgIsiwbjVqaV9WG9jCwtsOESs2sUds27Sq+s1hP8KF4VbvbZ2AE/Gfri5hRNHzodnfb+9WI/WGxqY5A/U5M/VgQAKlw+JM/Bsrz+oYiP7rtviaIPvH3H3/8kbOAOpPm/n2J9FAPMAi689pvrqysYkLntTgFqlXXNr5qV2CGUDdqsSpPvENwDl1gpsPAjR+9b1LfKq9Ry04wbnuuNVRfXXObT7tO5uM2rtWrid4WEDYdWulWV9AuTDaFPj+9j82jdzHxdf34La4kEEKnDK772gvPonv8mO6+FkgjzjZGDMjFrLMI7vy03iBVjduPSA81wb4DXxO0dQnYhskaQO1H1+lqTAQmXWBGRX70UIGoJ1WhTYJYyDpYOX8BxXAEKG4pMHNn8HU69gu0TOGEPRkTLnhcMxuvjGrQZ3zvWdzDDh8ENYk8XO89Y6q3IV8QYGe4aB6+8WWK4KWvLZx8HjJOX2Ovkh7AGRFy030tpa/tTyRCT9Ag/orSuduNOWwr47YD685rDGgt3eajR4TcFjUvAF1gpttF/8pVbKyuAgCqiX7024BfB903zcIEj/nW3J1a+qcF4x3FcGTO7dvNwu0FaL1gqv9ZTZx8LZ5CAm+J2ZyVcWBmZJ0cRz7xMbBs/p24AEnTfU2ATp154om5lL62P5EIPUEBABN/cwSu4AXGbaH7NMCACYxTgDAFZpQEVzLYu93yThAgXWBmbR23Ll8GhICsJvnRdwpPW4vCwurKcuxv2naZ04UdqdeBPQVtaU4TuD7edAphidyYmv34COdtqCU228EtttDwpAGYMpAQUEWJQ6+9jOzQsktf85wNZkMSJcBdkX3k0arzGpDS1/Yj0gM94Dhr/ubLjft+yMznDZs3RP2tFFe7UheYkVCZMATvV4yrN3STKOkvRPpl7IoMeVnhxgfnAQJUKSFldZcInaNPfSVkfQEAAFsHPrxPz1o7XZg4LmNM7+yTeV1Zj729xskJ0ybP+Gho2Q3J0Sd8vYclb8vhtl5BHDEeiH+8xbDvJojAxUh3X7Ppa03flrXOyIUsRydDSl/bp0iEnsCngexX8fsjBr6dk2HYCFtnctU+SR3pXvvRdT46N4z5tWakfwsQOgzMiQwr759HVWr/uaykq4Z1L2DbsdrLIZoQIBZr7tMysbdikp89XE8m8t0V4kHMB80cgGm797arDh6YFR7db66llwnUFrcC8OvhT8MQqEoiX17Codde1nXdRXswAINIARAQXwCAU3hHNjdMmGUkQk/wOq/xV43+MtEz2VwKOHOuaczCIE3qrlGLbGxbQ/8WIGTG7L528RIGGxsAM6qqihq13BvYqOjAGsA10behLfV3OjA+wiu0SAD2nrUJuiZ3+yJoQqPG05uuYLpxiJ+lrmSoU/dIc7pvmoC9Z269z0mFedrW7wqIAKVw6OOvgTq57qnmLgiwdW9Jm90hCB//zUefecxmuezBFSfcI6SHmeA6rynQV8d1Xhs/T8Uake28xobQ64pxW811RDowbr7bxejmTaxduw6YfHTV2qjlHoKsVkrNW2z7Xu82JWi5OOtHHmdOJwrNyVYAoNDMPO4ep0OYGf8EApGE2bNERD4WEzgZpK21Hb3thvdAcyciqOEIyyefR+fBY+CyBBpCm95UAnJJ5AuC5Ot6UUpf209IDzPBdV4Dy+8UUP1xnde2nqTI+c2lVOAs0y1VFYNlGBjX2hoMBAFgLusA/SFuXLgAEqQ7rzX88HcLbQRAIXlRU4tr23U6CG0bsPnZngvEkrlvaXHfEZqZx2E6hBnPjdBYE5vkfUS+dWup8V0QxoLveL+FvCn63BWY9LW548ew+PxzkMPR2A6DBOKMBHLKU/raPkQi9ATXee3vDm5eAvgHcee17af02AlQaY3aBsa5fPR46gs9swRtdu+afzff/wDS7CsnNmq5E8TXVEdJA8ZayeF18pjdp4PQtoLnOOFaY62rpHnE5qnyXk2aifXwpwM2RmNsJES9ZZDdoD9de9b6y9bhCC3YzbFhZlCe4/AnXzMNkWJpw92LNruDXv/Fxx6bT+lr+wuJ0BMA6BQW0lz8DRNT49hzotmxDdaPTtBdoazZnZUr5hJt7s5k89Hn8xy3LlxEMRyawLi7Fek+8cJbFrHxKVNIZNZEO3NTYZupwS63ggsFi23cWJtIs1X0/94QPnufkx+SjRvQZhj9ad+z+H3z+7ADaNa0ibDV2NxVCKG7r732CrKlJWMRM6f2DBMMmPQ1cWJBdn8MSOlr+wnpQSYAAN6tY4B/J15HwDZ0HbgtFDNUVWlzeyZMYJyKNOxwlrMaMJFu1LLY7aH/4RWs37ylG7WYuu73Hi0aO1tlVZM4sV1nJ/5duKy7Aj+src38TB4D1J9OK/eC5hpbjXE/TIe8M+YBBf10Obp3va4OgPee9dZyQnQe1PveI9jua4tPPoH5jzwONdRV4zwbjDk/ASA5LzJ0BX0BAN5N6Wv7BonQEwDUgXEE+fVSV4wbW2CmiWb0um3UolyBGQUlVfNo0U8CIWNgLu9Abmzi1ocfgoSANH50xbvdKMrmzHPDL2kToGYj2huYGMXVtjy4Ma8Ii9si0ucj98N0Czrk2DnUxH01nGthxlPPGWwDx3d2xuafyV0FS4l8aRFLH9Ppa6Hg5T1LAikQMtLpa2+m9LV9g0ToCQCAc8bEfr0rv6c7r9XO1LZo3yaiCGKldKpZZjuvSW12R7tuaAPqAO1H71GGrJK48f77YIYjdGc63BW28EzLQfFzOL4LLoN367ruJnjMd/vb/CNq3pvHag13BKZR0Gm5IPK/BDdRLyYbG2I3J+eKaIxYyyG2cxl3BUSAYhz55I+B8gw8VvjV3dcyoo/9vYc+8gQhpa/tF6SHmGDBDNB/ubp6C8B74yrGtc9GMUWT0cgrbXInQCmuA+OsTzo6hj2ybdQyLzLcfP88yrIASxX0Rx8XxXv3YbQcNro6Wf85N2fzCdc1czwPhAFVnl3d3jpHQo21WO/es9kpWoQXbltnYW8ucp7738f42X2lftdguq8tf/R5/P/be9NYS5IrPew7kXnvfVvVq97ZzV7IbjaXbja7uY4lUUNKmhl4EwwbJg1b3g3bkA0BlmXDMGCguv7ZGNmWZiTamj+2IBuC2Za8yhotkNXWSDPchprhNuSQ7K6l19rrrfdmZhz/iO1EZOR971W95b5mfN2vbt5cIiMi88Z3tjgxeuRhs/padvoakQa6VVUvj6vqC2Zfmb72XkB5iAUeL1szO9uV15B4FQ0y5skI5MdB3XbCj2586M6PzvE/Zh8HX32lgZXRGBtvvmUSzIAjQj8+GGEl0sys79XPYhbaXOCH/EC/mJinuTpw4DVhT0+s0YviNL8rhAj/xN3gON1aYGIuT+IJhGIfiQ/zPU2HAiKCbhpMHnkIax/7MPR0JiSMWAAlMtPXRiirr72XUAi9oAcm/rqWoxXScXqO39XZJmETzDCDq8qMJ10H1s5dl9GWbLEmYxywPBphdvMWbr3zLpRSaJt4oZbjGYEEedvpa3K+tm8Bc8gLHnfdKUCmJ6VmKu3q7AQYYXaOHOmIsqwtPkLFo+fmpUuhcts4AhcQn5ub72YDJF3SP8/d81DaIMCMqq5x9tMvQXc6sZYIidNOXyOin/9Ljz668mW80vHpemkLMiiEXiBh7dn8O1NwKwPjAGlYZ7EnPSNsaa1NEFuloMF2PrrLGEf9EsQXBWCiamB3F9cvXwHDJJjRnQ4+2nto6P6R8/gPDcMctFRvmj/A5QuBeb0aosLJtzFcElzq1Csl9b/nuuBkuiUVLAUdWwEtElbghDeOBMsoCFAIOnu5Wg77HSZS0LMZ1j/5Aqozq3alQ3enyLqmWkAvkXqcsPRpAHil8MGpR3mABR4X7C/+zOb1nzLzpcoMN3Nt3PnxygyGrBm67cDK+NFdxjhOV7tIy6OQYGYCl2DG5INvD23ltcMDEYmI4kBmTpuT3GAOnEAl942M5UTqk16BFeSXcS/IxW6MWZ7i75k7L0y3pOHonNY60eo5XOZcEN6Kc0iN2vcbb6evrXzwKSx/4Eno6QxEYZiP5EsivawqVKr6JaBMX3svoBB6gQR/CaguADMQfteq594eHvSzdKiXA53QBNgGsim7UIubupbzg7PcMPeqAKzUY9y6fAXTnR2Agx99kTidWWqgIUe45DrZd6cPorOlVOKJzL4FkcYabM8kijkV/SBZOqptIrxYn7sTYEI2vb2tEQfFvvuMjGtrdGYNZ156AXom/OiJ5YRB1BFBMcr0tfcICqEXRHArr2nmbzilyulWkcEu2kqHLHsFwy7UArBS0KzButtHYJvxVVYaWB6NsXP1GjZu3DQJZvzKawvE6Al8MpKMjxXAIlf9AHAaa8igJ0MLDCVy1P6hRWEWGzl7gjPJc8iB7+U5l6+AAbFqXXQ1x5+HD1O39c+8BFQV4oA44eoiqIaBiqqXfuWRJz9IKNPXTjvKwyuIkFt5bZ6ZNCV6t88d0Z0l8Loyg7w2pO5M6+L06HKnoS9XNbqNLdx44w2AlM0Y12bvenKItTlOcqBHSm3SkfNaIT26i4BegJXfj9AwEnEDIhFN+v4sfj54CamVOz3XEHZwHyVmeL++PEelRELxUQk4yq6+9rxZfU03jfcHxHEdRB2hW1PVZLkaf9FcXKavnWaUh1cQ4avWZ96w/m7DekslK6/lCKY/LgWtnd3CLFUVAuWSjHGhTBYlkPGjK4Wx1rj++iWTQrZtjV9eJ1csDCuYtruodxkJ7fyrEebUm8TfIiA2JccuhigyThzPGigOz7V8RMgLLuabyI8nov3dmWRD4Ifal7N2HSZcvAI3LZYeedhMXxOrr0mju60vK6VQM8r0tfcACqEXRHBxPX9x5/pbTPhRbY2GeS/5PHYKGkHXtSYwTpEPjNNu5TXJyIm0QABGICxXNW5duoxm5hLMhBSwJE8+caS+V45drsmZwBFqaYeKfAgbRZ3fF/VSA0yUQS642Bfj0UXICS4JbKVTl4JsqyPX3qVJgOBBGHSvc32fs4aqR1j/zIvgLqy+1mtZmL72h3/5kUdWy+prpxuF0At6+GrQysXKa3JAIPEt1WbiYcpFumsyfnSztKo2iWYQX54ObopMXvfV0Rh33nobW3fuAERo2wa64545c7EgyKu39wAj5kI0LFcJOd8+FmL8GcLES+gT2UL5E/YFkf6WIdaQh98nz4V0twAIOQqMZ8JbX/bTB8IKsL+qEtA0OPvJT6BaWxHT13o3Uw3AS6p6bA1rnwXK6munGeXBFfTgVl7rNH19PmW6AVzqYn2tXdupalyblde401Zr6BcXiwcExcCkHqG5ddss1EJA17TQuksvXUj4LLFiQI6CyPbCgjaMIuHNwfnR7TkUk7s7wwVppe6Iu8YxCQWxcBZbXwAXAMjCp8C+jWYXhRUSpIVCbA825aDvASl0dvW1paeegJ5O4xuJRhFRt6QqjIjK9LVTjkLoBTloAFB25TWYJcoBxHp6jNTAGsYE3XXodAdWlYl4t4FxzsrukX6HeUGXVI1q1uD65SsAEXTXoj2W9dHvFtJBEY+gcZa5DLNn+mAREXmBE6JzvuVeutMo2jpvnk9K2h+OiX7y7xtnjgt/dZptBrGrwVc9yACHYrggArhrMTp7Bmde+jj0rAFIId9ZRB0IFeEXAFCZvnZ6UQi9oIcLdjyZLfMPW+Z35cprMSQx5Ycg5mB2R+0WatE+49u8hTyITGDcCMCEFK6/fgltZ1Zt89HzSU0WAzmyClqpJzumaM66ODkubWEFF4ts9XxjEdgqtujIt2aeiLiwkH70jFBjllkl56t2R8Qa6/ZsKRvZLjq0tjPj3Gc/CXLT11zFpUmAoBoAFalPfOXhZ8v0tVOM8tAKcmAG6Fdv3LgD4HuV9aOHcYeQ6BcCcdicKc0lmFHej86W0IepygyKCsaPvlKPcPvKFexubYOZ0foEM+l61r1SjglDOqacumW24hzgFBGCjAAPQWQLT215RHPTLHuQa2/e1u5mB+zruZ20nOMS6fgpe1lpzBIn+y6IBJnUYwHrquDe7tyt50Mp6OkMZ57/KOqHHgA3Td9pbwQtt/raZEz8RXOgTF87jSgPrSCLl10ed6JvKj8K5OK0gb6JOQaz9aMDduU1JCuvDQ9gRDZj3GiM3es3cOfaNQCErmmgu86es7cj4OiR3p3ElkgN6wZ1y9xhMSwXFS2LC2XkbCAnzWf7hpsyJedCwwXKwVsonMVGarBz23gics6AMDvHTh4JMDABcf6VJ+Fn9+8CZYs3xxC/J/NqSgSezbD0voex9tFnoXenfXOCFyKIFSmA3PS1V0/N61UQUAi9YC408TfCymsyQ/dBPu1SqloDdQ0GQ9vc7IOmevvpA+OqGtjawY0rb4BUyBjnNfSFi3iXenk8V9vTmagzIVnQhOIAuiF7yGkARZqsbRBDPDtEFgp3HFjENktbdQ6UbBuJhaRfJTJiUa+k1HiR9sGA/ytfW2ao8Rhn7fS11NrjyyFSDQGK6A//hYceWvsyUFZfO4UohF4wBKM+z9zKa1Rhz3Ek//tnAKw7Mx+9loFxLid7OqhxNPZVRBiTwogZ1y6aBDPcduhcYByFc8MdkzosBMszUkKQK3bJgLn9aGKLO9oOkMaghScjkCUBZH478xwX4tFmid585+BsMd9lQ6R/QXQDg0EcSnGg3ru+B4jATYP1T70ItboMbuO0y8ICrzpAL6vq0ZE6+1mgrL52GlEeWEEWLjBuc3btNWb9uluoRawllgzUOT1CUCwzOrfymqJghmfttVF7Zq8uBMKITRrYW5cvY7q7C3Z+ea3NwCfSjNIcrWcRwcze/Ox6IrfW9unB3s6PoCmGT58D3RKg7xd5JgX3RL7kRYYxRXhSFg3zYp13QfTfYVlKvDEMIpMGdvWZD2DpycfBs2l8Y1hTv3nh9BJVqIh+ESjT104jCqEXDIG/BFS/BjQAfre2gXF9fStH5L4I/+HStjLBrI+u2Wrpdiij+HzxYbR0ZqyMxth6+11s3roNACZjnNbeYpsaO08TODNnuxdXkLP0zrP+LgoEUTuEpDR+j5y+PWieMNxD+X5YaFgdXbqvXRtZtCvyNWRUdMBr7mmwevaORGb1tfWzOPPJF6Cnje2/2HDvUgNoIhCX6WunFYXQCwbxnB9W6Othb0qdfTNy2C+OuzzsYLD3o4fAOH9FZmRSMNPXVuox2jsbuPX2OyCl0LUNuq4LgcQImttimNjnIdFQWWQhg7TIstdUo66X0s7CSy89ewmid8atJ08A22iCoYmSvoR5cuQCQgZFhngKds0XgYJBWCFhX48eO3Hv8ee7S9ismHHusy8BlYKXnDj5zRGpGYBaVZ/4ysNl9bXTiPKwCgbhVl5jkiuv7UcllGQVGEfb+eNm5TWjoWu38ppFtmQiKABjpaBmLa5dugQAJjDOme2ZIRd6XXxztRjUo73sHQZGgZOBdOI8oaQuvOziK5hKI+6r1ESduT1z+cIFPu4fsYAZbO5hpVWhbvtr2L4P8H1iAiXz7wQl9/HuMUV2+trHMHrwfnDThnOkQcB8bddUNalp/EfMrjJ97TShPKyCQbiV13aZvzdj3lAm1VQ0ZKSkPQQ3Va1rW7PyGpExudv56HtdXIFQM2FZKdx4/RKapgF3JjBOs/YanrNUymAz87mIFJARZTjQebz4SQwC/EqlCy+7eOz1DFg0xvaCJDmh5R5Gm4/3jUgsVnbTkbZX2r26HbRr116fQpbi9ksBKCfIEhH0bIblxx7B6kefhZ7O4LLG9YRCay2piMr0tVOIQugFg7A6A31l++rbIP5RTcFKZ5AOUqnGGasczAzdtCYorlImg1znzO4kx7moBDPGEWo289HvvPEmdja3ALZ53Z1QwAh+SXs/UyMG7YMCTn7kEnW0C3+YudkDBEbCn7oPnHz7hhGlTY1IPRC7f8syndGzYOzjnscrCIW7Ue+BurdUErN76+EDAWUp0qjhyT65Y/TdTl9b/8xL0G0b8s6ndSSqGgAK+Lybvobj7qqCu0Yh9IK5OO8SzGh8W5kBRsfELXXE3DAajwVd2xq1X5jd/WCeaGdy2yWYWR6NsHvjBm5fvQpSyqy8JvzwIBcxTmE1LCbkSk6/n+yolQhD7DR0krvCNtI+w54stnijco6ZObC2SIIyr+45jX3x2ioFW/c1UbftAbfiureD+8PC4eVM9eIOc9vspq99+kWo1RWzOJKLV0jO7Ey0u5++VlZfOz0oD6pgX9BEX+OIxIFhU7u0H8YkZXKwd+C6DvPRuw7zJiKZ0owffaIqYGeKG1feAIig2w6dz+vO3gzttR2aP+hFfHiikXSZvnVamG2QM7lG1giJPQLJFg/yPUKsevtkQYmTF+75CpP8ARt9cl0U/yZkAJz8LSX5d8xREteKaY7mPQ/upfRXFAQA40dffeYDWHri/dbsbkSHqD9suMuSqkCMsvraKUMh9IK9oAGghf72zIwcVRgAGPEwMqQuigGn02b+eVXZwUj7qWfZ60UxCmaRlgmA669ftNnm2pBgxp3uyICCMVOu9OUGwZz/8GQhBSSObR/EwX9K/VSyURHJrtz3xYKQXKK4gbid5DneCjQI/XEQnNhTjszcIlLdCyUs3kGO3CkhgVKwPAUvhfCzi9tJsZqIwG2H0bmzOPPS89AzQ+hZcZyIOgIqoj8GlOlrpwmF0Avm4oIdgdpt+mEHvF2bEUfnz46GEORohFmja1qz8lpFhsy7rmc39cQs9innR69HuHnpCnZ3dgHNNsFMnrIirdtpeYk/Mme9Phmk7CxS7fbmDWfEqr4M5XHybdsPnMYaBEUW34PBuS+1LLbAYhGl+oUn+KG6+99AvCOySngSd9abfCnhvgyc+9ynAOWG/uTNYAKI3OprL/75hz70NKFMXzstKA+pYC/weUB9BVc3wfzdKoqmmevZREzusNZCRtc0YFJAVRlNWUstPS5B7iQQKm0C47befRebN28AZP3yyfS3XO2kRpPV6hIb9slZ4HOWDknm4ZgzvXrlzhkn5oU1LCwypobITkGiYU5z576VIi1qARGTtWyjA/kYCub+O2De4Xg+eirnkPU5+avs9LWzH/8oRg/cZ1ZfS4p1d9agbk1V42WFL5q9ZfraaUB5SAX7gXlPiL8Zjxk5Ck20qBRs56MzA3UNzeglmBkC2fnoy9UI3eYWbr75NogU2sYkmAHHZaQ+cUKi8KTBeEmo8Mla4HM3twFihBDKlHE/R/U+Hap5Bu7ZxARuNgXBuemKix8VJzBUOdlWjszsPTCH+ehWUE7EZ+8jD1ebwLilx96H1Y98SKy+hp5xyK2+VrFbfe3hBReRCoBC6AX7wPP2p95pJVZecxjym+f2mVFDd3ahllEFkBm4evPRM0URjNl9TAqjtsO1ixeNIba15eVuH5nxOWixYK+l08D5J4ecymmP2Mxx0VQ8Fz/ALAP63xuwZhpvGHIJhJw/2e1OLknfhSh3zYljzu8kDdn35odA1XKBFm+hERaL6FJRPBGgO41qMsH6Z18yrq6s1MpgO32NQJ//rx544MyX8UpZfe0UoBB6wZ74nhtWx/idKfSMQFUYQxOT6DzYBVRYOz96bRZrERnjfE73gaIUgBHMQi3XL15CM2tswpounr7mwOhreUNaz8KDbSCTGcqDS4KE9ZZFelG/C+LwKQPboK+EnTz/OSGtb36ODNWxQWMBIWIkoraKIDnL3qFd0lKB6F0PQXKh4QyAlFt97RNQy8tA1jJGIDLT15ZV9eg5nPsMUFZfOw0oD6hgT7jAuPXb714C4yd2oRZhr84NQCnEIKy18aPbBDNuoZZocMkqMQxFJjBuuR5h4823sbWxAQB+5bX8rYVTWVrZs75XQYRx7RcDLIPD2P8HYXHw24LhpFdhMXCAimSlkPDwOKN+S4V+cR6eQ14r3vsccapInuQi/90CP27def9dlminr609+zSWnnwMejoDUZ8GrHCtJ6oCUZm+dlpQCL1gP+CvAtUFoGXgdyozNOhM2BlijT0TzGM3ddtAM0yCGREYl5ydDHNGO1UMrNRjNLdu4fY77wJE6BqX1z1cEQW+yTFf+s57vtf8spWLNZI5V0HsLI8W+HCn7UlmJ8V2d3vfxGGe2p8RLBIiL002o97Qe3b0PSJ/IwHpJLI4cJM8cQfhOAmgSIUXKXK7d8NPX1vH2gvPmfnoKlcXc3JHQKWorL52SlAIvWBf+J5TeojFyms59YeS/b1QHYDZJITRHTAamTnWIjAuOztWqFoKwFJVQU1nuHbpMqBIrLwmTc3WRB2FfNswoZ5ZmnvpNReLxCWc5pWnITPuc5Bb5jJU3Eoe/LIoEP4DUBDOPNnF8D7mvmyXjaMHjuu593836fOM0uFm2Zr9leYzkeCEQBAv8mMsOOc+90lD5tnnTADs9DXQJ/78Q0+U6WunAOXhFOwLbuU1RfhmY6LJTUrYHGH3KDHW1BnG7K7bDlybhVr8+ujMw+MLzKClQBiBMIbC9YsXDZHbhVp62d4S4nY7JXUbbW5gKhv6Q+nJYi+6sYP6gOZ6oNIXVqLJWH5Eqt/oMTq+F+8BiX2A02CPsr77gRUreu9gPwWwQfiNeZlGSG5G+h5oFCno6RRnP/EcRvefA7dt7772N0GaqFurRuNlnnzRHCnT1xYZ5eEU7Atu5bVtmn6/Yb5ZgVyWVfR1HodUwwi7vR+9rkxgHOuwyEpyvVO+3DcFQsXASl3j1pUr2N3aBnjIjy4HfzPoB02GQ1CxGPBzNod9Wa+PBfusRdTdIRnJyRPXISIi7pBZz/uUESvzcn1xIOGwnFHocGu7D3CWhJmjloRzxaeMmSCCCS4VDfRX2xdezxosv/9RrHz4GejpFEj86OZ9ZxARExEqhbL62ilAIfSCfcEaN+kvbmxcJ6IfVGasyESx7e/3HhLMkIl2n+NHT/V9IpiMceMJdq9ex51r1wGS66MP1SFM+eodITsNzLso2dczrcdiQz4HtvOTyc9d9+P+qR6WnckheSJCyXVrnqTa91Czc892YZ935EMQliW7n7lvRie5QQRojWppCeuffhHctMIKIE3zAIOqlgAG/eG/8NBza18GyvS1BUYh9IJ942VnZmf9LRXixNE3rbt9Q2ZCWD+61ahHFTQnK6+J0voJYkxg3LKqobe2ceONN0CkfGDcwcAxiTurZ0IWp1ezdfECfhN+7M606XSQfV94lDnfjTUnJiZH7DJAbK/iF7YbmKNflo//8Jq8e9hOKA0CanivCWhbrH/mRdDSBKz7vzsjLIBakF5R1ftITz8LlOlri4zyYAoODA36RrzAo9vM+czzwyID0K1ZWAXjEZgAzWLlNV9Uf6AhmBd3TAojzbh28RI0a5uwZmA++hx4kgNC0pZEFlmc6V4HBYf+FBPS3dPLuRdOm/7ll8n18qVoJIVNccF8sl6U9s956TJLCyXXRm81yIXOuV2K0O1OsfbsM5g8/ijYLtbiBdyoLOglqjAi/kWgTF9bZBRCLzgIbBi6+vaMuTMJZvZjapeDi9jLjK5pwT7BTKql0+DgauajM1aqGjcvXcZsOgN0N38++pz6Ddb+9DI5YosI4FbXksnITnPrHLI+ZudTd0TPQkhjBnH85uae/4n3TToNcS/IBEpCwPEmeZEeFgC4bTF+4D6c+cRz0LszUDp9zUkAdvqaIlWmry04CqEX7BsX7E/82tbSjzX4ig1z17FGnpra52gZzOiaGViRnY+uE0LP+Lp9qTYwbjzG5tvvYPPWLTCArmnugtCTqnLQ1E097664k0dKcuZDjO97XXEKwZG7xGul6RQuL9xw741dNMwRNy1sC+S0SxkQZ9/nyJ7m0h4T4dxnPykW80uMbuYk1QCoSX3iVx558gOEMn1tUVEeSsFBwOcB9ZdxcZeB79Q+wbYbElPH7IAeKDSlrmnNgFXXYHBvoZYhMlVkFmZfrkZobt/BzbffBqlqH4Fx81onK0ihZcI0nfPxnyz2Q0XOnyyogcWYLxpCw16SUwDZIPKt9u33aXFDX5BLR5yUdLqEONOCMNdcuFaioIg4rsBljTv74nMY3bcO3bbhtOgSM31tVVWTsa6/aA6U6WuLiPJQCg4KBQDM/I3gnpTBOMAwI8TRRswMblt0nQbGI2gArDm7lKqDpC8FwpKqUM0aXLt4GYD1y7vV3A4IQobh3Dcfa5RGAfdad8yYd1fZHkdsltS8lt6f3iWUvdMHCoKlI2zP4kOWIxFkxrKYIZyKvsm8oU5TdyCCns2w/Pj7sfLs02CbBpb84jfhcrf62gjql4Cy+tqiohB6wYHwfBghvtGaTTXfI5ua4+PduuvQNQ0wqsFEidk943f3l5qlVGsGlpTC9ddfR9M00J02CWbuxuxub0fklj8hv9vP7fV3X2wzrUFP7/Sf0sIaLXGPSG4J+07F8O2IO7Qzl1TIrx8P166QnGXomUalLOiD3+8zIinsaI16ZQlnP/UC9KyxhimWPzR7EanGtPsP//Ijj6x+Ga90WNie+NlFIfSCA8GtvDZj/Z2p1tsKpNgPj8DwbzxjdrcaQzebgesKqOz0tS4/fS26nAFFCjUDq6Mx7rzxFnY2N0FgHxh3UA7yiWVyc9W9YyFe+UtyIYkyTh6Z55D4Vb24wq5dyZWcvfT0wkpmUTY5K9DME2A4o8EvJuZba9xcc5ZTMomAtsO5z7wEZaevOXE2KVm1IF5S9fvPdMufBoCvFv5YOJQHUnAgXDCR7vQrOzfeIKLfr8kZcSVyw19ilvcWYEY3swlmRrXJGOe09HkVsVbBioGV0Rizmzdx++pVgJT3o9+LWklWU/F+VxcgF7UvaS5ERPGJI9N2sUCHf2oc2tmrOSWXxtbb0wdmkfaVhQAXxxf4JVkt5DOdnxf/uPtlf/ET0fNOa0iEbjrD2kc+hPFjj4CbBt6EEZ1GAKFbIoWK6jJ9bUFRCL3gwDgPVDZO7NvKyPM6T95AiLCRgXPxaV3botMaGNdmcPWBcTx3zCLYhVpUDd7exfUrVwAyke53HRhnS5ZajM+iZeubCyaL2rTgcO6MkFGN3IAtEpSgr6FLkjvOCt8zyP8nxTL/TO0ZMpCA4Yj+YOb24+2X/bxsnES4e9OYdbmY9dEnD9yHMx//KPTu1E5fy1p4SBOBmH8BAMr0tcVDIfSCu0an+esDBvGBz97waDSjtoNuG2A8hiZEKWAhrkRvj1moZQzCmIFrr18ypvaug77LwLjcHf360rb+cpp873Q3Xt7DnY8eIpzR1dVum6hvimLIHLn5LwuLYTqV68aHMwPRybnsPm0snTbBJQfxENFvo9tLVYVzP/epxNWUWqLM9DVF6qW/8L4PPEUo09cWDeVhFNwNNAAw1LdmJld4FTRxh77ZbiiUTGuNbtYAdQ1UKuR1HyJkDuZDRYQawMpohFuXr2C6swtmRnu3gXHmBnGt0/W3CWH6Uy6a6lQQQRwnkBvGHceR3EmLzOn7qZkxS0TtpbDh3RAczPKL/yznIdMntp3mJ2Smu/FshrOfeB71+llw28XBIe4ygDqFbk3VS9Ws+oLZW6avLRLKwyg4MF62v/R2ufm9lvmqAiisWzakyqUmeflVo525BDO1zevOexKyM7krbfzo2+9excaNGyDQIZjd05ul6mrwR4dV2jjWZhcWGfcIySaafdLMvu+Av4Vq+0Ash7emUPCJi1VrpKCTxkQs7rM9gNiRulTsfPSVp96P5Weegp5O87EgRFCkuFIKtUKZvraAKIRecGA4U9uv3rhxR4G+WxuNVPfJfB+DjD1VzxqjkY9GXkNP10ZnpzpFlxIqACtVjW5jEzfefAuklFn45ZAIPfiVEzUcYvoPYObvIh8Rvrijnrc5W81UCiriNA7nps2LnshCqbNDvR4ITcpnImpiYA1yESx5yDU9OIafwt7niiP2ZdVao15dwfqnPgHdtEiXUxV3UQ0AIvXz5/HoSpm+tlgohF5wt1AAoAnfVCaIKBlR0t/4nAGI7VrmXQdMxEItMtLdEU6mVAXCmBTqtsPV1y9CM6NrO7SHqaH7OnOIAnZJS6Imsq+u/7ZoPAcgp706mvLz78mZnRFp8BESIkyKXGBJxlmTApuzf7bxY82t9nfyOEjH5n41sHY183AJADqN9c++BBrVgNbIusiIVEvgJVJPvO++5U8CZfraIqE8iIJ7gtb8De3VtyHSnjPCO41Ha7TNzK68ZszYWmuA99aGFIARCMtVjZuXL6OZzQCt73KhlgGQiwRPnchxmyUZ+qNzxv9gvD9uDAzyEDTHgFtDHRgwuees2qkhYyGRWJFSCcweYjtpfT8TMxcaIk4gWo3ObSgFvTvFmY99GONHHwY3TX9uviuIqFtSFZSiMn1twVAIveBuoQGgrfkfT5kbExjn/OhO+0mj3DGwD2Ct0U1nQFWB68pPXUsXlUhBMCuvVQys1CPcefNtbN25A4ZIMHMYWrqzussBH+l22JeLIMhGFZyY9h6eg5uyJvdneTr1J+eKW3D0fcPSwuIsL/1ThIs9cUWcEkqXsnXUZApm97bF5KEHsPb8R6GnM0BV7ixxvrmIiVARlelrC4ZC6AV3hQt2WNjduPY6M16r4Szi+7C3ykHVDzQmwYwmgMYjGxhnp6/NGTOdwbBiYHk0wuzmTdx8+x0QhcC4w4EwzzqhRWaWcznRfQR+jFx8vxkbD6l6B4YwtXtHcjBDBzlKJtcRimzKe5zdXDjEwl3GeO5z/HIQbUj0UeJ6CAuinAZQX+sWCXbADFVXOPe5T2YCUkVf2elrFeiTf/a+Z55wMTVHW/eC/aA8hIK7BX8JqH4NaAD+nSpKCC5ILzfUSeVd7OuaBrrrQJOJIQ+3PnqiNWX96GwSzKhpg2uXLgEgnzHu0MzuvUaktYi/cWTGzV918pAqGwu2cuRlnqNMHhalTnVFSJIbuMvigU2GQsfSifbq2indJkGwmTtj+4SwVy1yue3l5QQ9bbD+0vOozqyB3eprUQnmxI6oW63qlVWlf94cKdPXFgHlIRTcNZ6zI4gm+prdJUzuDunI7zbj0ZPBYLdQi/Wju8C45MqsmKDIJJhZIoVrr19E27Vgt1DLoZtFYwYzZkvXJoQI8ciRLuq+mOzWq1ycHtU8r8if7jT3DI8M+Zz98UOr9D1CTjxHaKPXvKVQljxnyEsXAndREekBs/PRVz7wBJaffgo8m5l1ijNlExFXpFCjKtPXFgiF0AvuGt+3v3JN+ptm5TWq5l8hBwdB/G58dAlmRjbBjDW5s2Z5WlbBdyuvrYxGuP3Gm9jZ2jJmfJtW9mhIPWxxQoRupO/v75vZF2YkzFYk8ZsLQYyTM3oB/3OwGBqtQX+uOYt2uoC40GbyWr0RRHPPc2GeqUeux517IQR6ctthtLaG9U+9AD1tQJnpa9aPblZfI3zh/FNPLZXpa4uBQugFd42v2sC4LYy+1zDfquASzOSQ+qAzZ2hGO52aBDPj2s5HZzCbKTQDuj4AM8hWmrFaj7F77TpuX70OUhSmwx06pA8g5zQn+Mh4X1/y5L94A/4QcvQ09CSEAJPT2g+3YoeGfQl73iTPkSCT+tD91L+F0tyBfO/L36QFAdAa65990Uxf49DaqASCagFeouqpB+/gk0CZvrYIKA+g4K5hhzj6tc23roH5BzW5hVoGzh4S4P1uGxjHDEzG0ACYw0It83yWBLM++lJdA1s7dqEWQte0h5sxzqNfnjDChwiCnq+A/XrrrpS9PZ+LhaidJJddpZ62m79u8do0jNQkb+BiJPqiDnmf+8IsvHcQKJM17szHPozRww9CN03vBXXCKRR1y6rCmKpfAMr0tUVAIfSCe8J5oAIABn/L+rbnjNU8sG0vZIZuWnRNYwLjCD6ney9Rm7/MDy9QUBhDYcyM669fhNYaumvRtR00H0VgXFIXEVAmB3s/mY/75t1TxGxCG+07yKM9+7A577UM6cIgeV7kNHU3RcE+5yEmWywtfT8g6KbB0iMPY/VjHzKrrw2b3d30tT9m9r569D+ygrkohF5wOCD1tbyH2CH1uCaHnDtdd2inJsEMlF2opQs+cOlHD1RuoAgYMbBU1bh+6TKmu7uAtvPRuyMeayglqcByYfGP+JJetPhw0QuBQE5OD7WLl3AIVBSnZAoQ24vSqCz2cKdITd1aW1z0e6+kVNg5DWCGGo9w7rMvmYxxLrWxPAWAm75GUJ/51QeeeOwCoM8XTjlRlM4vuFeYBDOgb89YdwRUWd9cZHKf70fvplOgroCRXaiFc0Ftks7NtgJBMWNtPMHWO+/izo2bAAFd2xxegpkhcEZzzVgk0mU6B4paMKSRzmyDwTyth3npicQV9fnCkfigXj1wnluIR/SH9aubtudjI/Jx4gsMu0b6+idfgFpdAYsYlDiShahT1K1V9WpN48+bfWX62kmidH7BPeGCHadubi39RIMv2wQzB1CH+yTYzmbej+5SwGqZ1x1AoPKgGhFgEszUI2i3UAupI/SjzwP3vrlc4en09Hm1WgwSyNNU7ENmz1xy5XHvYliMhtwlpADmLBOG3Ew7KWpreL59t9JCIpUsiaB3p1h95gNYeupx8HTmbOyRi8ucSlwrBcVm9bWCk0Uh9IJ7BZ8H1F/GxV0Gflf5BDNzguBgTwEgWMB+Wj9624Im4xAVzjo2f9p50G5QdUq/AmFCClXb4frFS2Cw8aMfOaFTb9uLHNYeS0ygtA3I9BL3eic9fMJwBvYYcqpXaLu4ZOFwkJ6kKA2xDHgkctYX63bx54RGG8I/+F2PBZnfBXcdRutncPal56FnM5ByVOGI3X21ZnemL5zHc+MLeLXFgj7tnwUUQi84DJj3iPnr/TFrnhGyD4bJKd01DWhpAlYU8rpnSgyUaHy5CoSagWVV4frFS2hmMzO//TAXasm2JzHFgsB2rrIb2hkhM5kZQ8nKJYkDloYoM9ztZDGfknzcmE3EsnAEdleQZhWrqbpIR/Hc3bc0BbA/gxfh+e0Nhmna+mdeBJSKSD/yqBNUS+CJUk8/uL75cQA4fzqa+J5EIfSCe4ZLMNOCvtGZTfte+eEtuSLjQ5dxSFqj3Z2aBDMjNx9di/zSwpgppxMRQZFJMLM6GmPjrbewubEBAPFCLYfOMEOiBsPlBZeKarBdBI2WhSSUjoaLTYj9sft4XRvHgKiJ4ZkhfvUiAcYveJN0xeJNZctXiIigp1OcfeFjGD14P7hpe8Y0fz2hW6lqVdejP2r2FT/6SaF0fME946veZ87fmTFvViA1VxfJpESNudAExmkiwC/UIrOuiQujxB4MBUIFkzFuduMWbiULtaR54Y8KFLVR0DiLr07XEb5nB+9GQF7jO1nOHHpw8lh4XgvHYQfFXCMTJSlyERH94jd+4EUigp41WH7sfVj5yDPQ0ylAKm6Oe29JEczv7hfNnjJ97aRQCL3gnuFo6s9tX3ubwT+yC7U4kkdvVBtS3MXxbjaD1tqY3cE+r3sUaGTnAUflAqiYsKQq0HSKa5cugxEWanFpZI8acgWrMMLbcDFPzhzNS/dJSRD4Xvqle3LMiZH6vBtz5ms+f2Bv12lR7Ht+BArBjjaEJGtpOS3ts2DNqCZjnPvsS+CuyyQNsgKpMmlgFehzf/bRRx+8AOhT4ll4z6EQesGh4LxJMMMMfKtCFNeVR6qCRgTF0G2LdjYzhE4E1tyPdM+MkETmpR6xCY67dvESuq41C7+IhVpOcmyNAqQE8ds4P/8Hdpo+hVW/JBZ0yHRiSVhn3T5cDo/MPH6OXCCnhu96ariZthb4jqwwlnc2nRZiJyJw02L9Uy+AlpfMnPQI3gxBmqBXVX1ubWf1DwDAK4VbTgSl0wsOFcz89YONVxy5Je0e6E6j2901K6/VlU0Byz4N7LziFJnAuNV6hNuXr2Bna9to/W2Lrjvi+eg9WELOWSmQzuqN/w5M2AtCFM6KIteJp0QiITifMwUTT66LFh5BQAyvcJDIco9QKvgL3UabBnbt2aex9MRj0Hb6mrQp+YeqlB6pCqj0LwElDexJoRB6wWHBie/fmrJm8iuvzftdJ6wllR4XGKcUaDRKEsxIv3n/FmT96KujMXauXcfta9eMH71toXWXNYceHYSp3VfQREk7owQPpozjOd8yWMghVOSt5zzBmbP2t2+hIFMAWrNKamx3WnpvzZr0ewYnQ/ZxjbhtMb5vHWde+Bj0VE5fc6f7qEBlskqpL34JqC7g1aNYEalgDxRCLzgUXHA653b1ow54qyIQI5dAfX/DFAPoplN0zKDliRkUtdP4Eg9dYrIlmAQzS1UNvbWN61feAHxgXCui5Y8Q88KZvSnd6e5mfrpce5ztHHvz3RZ5pBW+W+xRqyh6X2jpC62a7hNR1jgR9Oi++0h39hYX504ZCP+IcDLPuy9EEgjrn3nRzsRIa+rbqRoAFamP/YH7nvgoYPJTHEuVCzxKhxccFvg8oP5rvLNFwHcqZH/9eWSVUw7z0ZeXrJZjA+P2GAhBBAXCmBSWGLj2+kV0rKHbDm3beTPwkVre9yjc18Fp79HCJ24Vs7Aud2qi5aisw636wbDHzV0AYGIWiSP693qgiwwX7JDuc5uh4WFigzkuZb7FFNaM4KlnM6y/+BxG950Dt503u8d1JoCoPaPqakWNv2j2lelrx43S4QWHCQUADP6GmIguMDBaD+zWbYduOjUZ4yoFnfGhZ021bBLMjBhYrmrcuHQJ051dLyRorSE49Bggh7/hm5qx3uS+Y2bvY+5FvyelLN7cZgFniSDhW0ewUADCKM/w8/HdeYvP7y5GgpN9IgLQiW6C9/3Zi95AIuhpg+XHH8Pyhz5gV19LXF4WrMxE/IrpFwHg+3h10Vv3nkMh9IJDw/MueFmrr8cJZhwksc0Zrp0J3SeYGZngONbQLto9MbPHl7I3u6+Oxth8+x1s3LgBENA2JjDueEdS2dZ029IBw2SRo5jwotlvwOITQApffw5+Y3ZuhcS6kInkX2RZxcBZUKJpGgaUCnJOM6coii6JsFi4Z8y6Q728jPVPvQDdtMMSJJFqTbTjH/wv73t6/RWgS20XBUeLQugFh4bveT6d/u5U611l3q+B4WnvMG5mRru7Cw1ALU3iwLi5lxIUkVmoZTRCd2cDN9580/jRW+tH3y9DHtHg6od5Erods48xCn5z9m5K6bI9PdnYggBDVlpxfllvgmYg19F7hwkuEKLn4Zg6sLaM/AcC18u+SPMmpSWeGIjAXYdzn34RNBmZWeb9k0BE1BL0iqoeWif+HFCmrx03SmcXHBou2Ej3td1blwH8uDLR3NzXxge085TjmdHNmtiPrvt+9D7MQQXCElWoW20TzNg88V0Hrd0Au0ejjki/8OKEN/1ztN8xn4wLN9zHg9aJxUYgNW98dxo5Acz76+jToe5ZKUVqssbsYq0x6bO2V/Vma+S3c9ceJUgpM33tox/C5H0PQzfNcGWJ9IQUFNQvAmX62nGjEHrBoeKrQHUB0CD6bRsYp/tMPTAYZIKndNuinc5AK0tApWwa2FhLz5ndCS7BDLBSVbj62kU00xmgOUxfG5wudhwIjc6mtIVbkhOCAIyT2eUNP0g03ImTf+9ZxVLJQscB3C2S6QlOIIN9ppEDSjwgxt4WmOPuLm4aTB56AGsf/wj0dApK08A6CU2R6kxQ6h8FQC+X6WvHikLoBYeK79mxRhN/LeydMzgls37S040ffRc0GoHtQi3aJSzZg6Wc2X1lNMHGm29i8/ZtAIyuaaKV144/0QyQ75Mg0fiY90Qb90t12rL2W/MT50s34MN9hsCqnv1mP16QE5dQ5iGRSjk2u1vzdHwYokkcBw0uApgBVVVY//SLeZeXszKRopaAiuiFP3/2iacJZfracaJ0dMGhwq28pjv1zRkYIcGMhB3wnP9U2p97pzK6nR0wkUkDq52GvvdccgLZwLgRmlu3cfPtd0CkQl53l+hkYPA8Gp7P+x/Tr/6syKluiJBtNFk2HezQLU4MjrxDelSfCc8dHfDAOE01fQ6x712cvFCQFXJR7z4AQkyd5OisPUvlk2kqKQLPGqy/9DyqM6vgrsv8bkymgY6oW1P1eFKPft7sL9PXjgulowsOFa9YP3q90v6g0/qdCiAf6hX8bPkBObMKG2tGO52i0x3UyjI0WKSAjS9P4czuE6qgpg2uXboEJjsdruvCcqoDOBkdieYQlQuochHwA3VfKOWOY1cyC0HJa6bODG2+u4VnjABAw+b4eU7mhYAwO4mscuQkGuFpSb56JF11cu2089FXPvgklp96IpMGNtRNKWJSCgr0CwDwfJm+dmwohF5w2ODzgPrl69c3AHzHrLxm1el0dEoH5OzPnqGbFu3uFGp1GVAKmnVMxpkgI7etQBiDsEQK115/HU3T9BZqGVTFcyPrkWCfqqYd9Z3vPzXL9qY/LQiiGAD75zL+uRp7A/ycgL9FbNt8CIdCtKCLaycnkf8WIt4gZ9k+KU7XbYvR2hrOvvQ89MwExmWfiZ2+RkSf/9OPP778ZaDDgopc7zUUQi84CpgEM6S+nk8wg4zj1H6mZngA3HVod3ZNgplRZTV0YbYcUOGMhm4XahmNcOvym9jZ3AKzCYzrpB99L7o41uEoNdfCD/zIBMQZ060/y+4M0lNGyV84xIF/cTCgA2HA5LygbRpCiOgnb53wbWNk5cuFYENrOln/zIugSs0RLki1RDyh6slnt6sXAeCrhWuOBaWTCw4dLsEMNNsEM7T3exZcrT1oZjQ7O9CqMn50Nj50bRX/ocGOASiyCWbGE+xev45bV6+ClMnrrr0f3Wm+/evzX44Kw8ZWr92y2w6anVTlWNitfRrZpNTjn8Kee0KpeUb+xX5zTi9LhcFB684iIgRFkg0GCNXnYH4XbewJMXsYlo4KRASeznD2+Y9g9OD94FkDkIpdIj5IAt2yqqB0/UeBMn3tuFAIveDQ4RLMMM/+8ZTZJpjpTcyJL+orpYLTGN3uFJo11MpyCJbS8/Vqp9sqAEuqBnZ2ce3yZcCuvOYC47zZNyGLY7O4H+AuDDG6O7UOcgpUqHW6uAsQB6QdH4YM6M4/nrwPzm9OcYv8VK85wt/pgKVv4SoiRuRCSZPMUeb3cezPkQh61mDp0Uew+tEPoZvOhlNHEREToVL4Y2bHq8ewIlJBIfSCQ8cFO0at7d66DOYf10KZDCHKYjRyg3qslEbE3s1m6KZTQ+iKfKS7M7sjKcIVQwAqECZEmDDh2uuX0HUa2vrRe9PXRNVSIjx5yKBB7s2jd4Hwvajwhai7RHiwzlXQF0fgrSZhOnfSuIUPistBvNxCYIne4eQ9JgBp3p0hEemowVqjGo+x/qkXgK4DkUJYF9DCSF2qIYBIfeYrq08/fMHklzs1T+m0ohB6wVGAvwqoC4DWxL9tU1DoHuP6s4GIrDI/e911aHZ2zVKqdQXNbBdZsfF2HHyRKRSASgMroxFuXrqE3e1tQDPaZD66L8fWKSJCFn8nBu6P7pbUna7n5KXFTA2bml7cPvaaurdAWF8CRVeFhxIJbnfZ1JPtoXB3L4i5/d5SxEKY2dvL4A02RwkicNti/dOfML/FroutCeE80oRuVVVnaYn+AFDSwB4HSgcXHAlcghkQiQQzewjo0uSdqC2sNdrtbWA8Ak3CfHTtTM5Oq0Z/4CNSqBlYG0+w9c5V3Ll+3frRW+gumbrmli0NXmsPJ3ecJBHY5KHJPmf4IN91UY54xJruyWHY9B73c4h9j56lbVOa1+RuLRDHqy5mzAky8l22yTfQuUzi46kBK7rsiBtFiqCnM6x+6IOYPP6o9aNTxipEgFI8IgUC/wJQ/OjHgULoBUeCKMGM8X1mEswkmEc4zGh3dqEZUKvLZtB3aWD9pcKqL4oksPGjVxX05hauXXnD+APbFq1fqKU/XJJjD1+o096Plxmj9gwkIvHJZpLrorndJyyMDGOe6YOdsi6ElcxZi9mwvSECAvx7mDSQbIDjEJFHRR05CNy0mNx3Dmc+/lHomZ2PnplGaaavERSrL34JqC7g1fY4avizjELoBUcCmWCmZf1OFULOBhD7r3OHjR99BrW6AibYhVqc6jl8MYGMHx0Vxlrj6muvoes0uq4189G1IBQOaVfd1YANyPI+z/2nXD0MpPfy34UM4tZNl5nVOAqVnt+9gzc7UkjXQeYoWYuErXj6AoVpXnHymsWUWnq2HrsptXHbwsSJ7sVU96qfcPsYRlNf//QnvJBl9vfV9JbAI6KP/sH7n/owAJwvnHOkKJ1bcFTwCWbIJphhDORr9Y5fZMztvjjopkWzswNaWQJXlSUvLYgr6Onp5QrAmIGVeozrr1/CbHcXrN189C66TzD3mpL8mCs4flDuOLbB1pk5yfud5WpmMi5hj/kFabHHiLkmmRAFzsEBItzLBrn6Lqxhd6BiWZbmKJpfWOCzAp548kcOY3ZvcPbjH0N9Zs2kgYWtoGgiAQRF3aqq62WuvmD2ljSwR4nSuQVHCZtgBr0EM31pPnN1GtmrOzRbW6DxGLQ0gdYmY5yWmeK4b3YH7EItANZGY2y8/Tbu3LwJRTB+9GwKWFuOnEKVxKLlcFxmT0qGcI7qa0jezXMGsY+j25eWfqJwoRfChEsEYlFz94wpxAucDuxFt/Fx6S6J3m2K3z9yxxjx9LajAhF4NsPKU49j+eknfRpYU+n4PGOOV1CqpIE9DhRCLzgyhAQzZBPMwPN6NNFFaltzDPOsGc32DjQR1KrN6y786OHE/vx0t1DLcj1Cd2cT198wfvSubeI0sNE1sGbO5Fhq9z12zJ9/H2ICrO7Gi07iEkIrd1YHr6nHbZOpezl55vt+KgtLL0F4iZfXzT978tLN8dROdx3qtVWcefE5sz66Uq4iacXM9DWmP/gXHnporaSBPVoUQi84MoQEM8okmCFSg/QSSfaZfRbddArdNFBn1sBEPg2sNzEPXEswL/sSKYy6DldfuwhtU8C2NsFMWoHgAQjRZH56nNSS+Dh5PQ2Yktsk2sFgFw9wajRYB6edh1fFWRxCHIPdb4mciCJZMOtSzzLh4dY8j3u9SV/Kde8fI15i9/heQwJpjXOffhFUVaAkINOBTV53XlLVo2hWPwWUNLBHidKxBUeGC5YP13bfvgzmH5sw9wGbeAqvHkM4CK0ffXvHLNRSVT4FrFlOVWgvmfIrEEYgLKsa1y9exGw6A2vdy+ue81K6qHpvWWRnCrVTxY6NM1OzbLClp0KJN7nDtWColEVD0EqdJYcQtPYwOS8xzUMSPXr7Tk4vvJvenu8Zd++fDOGk/Kn3XJMsyExfO/PchzF66AHopg0/Auv89zK2om5JVaiV+iNAmb52lCiEXnCUEAlm6LdrM+SIldfmmbIhnKRid9dhtrUFmkxAS2Pj/xZ+dBLW5nTwUmTM7mvjCe688SY2bt0CIeR1z8Hn2/ZLlsr9yfYxs2RwW1Byb2eSjk3WkiOkhms35t/shCQAmR7VVYQBMEnTPCN1i6QC1iJEh987YlnYWyNkWyn0V/xzCu/AYXQDEaGbNVh65GGsfvhp6Ok0+VG4n65hdCaCgvoiALyMV/M/toJ7RiH0giOFSzBDmn9rwEsdY4+Bl7VGs7UFJgKtrHjN2aSChZnOFhS4xJJPJmNcPUJz+w5uvPmW8aM3bZIGNtTLp4NlEXCW0/7sl6NfwFTUzXdWamjOaHbeohCTH0Va1b5ue8wYuDHLY/uoHJ2qQIIBBG083hDg/pRK5zbyXXZYrygzqskYZz/5gol0l++Q/JEo40dXRJ/6c6sffIRgZsAcUi0KBEqnFhw1NAAw9DdnrEGgvRPMwFwhNUs5BnW7U7Rtg+rsGjQQ5qMPGJXl3grAkqpQNS2uXrwIhlnnuYv86KlZO0/U8XxvA0qTbh865ozGiT9d7vC+Zx8FH0rLabiLg/3Ui6OP3GHKSXgHvMvRY693p29N8XkHnDtChJFIa4xf2AaH6B4imDSwn3oBamkJ0Dp2b3h5i0gT6RWqzo5H/HMA8Px7QLxaRBRCLzhSWD86dtbUDzrgrcokYMv70VN1VxKS22CTYKbd3kF1ZhWoaz8fXbuEHE5L52RcgTG7Gz96has/fR3NbAatO7Q9P3qmWuwGxkCHJlhrEcYmQt9sLgf+/hUsDixGG/YLGti++9MXs/XzauXmqVMgaErsNT0B75BrpxT0dIa1Zz6A8aMP+zSwvjKxhKlHSqGiqvjRjxCF0AuOGnweUF+5enWTgd+tjL4g/Oj+tBDZk1pSKT6P2w6zzS3Q8hJoMvbz0SPzuDs3ITIFwoiBtdEEt994A5u3bwMAuqZJtPSoZkl1ySebCUuUOt/lSel6qVWhT+7RPld/GVTGeeJfPET2BbsdEuzs9/LFa2peIBsiY5fjPYqDEILscUA3LcYP3Ie1j30opIHNnahIaSN8fOE8oIof/WhQCL3gOGASzGj+rTTBTADtW/FiZjRbW4BSoLUVaGa/WEs//st6mu1+RUDFwOpojOmNm7j+5lsgENqmhe7y89FTSndyByMQONnsHwPD2YmhRwaJu10GnTGcn33PUIYFBPu52JELIedFyT2ihZBk5hB3qvHOKSI1ue8HeWfV/q5UVYX1T74A1txbFMgTPBE1BFREz99/9okPFj/60aB0aMGRwyWYIcJvtWYz/94Nu8GT8xjt9g7atkV19owNhNM2wUxGPYnM5CZj3LKqUM8avPv662ACdNugbYYIPZU0kklgot55z/3JwVst3Hfh7TAE3ndrLJZIMg9xTcMTFuRH8sicqzNa8PE/wXl3HBKxTJImaWXxkx728yCFn93hQAKBUuCmwdlPfAzV2jJY69592ZqCtKJuVY3GdV39IXOkpIE9bJQOLThyuAQzxPp3Z8ybCqTidBgWMkh7j8Gkm83QbG+jPrsWrY8+tBqZG7AJxuw+BmFF1bj209fQzBpwpzN53R3mSRnUcxOwH00Xg9T9oC3SwgIIaUK9eg5vzdinPnjCkO8O+cCwqPLuWdxFYxam/Rlhw8/PJzICrTtvbzkmNkbMa+Q+wxP0dIaVDzyJyeOPQU9nIFKJgEDOvcMVEWqu/igAPI+HF+QH8t5BIfSCI8cFE+lOv7xz/S0Gfq92Dm4HOfgSBtnE8zwzdNui2diEWl2BWlqy89GN2V2en9tWCPPRb14JfvS2bdGl66PvB35yOkzGrIjUFweSrAEEs7u1avg564tV7X3BxzOQcCM4l7L4fvqQC3YUngROAh9EClz3vFP5+FDj4+wyxOP1szjz/Ee8Hz3727PLqRLh8+fx3PjLeKWkgT1kFEIvOBacNzPGmIFvmMA4m2DGqYWRRoV4n/suuUYzZnc2wVUFdXbNR7qzFlqahBjoiICKGaujMWbOj64IuhnK6z7PGM2Rdshil2zOQiDJiR6S5MSVTWIQTwV8ZrnIZx5XPpomfSy1ukfMXXE42Z9kzpGulVQ+ll1zOP1gLD9nP/VC6OTk/WcCoJQyy6lWH3xofes5ADhfCP1QUQi94HjB/Js53oj25AiZQsCWLQfN9ja6tkF937rxg0uze27Acnm/YdLAOj/6O6+9Bmaz8ppbfS2pNDKlhUr6qV+Ig4JkHQZHzuOjFpntPGS+CwO/3O+rdoqGW/axDakARlE3R/JjouAuFHJpCSOI9hGcs1qY2yXBJ1fR8OM9cHcQoJsGZz/2rJlK2nXBJZDWValuRVWqJlX86EeA0pkFxwXDkqr61i7rjkBVTLaYQyAs/nW7GN10imZzC/W5s+DRyEa5u7zuwyAQKhDGAFaqGu/++KeYTadmeda2GZyPPq9ebLnSBaH5RVwQBtCh2hwHPJW7aWp2wJfE7hZ38QQ3p2qLyoGA7XNiwYPimSBtFh+uCfooMChxpDRtfkTGQhU05aHLh8j8oN1BRNCzBstPvB9Ljz8GHc1HTywERFCkQKr6eaD40Q8bhdALjgUX7OhzafP+H2vwxZqk2d3CjUmJfTBK4BaUb3DbYXr7jvGjry77vO6sBxYiESq+AqFmwpnJEm5fuYI7N28CMHndh5ZTnQtRL3Bm+g56VtFjhRc9IssFefO7zCRnSEFodyxLyJHioiBQB0cZ+1y63tBe78IZmuN9xDU9XLB/5+Su0O4jBhG4bTE6u4a1jz1r/OgqFZssx9s0sAT83PmnnloqfvTDRSH0guMCfwmoXsH3ZwT6dm/ltRyZQxKPy4wlzKVaGz+6UqjWz0CDjdndrrzWKyeJgK8YWKtHmN28hatXrsDldW/bnNl9D0T+ztgU7+5Psp0I5Hi8cGQt//o+9YgOvTnXG3QXGM7snm+nPCt6TIlXZW4rF9RMH+ok2uzfOQ7CTOa6fRhl9rineW/OvPCxUE6ipdvks9aPrp588BY/h1DLgkNAIfSCY8Nz4Yf7m/aTfXav3AApXYhO40004WZ7G+10itH999n10TV0p4cHXArLoLq87qO2w1s/+jG01uiaBq3NGrdvRM59VzVJ5mzH1JgtFpEc/eplPcN00NqdINIjhxMnub0qYF40793l/pK4+wLNcWsvGqIgASG8IeySrgnGwYSVkOmVoGctzjxn/OjchpjXKISBAFLUraiKFI3+EAC8XPzoh4bSkQXHhu97hVt/vTE6a0WB3YT2yo7qAQxoFfafbjpFs7GJ+r51YDKG1javu9b54V2oygqEMRPOjMZ45yc/we7ODqC1J/R9m917tvQgiTDDL9gSCJzTMXZBINUtS3+e9EyfGXO1bVfKaqeE5GI7DXkNdSip3ulBrsbSlSL/4GM/wqso/O5uH++vH4gIPJth+fHHMH7fw9BNk3dnEIGJiBShJlg/+qunr6sXFIXQC44Nr1if+WbVfLdlfb2CWKglQhh0emMCyQ+Gblrs3rqNam0V1dkz0Nx5X3o6dHtEfnTg7GiCjTfewvV33gEAdLMGTdPs2+zeH7ZImK05kCOc9hMvqJHWayEgZBQXLAcbRDdPO12kJsxHMM0bKmNv/XHuh1Min+wBFs/PfJcfQNzO3M/Ni6HzHi4RdNdhdPYMlp96HNwkgXGiYFKKWvMb+dyffvzx5S8DxY9+SCiEXnCcYAbov7t9+yYzfbc2pKf9kWTA8G5pPxpwNB4xAGiN6e07YAJGD91vllNlhtZdnG8DonhbLhFQA1gbjYHNTVz54Y/ABLSzGZrZDO1gcFw/4CfeLxeFsf5/dulnndnTdcg+VaBjh+w8R+T5AVpCRhIsJnKSlPnOcATmbPCIP08pzIwLEXzi3kO2EjWHH5UTZEJUelTS/K5ghhrVWPvIM2DdRYVE15H3oz/x7MbkOQD4auGiQ0HpxIJjxcvGdQ0QfktBUl+kegetliJ9vR80x2ahlmZnF+OHHzTLqfrV1wbM7l4rI1RMWKIKa6rGle//ANPpDF3TYLa7i+l0OuBLz5dK4l9YnzPZ+9hJ6j76PcuHfVf8CYP9v1H2NccHA5VdbFXL9b71/lhriVkG1+4lS0GO121Q2emECBBwxA73LoZeAIKQNvhch1ZSCycAmrH8wSeAqgqdmVRF+tGJ9M8BZTnVw0Ih9IJjhfOjs6Z/2BqJP34HpSqdauPpeQDAjG53iuntOxjdfw60uozOTl3Lmcx9WXb4UEQYM3D/0jKu/eQ1XHvrLbDWaHanmFpS36/pnTM1ZRA4GarInev80ItqdrcwAzkhcBxnA8NyVV+MtKtSK49tCC4RjUyE4me1WRIkYPGj4AbrJ8VHkqahaDqid68AkQwQlbSPZ8idxviB+0GjkcgHwaKH7Q1I2Xef/gmg+NEPC4XQC44VzzlLOZrfnrLerkBGUU8hSH1Im3XQbYudGzdBy0sYPXi/CYpjDd113lOavZTNQDNi4IHJMurbd/Dj3/kdaNZodncw3d72pH7geen+XpYQ2PlmRZBZPmYoDq9bAM3QREWLniQxnxvhM2duD/Pbj6myWUgJUTpI4iQ7hsjDOSSlFo6J73Qh9R2ETxcT4ZfNFa+l3+f6Yz/PkDUwGoEqlfi4gGjmhCLVmSQzn/oSUBU/+uGgEHrBseKCXajlv9258SaBflCZn7AR5aXzLqNU5FV1AJ3G9NZt6LbD5P3vg64qaGt2z2rpHLQwgFGDsIIKjy+v4fd/4x/h6rtX0c4azLa2sbu9jd2dHUxns7tqL7sbQmi6blfq5HdNltsLpRkKP7NV5VgogMzxZDdpnl842FXngrACRGQvVqWTZmlQsK4sFO5B8HOPKBf85oTRfUMpzG7ehp7lotzjF7sloAJ96HPrTz4JlLzuh4FC6AXHjvNuoRbG12pQ8KM7Akjc6dkw3IgMGc3mFmabm1h69BHQ2gq6rjPz0S2hzxuTCMCYgfetnsHkrav42t/5u2i6Frvb29jZ2DSkvr2N3d2709Q52XZaEctFUSh//mKBQSRN6IYKKKzf6U7zPmnTTr97QdomzSB9CZJA8XPm2MpDyfM6HchbhPzsBWdxCT/FQPSCmIOAlmQTtAc1AduvXQQ3LViRKCuREgikibplpSZLqF+yRwof3SNKBxacGIjwGz79hIvViU5IAnOTiyW63Sl2btxCvX7WmN1hMsZ1bWczxw2QiR2gFAPLUHj23AN459XfwHe++S3oTmN3YwNbt+9ge2sLOzvb2N3dPXgWOcBrg3ZhNq+hZ33MvcC/pL4niGBqD1aHno5L7oH2LREnzYOSYuC3w6ePb3DbXsIMWrm0QyyAR2QfEPXPWXxYtl7ssC+q7yFH5EEED6+j7ad2d4rb3/6uMbnL470fOIGIuCaFSuGzZt8X7rWhP/MohF5wErALtehvTlk3RFSxGEXlYBHpAGK8ScFtg90bN4BKYfLY+9BVCp3W6Lo4jWtu/HXrgNcdY320hGcnq/jOX/vf8dOf/gRd02D79m1s3riJ7Y0N7GxvY3t7G23bDhco4CUVdy+Oj/qtvLLeOybN2ycDOX3NBsrR8INxK9AlHtQTw7xaOOHEPTPuHUMvs5wLojtxSWsu8q4dAPBmlOjXJt9aEpYzjq5xUe9evhvVuPOT13HnH38XtLzkrWPJDcOHIpdz6eNACYw7DBRCLzh2XLAjx9c3rr2mmX9cS0+dZbTol+2n21jklIxOY/fmbTS7U0wefcRGu3fous4sibrXgMsAtMZIMx5dW8cHdjW+9Vf+Ki5dvoxmOsXmzZu4ffUqNm7dws72Nra2trC7u4tOz08RG4KscqTnprQFoqf44tjtKA6dnG89NbWG737lNoS14YPmvgh0DswjXpf0JzdbwZmZe3PxfdzcorRvL6Tt4iCZiHO8zYUC53uad9YlezYRoLsWrSK88df/b7Q3b4Pqam/zBRHZhVY/VALjDgeF0AtOAvxVoHoVaJnoG3ahljznOjLfhwN2dmcD0zsbGN23jurcOjoAndZoW7uCmhyP0ts4Yuo61B3j8XP344mNHfzuX/mruPiTn2A2nWLrxk3cfOtt3Hz3XWxtbGB7awvbW8YMP5yEJtwh3nZEF6YPOXN2CNrjsH+oqKSrjg9Oq5P3Z1EJdq5SYb4V59p/F8tkHb8ZfipbSnZitgIQW5ROLSQ7JxYYOaMhvsY8v65poMcjXP3aN/Hu//7rUKsrJn4lKljCS0LUGXn2ic888MQjQAmMu1cUQi84EXzP/nAV4x/aXSRNyh5ucKHMsQTd9g52btxEtbyE6oH7oGuFDoy26+JUrtKELXYQM6ANqY8047FzD+DJzSl+/D+/gt//7W9je2cHO7dv49abb+Hq5cu48e672Ny4g62tLWxvb2NnewfT6dSv1jaX4FNV3Jk90+lsibna9VFPPPBCQaJf9iSXw6KdvcsJC73YoZ3CPjkP2gsx+7jDcZEmCZN7aIOI8BPHXK3kM4qn9YX9C49EKINwdbHcZwMH22aGRmvcefsd/OTPfgV61oAV9d9DCfJ/1IGhiNZGLb3vaBv2s4H6pCtQ8DMLDQAz8NeJtQaoAiTfCDN7anLPgBRBNw223nkXrF7A+JEHsfmjMbrtXZDWoKZBVVeg8cRIsVGck/iXAeoMGVeVwoNnzmF5Zwtv/5+/jt+7dAWPfe7TOLN+DrOdHWzduo2ltVWsrJ/DypkzmCwvYzQeoaoqKKWgVAWlyKdN9X/WzB6bb3uSjPk/mesNIETH2/29a1m2Cv1R1dv3gw/UyRNMe8pNe2OIufx8dUqyr5F3urANISd3vrPOCLnO7977tbiHJuTFCfZsxP7TuxpkfRGeqZRJTw1cBwPRpxPIuq5D13Zo2hlmncZrv/wV7Pz+a1Bn1sCawUlWOfEIoy8MaGUUy3MA8Pwp66ZFQyH0ghOB86Pf2l75vYdXty+PiJ5qGRpkrUYsB/Lh33ik1ROwdflNTDc2sPy+R6DOnUW3OwU6BnQHms1AqsKorkOxYtw2X+0OrY0XQCmsLq/gg+MJbv7jH+DN1y5j9VOfwLlnn8bSygqmW1vYvHYDo+UlTNbWsLy2isnyCkaTCepRDVVVqKoKRAqUIXdAkLkYBFOS7q9slkvDmTMR909xkUgRL827hNzStfvMmrZXilBRW05Ice+LyK7oc4BrMnd1bXCCxN4Vtjq7DJzb4zr5ekXbXgA4AoFE9L13jZMUCPuuEg8h4EYCpCByzWadhG46w6yZoWXGO//j/4Jbr/4maG0V3HVgUgixCOFdi7orCEFMADTx2uF0wM82CqEXnBT4S0D1l3Fx9z/lh79WEz3VQmuYzHEGgqj3HHQZoKrC7MZN3PzRT/Do5z6N5Scfx50bt4DdGYg1qGlBNAUphdpmsjKaaRjkyGomxFY75g6aGVQpPHjf/Vjf2cWdv/+buPbd38P4w09j5aknMFlfRz2dYvvOBu5UCvVohGo8Np+jEerRCKquDbFXCspq8GT/lIwaVsqOdfbTavRyW/aDjDiPyEFq/8l3e3a2P6Nzc4wzl6zD4J3ezXV2/1EShiZ2U+9LIGHOnkeyChGZDlQsHMnxXNKH3nYwl8T3Y+IQN9tL+MnyL/mmyJ5zFiZpxohtCX2/Rm6+fXCJGAJnraE7Dd02aJsWXduAiaB3dnHrf/ubuPnr/69PuSzrspdYZ4UEapnRcbc19+SCfaEQesGJ4Tk7FmnmVwF8GRDjVzoWDA3EMFqeH9gU4dq3fxf3f/TDWP/oh7B1+Qq6t68CrSFnahvQTIGWllCRSvzc8ehJAEgzWJu57Kwq1EsTPLi0hG5jit2v/Q5m3/khmkcfRvXYIxg9+ADqs2dQLU1QjccgSdyJyd0TtNTUU1N8cswlaYnWkJfDpiOH1JTPiEkzJZEe+ec73ck+0dUJ0Saq6NzysmSWK09cG5va43pE2cIp9WzLZvavY3GchHbZv4QGywlXp03t18u30Ms6ubJEefni5iMwObztyQYreKcMxwTOlsDNtlkTwSxyZGtcKahOQ1+8go2/9Sq2f/BjYDL2MSNEytYv8ZOIyrvgVK01s9ZqqjvebukqAHzvlIQaLCoKoRecJDQAtIR/NGWtCVSxGAfmaeX+Vy/8lAyAqgrTG7fwxj/8LTz9T/8S1j78DG7evAN0OyANUNcBsxlIKYwnE1TeeYzAWAAUGUu9stXsOraZ5xS0qqCWxljBBGg78MW30V18CzwZoVtdQbe2CrW2ClpbgVpeAk0moKUxaDQCjWpQVYGqCqhrM5Bb0ocimEUrbIMEobtt74Wmfvvtjrijhva7XRzK6mnO9sMpfBF/pcXtwz0yhFgIGX7o0q3rdU8KdSMm3FUaN2eV8eb0UJUgwOyvXN8WYe8Oc9v3vjbiYDiBLCN0pg9tP9Xz5yWCmuzDqBAGaTYxKLMGtLkN/e41tD/8KXZ//Dra3SmwNLZrJqTlynbH5O7WZ+86DTCjgb4xravLAPAywBf27KmCIRRCLzgxXLDjlt5e/4FevX1xRPTB1pD8gWZfRCI9mzWZb3z3Bzj71BN48IXnsX3lLey+dgnUdibZRdsCu7sAEcZLE1Sa/LXS2qyITOJ5JihmaDB024FIg7tgMqelCWois+b55g54Yxvgq/ADLxG0MuZ0Vgqwf1Qpc9xvW1JXbr8gdYr3mf3w2/aL1eIdybtjgGdmLwyI/e7DlgGvRRKi8T3SIsPymy7ILVgOpGZmBvSwhCwSNZVEVdLrk/vByltp7IG9hw/E8v0hLhft8vckBKpN7uU+Ui0/6sPMNXG7RVm+Xma3p7qctSQqiuz5LmYgZe9kWxI8s98Es40LsdtsyNQFgEJr8/toWlDbAk0LTGfg6RTY2QVv7UBvbUNv73oC50qBdee1fW95St4t2cdGniCj0etOE7jqmH/0X965fJNllxfcFQqhF5wk+EtA9av48fQ/4Yd+qyb6YM+Pnl4gv/SII9YkL/2//wBLD96Phz77Kbxx8xba6zfNYuyswY7UFWE8WUKlNaCdT9EO+HZAVFIbAtvBiEFKe8J1ZnVHzm7wdQOc163tXHd0HeDXe+FQd/fdalLE+Xhr2RdSo8PAvl5AUnb6miNfQdRSY/XnmBIl6RNc+r98qWl9w4YQplwvxTfMUFfaOopPzCE81lhvJHswo7nKO0tijUk6KOPsNH1fNsV1HqofyTck3NlViUWr96OKmyZFCWzD83YWDl9p0X6I7+4rhcOstfGpWwGAxbvpBbakbjmBhYmguw6661gxo9X8mwDwslnjoZ3buIK5KIRecKJ4zo9T9CoD//Jekb898hKkHvjQaDPd5hZe+3/+Dj70z/+zuO+TL+DqP/wasD31EexoGvCOGXTGS0uoNANtZwZYjTCFy9ZJiW0TLCR0E+q8Fuk1aFE/r105k7AURjLmakobSr2NOTyWnJNV6MKqtZQWFNWnT/xyiGZ5ynyeyZeTXtOzOefKn2fATn0DZlfaza7ljpSS7k+KckuBMmS/yRgBdqdTmBHAon1SfurVnZ14FN/aX0euvPRoH145999j0mWbvpVIRUfkEn9+aj1roGMTua4dietee+S9icLTiejdWZoqBc2MrmnQGf85Zlr/LQB4vmjn94xC6AUnDQ0AnXJ+dKNEA+iNfG5s89oQgp4oTaluQKW6wvbb7+Knf+Nv46lf+iM489xHcPvb37XmRwagwbMGzNtgAiYrq6iqCpg1ZrUWDsShADunziUZkUtv2iQp7LyG2tQpVk0STSXphUhDlKO/UwEF2SdnxZwXvgmdN74yw4Y93oy0eIpPGCgj7B6UIuK75A4PF50cEX3C4Ttx3Pq+wDRkmQjXuOuHWhNv9Ns5rEnb90Oc7vzJveLsMffsYz/8PiSoVILgpO05RraCBTlhJNHsvQCQXEpk5poqCgGfQYAV20qBqwrtzg66ttXQWm3q7spb2/gNAPjysJGnYJ8ohF5worhgh4crW+/+8AMrD782UvRMw6yJ5pjdSX5K4gwGYgYAbfzpG5cu47W//ffw6M99BrM7G9j+/Z/ahFjWbNgAvLkFZmBy5gzqUQ3sTo1PEUFbVvae0nrJQsuDJPfALHZoTEZB/1UMyunALk8kdooa5DRyIB4F46GeoCMi0BgiAX+da58bz6USneMof8xoefsL/xLIyDD+a0pwdh/bh0IyI4587nZLmqrnVT3UJVk21ZXkhEdnTrf3JIY1KbuH4shXXhwLY66OPdHC7oybHItZQdDwFUb6xHPf+wKfvK14mb01wda5V8H49kYjNySurLXCu5pcY1w8g1LAeISuadFNZ2i7Vldg1XD3v/wa3to+D9QXirn9nlEIveCkwV81CzPM/gzhH9SgZxrwYGCc18QdKD1mt+wYy5qh6hobF6+g3Z3igY99BO32DmZX3jJh7GBAd+CGwZub0Fpj6b51jM6dBe3sgnd2gU7DrRjmBj4Ft2woDJFZrYY984TTk2qK2lJ/YI8aIkdZocSzEyaQaHuxUu0G8/gOOToJNOIJzVknOLkyp+BGjU1El+hRudrISPI+EYXm27pKLuFwjO1nKjCFW8YUOFh10R2JDcD2gdBSKXx394/ukhEIXBxEWnZ0D1e+3yT0RbWUwGWb2Qs7RvAJ72o01VwImr0aSCEzSUQTWycseTttHIHMw5RMhKBMGziqAbS7O2ibGbPW6lbXTDep+Uu25KKdHwIKoRecOFxed4b+2xrq36R47IM5ZpFq573SRA5p+49mhqorbL/zLprtbaw99ijo/nNobtwEd2aebaUZ3DD05iZ022Jy/31Yum8d9foa9O1NdNs7gIYgdvZjplFoghYXCRaJehhikaz2KMbOPrnndcpUeSJxaqQMeu0xcz4oJhNSQpsMlQ4CgTTfS+2PelPahmvujuWO5vfldNCgjQcdPFc3r/I69ObeiU1KyDVXq4Fz+veN98k+FJXxxyLXgD9zyNox3LPuSBL8n7/UP+KUzN0xUXdrLJPF+qeYErrT1JXJFkeVAq0ugyuF5uZttDu7aLuuU8z1tu7+yi9vXfv9r4aV1gruEYXQCxYBGgAarf/Bruq2K1IrMibNQzJXTw/rf5GKrmYNUgqzjU3c/MlrWDq3DrW8hNn2LmptNGwFDW4ZvLOD7mqHbjbD8iMPYfzkY6h2dtHduIVuY8vMZ1eCwJ1myslyqCSYOmpDArLkxJ4i0SMjBA05ZBR39xJpUHuMkxOPBkD5ioYaxfp+L5guX2jyXVawT4/xEXHcyVGumoz4WK+zUjK3F6aCR66/siyY1tscywlh+RJSWo8rEllbYN6DveZu9mvTK3bwfevFa9h9JM+RFea4fvLZK5C/1hC5KUuNR1Bnz0BXhOb6TTSbW2ibRrPu1M2uub2pZy8zQC/PMZ4UHAz7/akXFBwpnMX4P1l58B8sqfrzU9YdkV2wxZ1EVrO1I5f3paP/6dJc+kUcheasbearLiLzHQAAGYhJREFUemmCEQhV06HSGjUIFYCKFJQiVFWNemUZSw89iNXHH8X4zBnw1g6aq9fQ3rgFvTsLKnfqJ42mCbnWcZ8WJOf7A24nxVJJjkB7Q2GGMMnZimOtdhBOYeRQr2iWUzgt3uir0mJH3vYgu6fXkt7+fjn5+1CyJ69X988+HORqmRNrpKg03C7xMFJm7WnV/RvdTdvC+5H0pXzgFM4L2QzNSVTXqM6uojp3Fl3bYvftq5jduIV2OkXXtS1rXb/Vzv7kL++8+98X7fxwUTT0goXAy3YOqgb+rgI+jywDBA1raJD2ZC4K8GRuCZ7ZGDRn2ztoqwojpVCTIfqaCQwN1RE0N+g2OnTTKWa3b2Pl/Y9i7QNP4uwzTwJNi+bqdUzfvYb21h102zvgpgV3HWL/I4L2TGHwC0fDwOiMrCLG2GqjclB3V+SJYH8ElVw3cJHcpXKnCbkji9imn1ElrXDRs4STtTq4wi39+Q4RxwdrHCrhPL7zLAJDyBHxfkjS3zHpavmso8A+J/+FVzxYfADT+HnzOaM7cPJt2OqTuz46l9P3LJXe7N5agcYT1OtnMHrofmAyxvT6Tey8+Taam3fQzWZou7Yl5vrtbvZ/FTI/GhRCL1gIfN+NEBX9nRnzy7DaeQDF2wPaubPL9qbYiCAqSfdd16LThIoURiCMYOaYV0SoNKECg6eMrrmF2cYWtt9+F6tPvB/rH/kQzn76ExivrgJdh/bOJpo7G2hu3UG7uYVuewfdzi663V1w00K3DbjpwG1rsmvZtJduCh2zcTJwaIKtNvsd5NsVWp3SVKpd9QPlgDTyoJeffQDyHgxY1+ocyksPid1BQ7X37xkVSNyIeoXkajvPUOBrZcscNCbsAXK1JrZWC7Llsz/eex6Zfggr3olOsdPufO8MuEBydepJv8KyE70TyXrussJk2+GFChedLuaQU6VAVQ01GUNNxqhWllGfWUO1fgb1+lmgUth99xq2fvI6dq+8hXZjC13ToNGdZq3r69309ctq59+2Bp8SCHfIuBuLTEHBUYAA8J8CJuPVh78zIXq2cWlgXcCZJ/GY0AO9BU3cTR9zA63LcMUIGns4x2wrIoxIYQxCDUJNhAqEisy0HEXKrHNe1xidXcPqE+/H2Wc+gPUPPY2VRx7G+OwZjJYmxo+o7SpVTQPdtOC2hZ410M0M3LTomga6bY1W33bo7H7WGmxT1HLXmb/WfmoN7rQRCLSdL6y1SWdrt6HZb7O246XP7sVeiJCCgjwvOp+DBh1W6uLoO4nrWFwfQZAUok2Od7MjMnGO2A4meA7bHBOoE9o8Icl7JewlYx6QnpaBLzNpTjgICGaM5Rrq34SUCyjM5SjwrBpZeBzxuxOdFSOk+bXbSgUhwUWai3TDZrsKmQ2rCqqqQHUFqmvQqIaqa1BdQ40teY/Hxi++NEG1NDFrE9Q1mBnN1ha2Lr+BOz/4fWz9/k8xu3oD3XSGrmvRas2atb7ZNe0b3H7hf9q58bUvAdUrRTs/dBRCL1gYnLdzUf/jlYf+7Jqq/sw2uCVC7XVKPz4HkyUQCDlH5uHTEnvumCgDDFREGFOFMcXErkj+mYGwmkwwOrOG8X3nsPTg/Vh64H5Mzp3FeP0sxmfOoF5ZRr00QTWZoBqNUU1GdhW2yqeIdTnh/QDsGiXV1tTS4PZlSNgTrhbH5PnMEfmyu4Z1sLLKazCv3KQOQDjun467T9yWyPpgCTYmYPfQtX/mJIqgpAyJzPTvIDAA7oZ9onX9PkTs1I+8N5ckGre7XAmhQgTlkSBsUP97yEIXzBcyN79PtTpE6LlFfohsMGe67e4nBWX3TrARIrsOum2hmxbtdBftxhZmGxuY3ryN3Xfexe5b72D3zXfQ3LiFbncK3XXotEanNRru2tu6rd/oZv/2X53e/h++ANSvljnnR4Jici9YGHizu8Zfnyn+M5Sdix4bGCNyQyBqqbeLsyLCl2UErR3omNFwiykRxqQwgUJNChUAxYyKCQoapAld02K2ZUzxpBRUpYxWMzKaTTUeg8ZmffRqMkY1mRgtZzQy59QjVJOR0YJqqxVVFVRdWa2p9ttmLfXamD6JjEZVKZBd1IUyQoLXzvzAr3yEPux2TAYI28p4PeIYAPj5xjGRZUgpMf3HKqt8osl1ki0ziHOkJ++Gl0jEPsn2Xmv3UkT+JkA0e8Dl+M+ld+m9TP0z4JYmldneosBJUYZxv4hznIAlhDEnSJmUrAzmzi91aiwx2lp0zL7IutN2Zj2CNliAdNtawm6sJcn+zWZG097ZQbczRTedQu9OjUtpdxfddAaezkxZ1jKk2eR8b7XGDnftHd3W7+jmv/nq9E4h8yNG0dALFg307wH1mZWHvj2uqucao0apnHbuBzVyCqQdbFPT+tAnjCkeCJq69t+CAleTwpgUxlWFUVVjVNeoqgoKMLFKdhAlO/iSM1ezMA0j/NikduUza0UrqyWfyhGvJW6pYXnCdufa80iWqQLh2lXfTEWClubLJ1jtTtQv1RB9Hcy58liwBkuNT2iBTgP2MkKiJUoN15IvE8dlQTwce07kz5ezBAjBYpBwu7hRQuxOO7VNT2cnRK4F8pYNV06WqD0h27XFvTUlnOuPW5cBO/eJe0e7LinLkb0lbO9uYZN3Hdq6ftx+7d0ynvjdIivCbcNWIICWAoWOLChh0RYWTTXnG4FY47Zu2i3u6tus/+b/Or3zz3wJUK+Yn9iwFFVwTygaesFC4TxQXQCaP0347yvgVxuG9mtjABCqePiQCpJQzCV5+++OrP1QJPeFMt3YpZnRcodddKh1hxF3WK4VlldWsbS2imo0MvNwmYFOA7ozn50JfCOtzWIwdqB0A2f/DyA7uNJQo5JhsC+NhwHXW40zymocbAWnRM8FyTsGxdt/yl39k/IFZjXsqFL9C8geEplWBfMOtGev9vlyzHm+acn+bLX2vE3SUXAFi7KGBI29YB+wKc4UYu5CiEQQkTWuZ/1wfZlUpG90kL8XGLJHLCRrMBpmbHOHDd11M3Ddgn9vvER/AlOgkPnRo2joBQsFN4b+yfX1c8vN+Id1VT3YGWXcLXaG9NMRtNMYpN/cH+dA5Do6r0/ybjDT0bHwpwBUdY2l5WVMlpcxWV7CeLKEejQymrtSqJyZ2w61nqQTEu8RvNTKONaUSPi75TVxAJu4FgDk+e445HdXL9GrfshlsS2ukd9Ti3ZyKHqy+4C/Zi7Z9amzf1oowFGdE0pM3ThE90cMLuruG+OkB7udEuTQ/kytozYmp+UvEwXGc9rC7v6temWne3OeBqltx+fEcSYMI+hq+9nCaOQzZuxCY8asCSBFuK2Z/9Ars83vlyC440Eh9IKFg/vx/6nlh/7U2br6lV2gBaFOSRz+ey4Izg0+CXFnyNzNnWE7SIXygxk+JnV7vR3xjNW7QlUpKFWhripUdWX3WYK3n+bPmLfdJ9lAu8jMDrEOO+BNzpLwwtHQGzKTnCRrb8aNiF4QuP9uNT6WgXTwx9w1ZulYwSbW7ztXWOipfZKNwjWu/pJQ3Nz0cL0g2JS6sgLA0K79CRqRDMFyVyxcOFLcU+lOBII+wXJmKz4czUCz5gSO+jEtzdU4vP8ArMvKfPNCLIf92u73JA5G5z7FPlM6cQ10FVHVMf/xV2Ybf+MLxW9+bCiEXrCIoPPm3VS3Vh/8R8uq/uyM0AGoJKmbz5Sw7cAkNFEW36UWHmvfoRw3qLn7aHmO3w7wy4M4kvIfHP3AnIbotD+/kAVIuJXjzFu9LFwu+hnhuui4O5KY1Z2e6q53VQ3Xp0MBx9d6xpF50weQU/8g+NALI5LV+l+jemQINVfXaNccVmUnJMwj4MFrI+O0+BbvReiyoS5JbsG9W0bvO4tzhN8/JW4WdeFof1Imc3+f6JHIP56tr31H/R9BAe2EqJ4y/8d/bbbx3xYyP14UH3rBIoK/bwJo2v9w1v07szF9QylVd2RCqvpkHpOp1OTCAIdoXzjW/0P2eN/0npbYj+T29Gp9s9zTnPp2094JYjQfMtYOI3UB3wvisnLO5fl38TPFgN4ia/JYWowXPtx1gjsp+e6t0oJMIxnrntBvo6O8OM99evO+JHLQuvTkkzkFpOfOtRb0XivZqQMX+IKlaAmQI3Piv/TXpoXMTwJFQy9YWDjT+59cfuA/WK/qvzglNCAaeS2CBdly8omggfT3xwSthaaT95tzz+wOHHxQlsgR7UGINx1yc0PwUFmcHD8swp+L3E3mNSBVeoXcM1QM+XPyBNvvo5ho4+P7psQsMlUfNjAcArI1FTcNPM2eiH3dnAAcSVP2aGpakBYjGOnazIKkbomo6gh/D7t3fgkoQXAngb0W9CkoODG8AnRfAOr/buf6V+507V+eACPN3DpWlWTtdgQfYqDdrHndb8Nqz2Hw31Mzl0PUHprSXsdyQkK6bz9l585Ny3LCTHp88NzkuuDaSPbxwHeIbUq+58pCRujy5wcDcPgvflqxCVk+uaE+kk897ov4Ou4d3+sPA5/zntt+yt3rnrHgGQRb+Y676WXZ+4tj3qRP4XcC2AcMu+KfJfOx8Zn/eKfW/9IrQPfc3q9wwRGgaOgFiw76EqA2gPqZlQf+3qqq/+AucUtArQFP5nLQH0rtqsW5fuBj7g+A9k+L75oRBkW7DdiD4lcULWV6r0jKTiF94daq7+t24Bq4oTen/u5l6d/LpiuTuUiXBItzBiEyxGU810NV3w+THFzvng9Zj0Mpd+A9C92WuUs6p977MjImDs7Uc4/Ku+fgyFwBugKRImzMdP35/6O5+Z0S0X5yKBp6waKDnwP414Hpbdr957d188MxU63NbBmkZB4Chbin9Zn9Q5pWXxN35B2dLwfWlMwB+IQ399Ri+7mHjdbvTgf6zIlpgLj79GlfbTlDGmSkubl4AIJP6uPOjuMVhBSE0M+uvD4o+ovOF6WH5+HOleXvn0zv9Tnl3qkDlcvZzQCKt+P7WJIW6WDN7ugMq527h0Thnc6R+T7hyNw8fuKKiDrGv/p/NDe/8wWgLmR+cigaesGpgJP6/63J+tOrVf33xqp6agZuwajdmufSFy6noAF2O9XGOQySft10BO3dR8aH8TCQuJ8mZBEOAEBIT+qUIjsg++Uy/WVCo++p235n2Jfs8vdOEqtEitaAPzoNRGN5f8Tb8TnJtbY/3dS6dD9EKaGXY8QZ0g9Jw70HDIkbQ8cOWva8+Ib5Bg/RufKBMvev6T3GjE98CJlKeL85ERQABXIR7X/6f5tt/LkvlCC4E0ch9IJTA0fq/+b4zLMr1ehvTVT1wV0Y83s+GE4SN0cROjo9x28LU7sg/FT3lKlnZaCQ3+fPc2Q1QJUZMpbXDu9LWT29gzjMyfGo3LhWRHK+dzKqC02vf6/9UOA8SjxsA/jeyIsu4ftx3HfuvdJ3A0I69MeTVyEtLN0nvx9EQiEjnBIIyrxC7RKpesb8lb8+2/gPC5kvBgqhF5wqOFL/NybrH1hR1f85oeqFXegWMIlncqb2XlS7HRiHMsHFZC809Lka5NDIGQiUEHZF9vr0Vzg04g8RfI7wfTlOgxMXep92en2erCnT/qju+9X6ThApeUukBoyjuvfgY5NmD1nTyFwuKxr2+ccoBbEDNGjotPQtIPunTB6DdkKqboH/5+PTO3/8+wCViPbFQCH0glMHR+r/2pkzDyw39V9dVtUvTsFdx6ysIiGWSU1IOyVr9IPk+pnhkPx7ALhELoI0ye5H2BWZ8aPItkgAgNifCASDGru4xml4oXL983qt3IsVUpXvID10PFr5XmR1mDWIRCFGP5sbkGjdyXFnGk+EqijmICJ5iq+XGGhg+gq4xA7pU5S1dGZ2AN2EqOqAb29PR1/8ddzYsKdqFJw4SlBcwanDK0B3HlB/ZWPj+q/t3vynNnX3q4pRVWZs6tzA5Ag7YI8pacxmAKaUyHNkmUAOrMkg69bs7rnKI40qHlVNEhp7b0/eJL5DjMQs7hmLIZG257uChDaYIiWKIfUfmeN7nTvv2qPBXtr4YZN59NmzllBMxkC87SwnUcBGqHd0jXw+zOiRubtn+hpkzkn7Iddn9q8dgyrNuNhR/c/9Om7cOV/IfKFQNPSCU4vzgLpgx6N/fencvzoG/cqI6L4ZuNMMBTBJeosTyOzD1B6JA2Sv5f6g3Ft+cxhzDPPR0VRDmn/lQWlpP1q3w9GT7r1gnqh1HDXP3cP3bmQGGHhvZEFe9mJ7OEzZuxuvxr1YIWR/Gp85tWNQzcBbM9a/+H81W98r09MWD4XQC047yK6z3P3L4zPPTpT6lTHUP9kB6MCtBiqAibmfkx1AiH4nu9BZdE5MsIdhIo6Dzuachxyp3z32FBB6QsnxmMMPgrsVX44CLDZkSEI4gYX5PN2fPlX2h/IO7f0LjL363QO8Zk7UTkC1Br8+Zf7jf6PZ+m4h88VEIfSC9wTkAPOvTdb/XQJenpB6bAaGZm7ZLOxCcXCcgVtFKqeZ73tgvItBd7is4RunHut5kPzQP3cv3/c86jwZ3/dJINd32XplT0zcFz0fdyLcyeQvwJ6PKNXAszabu3xU1mLUKUBNiKgBfmNH1f/K3969ebmQ+eKiEHrBewbnAfWycV3yH19dfWStrf4zBfz7Y6iVBgxtNHYFQDlCd0FyOe19EQglhVwhDDAaf06QSEn/MLX93L2Gyp4vVMTnORxFsNpB4S3kyU6XX2CPq4PPPNnPbn8ugG0fJoi5pxyAvIfM8baIjgCMiSoG0DD+63eazf/8W0BTyHyxUQi94D0HOej8C+O1j45A/xEBf2JEaq0DowM0M7M2xC787GJt9H3eK1WgTuoHNTSW70fPHvI/H6Qt9+KvPQnsv772TOcUT6eRueA1OeXMzQ/PFbUfCEX9QAq2OPkAz8BPBrFVrkdWEGmZf2PG9F/83XbzVcDHrJQAuAVGIfSC9yq8bx0A/pnJ5OklPf63QPwnaqgPEgBP7oC2ZE7W80nJkH1XBukhDSiHkxQG3gvYy0ow9wwG/Hz9aP8AgTtNG+GwC2BLbhow8MLcq/CTscLLL9w/xkyhnQp2sTQ33akBwOD/T0P/xb/b7H4V8AJymWd+ClDGkIL3NM4Dyia+6ADgF4HVyXjtnyTgXwTji4rwvgrSfw6ppWsOmksPnPx+KAgC7ntmc3+QZQ0JFAN1ursbHhOGfNI5X/CBit1TIsqfEPfxgJM6tZSnFcxXON8EIR+orLNkb4j3rveZ6wK5z91PW2tUY7xObzL4hxr89zvQ3/xH7c433fnFxH66sKi/+4KCQ8V5QP19QL0q0lN+Huv3jav2JUX8cwA+zoRniPE4CPcpYLWyyTRsgNA9J224RzP+vMGf5fluO1fWoiCpzzzVWX6lg45YxDCTF70WLfpVpE711nN725gZk2C1tNoEz/TpRMehS8wk9dSP3p8BkarYzjUERIKny3rIzGgAzDR4ysAUwDYYtzXhtgbf1KCbYH5TMy43xG+w4ktvNs3Fq8CmrIm0bhWcHhRCL/hZA33JWhhzA9YngFXC8rnlUXu/0upBBfUgKX2WWZ0lxjrA5xTRGQaWCbRE4CUQlgm8BKYJA2MF1ADVINTMqBVxBaAGUAFUkfHdu6x2igzXKGYQGT1QIeKuhMksF0S5X4gMQbnj6clpJxyw03KzrYaEh73U8CHJJNptSTI+NTFr969znAdnWWEz+1AYYDjskwkECUwhuaCGWKMHIA3jlrGf0JR8sr2GmDs271UHUAegZXLfudUm4KzV5ngLk7a4IVADQsMajQbPCGg0MANRw0BD0FMNmrLGlKF3mWiXgKkGTTuiaYV2V7e0sw21o6B2t7CzOwVmVw2pN/keD3AC7xcBXfzkpxeF0At+lkFfAtS7AD0M8CH6CSsA6img2gWqM0C1DFQ7WKvH0NUErFpAjcGqBavRBKplruoZVDeGqpirDlCVnWpXA9Rxrdy2BvttNmyjKoCYmRigSphgnfKZftaZfRznNgPFHoS44wb6qQvWAiaA5Xd7itlPFJ3ntq35hBWgCS0TRtwCTGi4A1gRaXdNYz+V/E7EFaBnM5hPEFcTaAK4mpKeAlyBtAJ4F2b5z9p+38YWK4BrQG/az1sw5SiA34lIPvr0gsSiwrme3hVjvn3nT0X9C/aHQugFBTEIAJ0HkA6AEg/bAfA5+3mhDIoFAZEk9HLyDn0/804NvWdDeDjzrr0ihKbkUHkvf0ZQCL2g4HCx39/U3PPOJ99zJPCzhucGiOnC3Rd52ERXiLOgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKDgnvH/AyORrF4VtpiDAAAAAElFTkSuQmCC";

// src/mobile-design/plugin.mjs
var inject = ["react", "pages", "conversation", "relay", "artifactStorage", "agents", "browser", "host"];
function apply(ctx) {
  const R = ctx.react, h = R.createElement, ID = "opcb.mobile-design";
  const editors = /* @__PURE__ */ new Map();
  const current = () => ctx.relay.snapshot();
  function DraftTool(props) {
    const key2 = R.useRef(/* @__PURE__ */ Symbol());
    R.useEffect(() => {
      editors.set(key2.current, props);
      return () => editors.delete(key2.current);
    }, [props]);
    return null;
  }
  if (typeof ctx.conversation?.registerTool === "function") ctx.conversation.registerTool({ id: "design-annotation-draft", title: "Design note draft bridge", component: DraftTool });
  const uiError = (e) => /[\u3400-\u9fff]/.test(e?.message || "") ? "Could not load this workspace. Check your access and try again." : e?.message || "Could not load this workspace.";
  const button = (text, onClick, props = {}) => h("button", { type: "button", onClick, ...props }, text);
  const inset = { padding: "var(--space-panel-inset, 20px)" }, row = { display: "flex", alignItems: "center", gap: "var(--space-2, 8px)", flexWrap: "wrap" }, muted = { color: "var(--text-subtle)", fontSize: 18 };
  const destination = { version: 1, kind: "plugin", pluginId: ID, pageId: "design" };
  function check(connection) {
    const now = current();
    if (now.status !== "ready" || now.cached || !now.session?.viewer || now.session !== connection.session || now.scope !== connection.scope || now.generation !== connection.generation) throw Error("Your identity or community changed");
  }
  function useBinding(connection) {
    const [state, setState] = R.useState({ loading: true, binding: null, error: "" });
    const collection = R.useRef(null);
    R.useEffect(() => {
      let alive = true, ticket = 0, off;
      try {
        const store = ctx.artifactStorage.open(COLLECTION);
        collection.current = store;
        const load = async () => {
          const n = ++ticket;
          try {
            const binding = validateBinding(await store.preferences.get(PREFERENCE), connection.session.viewer);
            check(connection);
            if (alive && n === ticket) setState((old) => !old.loading && !old.error && JSON.stringify(old.binding) === JSON.stringify(binding) ? old : { loading: false, binding, error: "" });
          } catch (error) {
            if (alive && n === ticket) setState({ loading: false, binding: null, error: uiError(error) });
          }
        };
        off = store.subscribe(() => void load());
        void load();
        return () => {
          alive = false;
          ticket++;
          off?.();
          collection.current = null;
          store.close();
        };
      } catch (error) {
        collection.current?.close();
        collection.current = null;
        setState({ loading: false, binding: null, error: uiError(error) });
        return () => {
          alive = false;
        };
      }
    }, [connection.session, connection.scope, connection.generation]);
    const save = async (channel) => {
      const store = collection.current;
      if (!store) throw Error("Your personal settings are not ready");
      check(connection);
      const c = connection.session.channels.list().channels.find((c2) => c2.id === channel);
      if (!canBind(c, connection.session.viewer)) throw Error("This conversation is not available");
      const revision = state.binding?.revision || 0;
      await store.preferences.update(PREFERENCE, (old) => {
        check(connection);
        if ((old?.revision || 0) !== revision) throw Error("The connection changed. Review it again.");
        if (old?.channel === channel) return old;
        return { schema: 1, revision: revision + 1, owner: connection.session.viewer, channel, label: c.name || "Execution chat", source: null };
      });
      check(connection);
    };
    return { ...state, save };
  }
  function Preview({ connection, binding, allowed, localHtml, mode, control }) {
    const [state, setState] = R.useState({ url: "", error: "", loading: false }), [retry, setRetry] = R.useState(0), [notes, setNotes] = R.useState([]), [notice, setNotice] = R.useState(""), [sending, setSending] = R.useState(false);
    const runtime = R.useRef(null), latest = R.useRef(null), store = R.useRef(null), busy = R.useRef(false), sourceByVersion = R.useRef(/* @__PURE__ */ new Map()), transferred = R.useRef(/* @__PURE__ */ new Set());
    latest.current = { binding, localHtml, mode, notes };
    const available = ctx.browser.available && typeof ctx.host.spawn === "function";
    const guard = () => {
      check(connection);
      const list = connection.session.channels.list(), c = list.channels.find((c2) => c2.id === binding.channel);
      if (!allowed || list.status !== "ready" || !canBind(c, connection.session.viewer)) throw Error("Access to the execution conversation changed");
    };
    const preference = "annotation-drafts:" + binding.channel;
    R.useEffect(() => {
      const collection = ctx.artifactStorage.open(COLLECTION);
      store.current = collection;
      let alive = true, ticket = 0;
      const load = async () => {
        const n = ++ticket;
        try {
          const raw = await collection.preferences.get(preference);
          guard();
          const list = (raw?.notes || []).map(validateNote);
          if (alive && n === ticket) setNotes((old) => JSON.stringify(old) === JSON.stringify(list) ? old : list);
        } catch (error) {
          if (alive) setNotice(uiError(error));
        }
      };
      const off = collection.subscribe(() => void load());
      void load();
      return () => {
        alive = false;
        ticket++;
        off();
        store.current = null;
        collection.close();
      };
    }, [connection.session, connection.scope, connection.generation, binding.channel, allowed]);
    R.useEffect(() => {
      void runtime.current?.marks(notes).catch(() => {
      });
    }, [notes]);
    R.useEffect(() => {
      if (control) void runtime.current?.control(control.action, control.value).catch((e) => setNotice(uiError(e)));
    }, [control]);
    R.useEffect(() => {
      if (!available || !allowed) return;
      const controller = new AbortController();
      let preview, loadTicket = 0, lastHash = "";
      setState({ url: "", error: "", loading: true });
      (async () => {
        guard();
        preview = await startLive(ctx.host, `"""Memory-only live preview. Only annotations cross the isolated document boundary."""
import hashlib, json, queue, re, secrets, sys, threading
from collections import OrderedDict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
LIMIT = 50 * 1024 * 1024
config = json.loads(sys.stdin.readline(1024 * 1024))
helper = config['helper']
token = '/' + secrets.token_urlsafe(32) + '/'
csrf = secrets.token_urlsafe(32)
lock = threading.RLock()
clients = set()
current = None
versions = []
notes = []
last_control = None
documents = OrderedDict()

def emit(event):
    with lock:
        print(json.dumps(event, ensure_ascii=True), flush=True)

def broadcast(event):
    with lock:
        for client in list(clients):
            try:
                client.put_nowait(event)
            except queue.Full:
                clients.discard(client)

DOCUMENT_POLICY = "default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval' blob: data:; style-src 'unsafe-inline' blob: data:; img-src data: blob:; font-src data: blob:; media-src data: blob:; connect-src blob:; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'self'"

def prepare(html, source):
    raw = html.encode('utf-8')
    if not raw or len(raw) > LIMIT:
        raise ValueError('HTML must be between 1 byte and 50 MB')
    revision = hashlib.sha256(raw).hexdigest()
    # Keep the inner page on HTTP: Buzz validates every subframe navigation.
    # The opaque-origin sandbox and document CSP still deny host/network access.
    html = '<meta name="opcb-document" content="' + revision + '">' + html
    html += '<script>' + helper.replace('<\/script', '<\\\\/script') + '<\/script>'
    with lock:
        documents[revision] = html.encode('utf-8')
        documents.move_to_end(revision)
        while len(documents) > 3:
            documents.popitem(last=False)
    return dict(type='document', revision=revision, source=source)

SHELL = '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{height:100%;margin:0;background:#0d0c0f;font:18px system-ui;color:#fff}body{display:flex;flex-direction:column}header[hidden]{display:none}header{padding:10px 16px;display:flex;gap:16px;align-items:center}#retry{font:inherit;color:inherit;background:transparent;border:1px solid #777;border-radius:8px;padding:6px 12px}#status{margin-left:auto;font-size:16px;color:#b9d9bb}iframe{border:0;flex:1;min-height:0;width:100%}</style><header hidden><span>Live design</span><span id="status" role="status">Connecting\u2026</span><button id="retry" hidden>Retry preview</button></header><iframe sandbox="allow-scripts allow-downloads" title="Mobile design preview"></iframe><script>
const base=location.pathname,csrf=__CSRF__,frame=document.querySelector('iframe'),status=document.querySelector('#status');let current=null,pending=null,state=null,notes=[],loading=false,timer,initialized='';const retry=document.querySelector('#retry');
const tell=m=>frame.contentWindow?.postMessage({opcbDesign:1,...m},'*');
async function load(doc){initialized='';loading=true;current=doc;retry.hidden=true;clearTimeout(timer);frame.src=base+'document/'+doc.revision;status.textContent='Applying latest design\u2026';timer=setTimeout(()=>{status.textContent='Design did not open. Retry the preview.';retry.hidden=false;status.closest('header').hidden=false},15000)}
retry.onclick=()=>current&&load(current)
async function event(message){const response=await fetch(base+'event',{method:'POST',headers:{'Content-Type':'application/json','X-Design-Token':csrf},body:JSON.stringify(message)});if(!response.ok)throw Error('Annotation could not be saved')}
window.addEventListener('message',async e=>{if(e.source!==frame.contentWindow||e.data?.opcbDesign!==1)return;const m=e.data;
if(m.type==='ready'&&m.revision===current?.revision&&initialized!==m.revision){initialized=m.revision;tell({type:'init',revision:current.revision,notes,...state})}
if(m.type==='applied'&&m.revision===current?.revision){clearTimeout(timer);retry.hidden=true;status.closest('header').hidden=true;loading=false;status.textContent='Live \xB7 '+m.revision.slice(0,8);if(pending)tell({type:'snapshot'})}
if(m.type==='busy')status.textContent='Update waits for your note';
if(m.type==='state'){state={state:m.state,viewer:m.viewer,scroll:m.scroll,theme:m.theme};if(pending){const next=pending;pending=null;load(next)}}
if(m.type==='note'){status.textContent='Saving note\u2026';try{await event({type:'note',note:m.note})}catch{status.textContent='Could not save note \xB7 try again';tell({type:'note-status',id:m.note.id,error:'Could not save note. Try again.'})}}
});
const events=new EventSource(base+'events');events.onmessage=e=>{const m=JSON.parse(e.data);if(m.type==='document'){if(current?.revision===m.revision)return;pending=m;if(!current){pending=null;load(m)}else if(!loading)tell({type:'snapshot'})}if(m.type==='marks'){if(JSON.stringify(notes)!==JSON.stringify(m.notes)){notes=m.notes;tell(m)}}if(m.type==='control')tell(m);if(m.type==='note-status'){tell(m);status.textContent=m.error?'Note could not be saved':'Live \xB7 '+(current?.revision||'').slice(0,8)}};events.onerror=()=>status.textContent='Connection interrupted \xB7 reconnecting';
<\/script></html>'''.replace('__CSRF__', json.dumps(csrf))

class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def valid(self):
        return self.headers.get('Host') == '127.0.0.1:' + str(self.server.server_port)
    def reply(self, status, body, kind='application/json', policy=None):
        self.send_response(status)
        self.send_header('Content-Type', kind)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Connection', 'close')
        self.close_connection = True
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', policy or "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; frame-src 'self'; img-src data: blob:; font-src data: blob:; media-src data: blob:; connect-src 'self' blob:; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors *")
        self.end_headers()
        self.wfile.write(body)
    def do_GET(self):
        if not self.valid():
            return self.reply(404, b'{}')
        if self.path == token:
            return self.reply(200, SHELL.encode(), 'text/html; charset=utf-8')
        if self.path.startswith(token + 'document/'):
            revision = self.path[len(token + 'document/'):]
            with lock:
                body = documents.get(revision) if re.fullmatch('[a-f0-9]{64}', revision) else None
            if body is None:
                return self.reply(404, b'{}')
            return self.reply(200, body, 'text/html; charset=utf-8', DOCUMENT_POLICY)
        if self.path != token + 'events':
            return self.reply(404, b'{}')
        stream = queue.Queue(maxsize=8)
        with lock:
            clients.add(stream)
            if current:
                stream.put(current)
            stream.put(dict(type='marks', notes=notes))
            if last_control:
                stream.put(last_control)
        self.send_response(200)
        self.send_header('Content-Type', 'text/event-stream')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        try:
            while True:
                try:
                    event = stream.get(timeout=15)
                    self.wfile.write(('data: ' + json.dumps(event) + '\\n\\n').encode())
                except queue.Empty:
                    self.wfile.write(b': keepalive\\n\\n')
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            with lock:
                clients.discard(stream)
    def do_POST(self):
        origin = 'http://127.0.0.1:' + str(self.server.server_port)
        if not self.valid() or self.path != token + 'event' or self.headers.get('X-Design-Token') != csrf or self.headers.get('Origin') != origin:
            return self.reply(403, b'{}')
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= 16000:
                raise ValueError('event too large')
            event = json.loads(self.rfile.read(size))
            note = event.get('note', {})
            if event.get('type') != 'note' or not isinstance(note, dict) or len(json.dumps(note)) > 12000:
                raise ValueError('invalid annotation')
            with lock:
                if note.get('revision') not in versions:
                    raise ValueError('document changed')
            emit(dict(type='note', note=note))
            self.reply(200, b'{"ok":true}')
        except (ValueError, TypeError):
            self.reply(400, b'{}')
    def log_message(self, *args):
        pass

server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
server.daemon_threads = True
threading.Thread(target=server.serve_forever, daemon=True).start()
emit(dict(url='http://127.0.0.1:' + str(server.server_port) + token))
try:
    while True:
        line = sys.stdin.readline(LIMIT * 6 + 4096)
        if not line:
            break
        if not line.endswith('\\n'):
            raise ValueError('input exceeds limit')
        message = json.loads(line)
        if message.get('type') == 'document':
            revision = hashlib.sha256(message['html'].encode('utf-8')).hexdigest()
            with lock:
                unchanged = current is not None and current['revision'] == revision
            if unchanged:
                continue
            prepared = prepare(message['html'], message.get('source'))
            with lock:
                current = prepared
                versions.append(prepared['revision'])
                versions[:] = versions[-20:]
            broadcast(prepared)
            emit(dict(type='version', revision=prepared['revision']))
        elif message.get('type') == 'note-status':
            broadcast(dict(type='note-status', id=message['id'], error=message.get('error')))
        elif message.get('type') == 'control':
            action = message.get('action')
            if action in ['view', 'annotate', 'theme', 'flow']:
                control = dict(type='control', action=action, value=message.get('value'))
                if action == 'view':
                    last_control = control
                broadcast(control)
        elif message.get('type') == 'marks':
            with lock:
                notes = message.get('notes', [])[:50]
            broadcast(dict(type='marks', notes=notes))
finally:
    server.shutdown()
    server.server_close()
`, "// Injected into the isolated design document. No host or network capability.\n(()=>{\n const send=(type,data={})=>parent.postMessage({opcbDesign:1,type,...data},'*');\n let initialized=false,enabled=false,drag=null,editing=null,notes=[],revision='',pendingSnapshot=false,awaiting=false;\n const style=document.createElement('style');style.textContent=`#md-annotate-tools{position:fixed;inset:auto 16px 16px auto;margin:0;padding:8px;display:flex;gap:8px;border:1px solid #d8d5d2;background:#fff;color:#181719;border-radius:18px;font:18px system-ui;box-shadow:0 4px 24px #0002}#md-annotate-tools button,#md-note-editor button{font:inherit;min-height:44px;border:0;border-radius:12px;padding:8px 16px;background:#181719;color:white}#md-annotate-tools button[aria-pressed=true]{background:#cf3f29}#md-note-editor{font:18px system-ui;background:#fff;color:#181719;max-width:min(480px,90vw);width:480px;border:0;border-radius:20px;padding:24px}#md-note-editor textarea{box-sizing:border-box;width:100%;min-height:120px;font:18px system-ui;padding:12px;margin:16px 0;border:1px solid #aaa;border-radius:12px}#md-note-editor h2{font:24px system-ui;margin:0 0 12px}#md-note-editor menu{padding:0;display:flex;gap:12px;margin:0}#md-draw{position:fixed;border:3px solid #fa543c;background:#fa543c25;pointer-events:none;z-index:2147483646;box-sizing:border-box}#md-note-editor::backdrop{background:#0005}`;style.textContent+=`.design-shell>.design-top,.design-shell>.design-nav{display:none!important}.design-shell{grid-template-columns:minmax(0,1fr)!important;grid-template-rows:minmax(0,1fr)!important;padding:0!important;gap:0!important}`;document.head.append(style);\n const bar=document.createElement('div');bar.id='md-annotate-tools';bar.setAttribute('popover','manual');bar.innerHTML='<button type=\"button\" aria-pressed=\"false\">Annotate</button><span style=\"padding:10px\" role=\"status\">Drag a box</span>';document.body.append(bar);bar.showPopover?.();\n bar.querySelector('button').onclick=e=>{e.stopPropagation();enabled=!enabled;e.currentTarget.setAttribute('aria-pressed',String(enabled));bar.lastElementChild.textContent=enabled?'Select a phone or reference':'Drag a box'};\n const editor=document.createElement('dialog');editor.id='md-note-editor';editor.innerHTML='<h2>Add a design note</h2><div class=\"location\"></div><textarea aria-label=\"Design change\" maxlength=\"2000\" placeholder=\"What should change here?\"></textarea><menu><button type=\"button\" data-save>Save note</button><button type=\"button\" data-cancel>Cancel</button></menu>';document.body.append(editor);\n function finish(){awaiting=false;editor.querySelector('[data-save]').disabled=false;editing=null;editor.close();document.getElementById('md-draw')?.remove();if(pendingSnapshot)void snapshot()}\n editor.querySelector('[data-cancel]').onclick=finish;editor.addEventListener('cancel',e=>{e.preventDefault();finish()});\n editor.querySelector('[data-save]').onclick=()=>{const text=editor.querySelector('textarea').value.trim();if(!text){editor.querySelector('textarea').focus();return}if(awaiting)return;awaiting=true;editor.querySelector('[data-save]').disabled=true;send('note',{note:{...editing,comment:text}});bar.lastElementChild.textContent='Saving note\u2026'};\n function path(el,root){if(!el||el===root)return root.matches('.phone-screen')?'.phone-screen':'.reference-mount img';const parts=[];while(el&&el!==root&&parts.length<6){const tag=el.tagName.toLowerCase();const attrs=['data-action','data-go','data-field','aria-label'].find(a=>el.hasAttribute(a));parts.unshift(attrs?`${tag}[${attrs}=${JSON.stringify(el.getAttribute(attrs))}]`:`${tag}:nth-child(${[...el.parentElement.children].indexOf(el)+1})`);el=el.parentElement}return parts.join(' > ').slice(0,500)}\n function drawMarks(){document.querySelectorAll('.md-saved-mark').forEach(n=>n.remove());document.querySelectorAll('.phone-screen').forEach(root=>{notes.filter(n=>n.page===page(root)&&n.revision===revision).forEach((n,i)=>{const box=document.createElement('div');box.className='md-saved-mark';box.style.cssText=`position:absolute;pointer-events:none;z-index:1000;border:2px solid #fa543c;box-sizing:border-box;left:${n.rect[0]*100}%;top:${n.rect[1]*100}%;width:${n.rect[2]*100}%;height:${n.rect[3]*100}%`;const badge=document.createElement('span');badge.textContent=String(notes.indexOf(n)+1);badge.style.cssText='position:absolute;left:-2px;top:-22px;background:#cf3f29;color:white;font:16px system-ui;padding:2px 7px;border-radius:6px';box.append(badge);root.append(box)})})}\n function page(root){if(root.matches('.source-card img'))return 'Ayo original: '+root.closest('.source-card').querySelector('h2').textContent;if(root.matches('.reference-mount img'))return (typeof appState!=='undefined'?appState.compare:'Reference')+' / Ayo reference';const card=root.closest('.device-card');return root.closest('#viewer')&&typeof appState!=='undefined'?appState.current:card?.querySelector('[data-compare]')?.dataset.compare||root.closest('[data-screen]')?.dataset.screen||(typeof appState!=='undefined'?appState.compare:'Document')}\n document.addEventListener('pointerdown',e=>{\n  if(!enabled||e.button!==0||e.target.closest('#md-annotate-tools,#md-note-editor'))return;\n  const root=e.target.closest('.phone-screen,.reference-mount img,.source-card img');if(!root)return;\n  e.preventDefault();e.stopImmediatePropagation();const bounds=root.getBoundingClientRect();drag={root,bounds,x:e.clientX,y:e.clientY,el:e.target,page:page(root),selector:path(e.target,root),label:e.target.getAttribute('aria-label')||e.target.getAttribute('alt')||e.target.textContent?.trim().slice(0,160)||'Selected area'};\n  const box=document.createElement('div');box.id='md-draw';(document.querySelector('#viewer[open]')||document.body).append(box);box.style.left=e.clientX+'px';box.style.top=e.clientY+'px';\n },true);\n document.addEventListener('pointermove',e=>{if(!drag)return;e.preventDefault();const r=drag.bounds,x=Math.max(r.left,Math.min(r.right,e.clientX)),y=Math.max(r.top,Math.min(r.bottom,e.clientY)),box=document.getElementById('md-draw');Object.assign(box.style,{left:Math.min(x,drag.x)+'px',top:Math.min(y,drag.y)+'px',width:Math.abs(x-drag.x)+'px',height:Math.abs(y-drag.y)+'px'});},true);\n document.addEventListener('pointerup',e=>{if(!drag)return;e.preventDefault();e.stopImmediatePropagation();const d=drag,r=d.bounds;drag=null;const x=Math.max(r.left,Math.min(r.right,e.clientX)),y=Math.max(r.top,Math.min(r.bottom,e.clientY)),w=Math.abs(x-d.x),h=Math.abs(y-d.y);if(w<8||h<8){document.getElementById('md-draw')?.remove();return}editing={id:crypto.randomUUID(),page:d.page,selector:d.selector,label:d.label,revision,rect:[(Math.min(d.x,x)-r.left)/r.width,(Math.min(d.y,y)-r.top)/r.height,w/r.width,h/r.height]};editor.querySelector('.location').textContent=d.page+' \xB7 '+d.label.slice(0,80);editor.querySelector('textarea').value='';editor.showModal();editor.querySelector('textarea').focus()},true);\n document.addEventListener('pointercancel',()=>{drag=null;document.getElementById('md-draw')?.remove();if(pendingSnapshot)void snapshot()},true);\n async function snapshot(){if(drag||editing){pendingSnapshot=true;send('busy');return}pendingSnapshot=false;const state=typeof appState==='undefined'?null:{...appState};try{if(state?.photo?.startsWith('blob:')){const blob=await(await fetch(state.photo)).blob();state.photo=await new Promise(resolve=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.readAsDataURL(blob)})}send('state',{state,viewer:!!document.querySelector('#viewer[open]'),scroll:document.querySelector('.design-panel')?.scrollTop||0,theme:document.documentElement.dataset.theme})}catch{send('busy')}}\n window.addEventListener('message',e=>{if(e.source!==parent||e.data?.opcbDesign!==1)return;const m=e.data;if(m.type==='init'&&!initialized){initialized=true;revision=m.revision;notes=m.notes||[];bar.lastElementChild.textContent=`${notes.length} notes`;if(m.state&&typeof appState!=='undefined'){Object.assign(appState,m.state);renderMain();if(m.viewer)openPage(appState.current);if(document.querySelector('.design-panel'))document.querySelector('.design-panel').scrollTop=m.scroll||0}if(m.theme)document.documentElement.dataset.theme=m.theme;drawMarks();send('applied',{revision})}if(m.type==='control'){if(m.action==='annotate')bar.querySelector('button').click();if(m.action==='theme')document.documentElement.dataset.theme=document.documentElement.dataset.theme==='dark'?'light':'dark';if(m.action==='flow'&&typeof openPage==='function')openPage('invite');if(m.action==='view'&&typeof appState!=='undefined'&&['compare','gallery','sources'].includes(m.value)&&appState.view!==m.value){appState.view=m.value;renderMain()}}if(m.type==='snapshot')void snapshot();if(m.type==='note-status'&&editing?.id===m.id){if(m.error){awaiting=false;editor.querySelector('[data-save]').disabled=false;editor.querySelector('.location').textContent=m.error}else{bar.lastElementChild.textContent='Note saved';finish()}}if(m.type==='marks'){notes=m.notes||[];bar.lastElementChild.textContent=`${notes.length} notes`;drawMarks()}});\n document.addEventListener('click',()=>requestAnimationFrame(drawMarks));\n send('ready',{revision:document.querySelector('meta[name=\"opcb-document\"]')?.content});\n})();\n", controller.signal, (event) => {
          if (controller.signal.aborted) return;
          if (event.type === "note") void (async () => {
            let accepted = false;
            try {
              guard();
              const note = validateNote({ ...event.note, source: sourceByVersion.current.get(event.note.revision) });
              if (!sourceByVersion.current.has(note.revision)) throw Error("This document version is no longer available");
              await store.current.preferences.update(preference, (old) => {
                guard();
                const list = old?.notes || [];
                if (list.some((n) => n.id === note.id)) return old;
                if (list.length >= 50) throw Error("Send or remove notes before adding more");
                accepted = true;
                return { notes: [...list, note] };
              });
              guard();
              await preview.ack(note.id);
              if (!accepted) return;
              if (latest.current.mode === "draft") {
                try {
                  appendToComposer(editors, connection, binding.channel, formatNotes([note], note.source));
                  transferred.current.add(note.id);
                  setNotice("Note added to the execution chat draft");
                  await remove([note.id]);
                } catch (error) {
                  setNotice(uiError(error) + " \xB7 Your note is saved below");
                }
              } else setNotice("Note saved. Review the batch below.");
            } catch (error) {
              if (!controller.signal.aborted) {
                setNotice(uiError(error));
                void preview?.ack(event.note?.id, uiError(error)).catch(() => {
                });
              }
            }
          })();
        });
        guard();
        if (controller.signal.aborted) {
          preview.close();
          return;
        }
        runtime.current = preview;
        setState({ url: preview.url, error: "", loading: false });
        await preview.marks(latest.current.notes);
        preview.exited.then(() => {
          if (!controller.signal.aborted) setState({ url: "", error: "The preview process stopped", loading: false });
        });
        const load = async () => {
          const ticket = ++loadTicket, item = latest.current;
          guard();
          const html = item.localHtml || (await readSource(await readAttachment(connection, item.binding, guard), controller.signal)).html;
          guard();
          if (ticket !== loadTicket || item.binding.revision !== latest.current.binding.revision || item.localHtml !== latest.current.localHtml) return;
          const hash = [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(html)))].map((n) => n.toString(16).padStart(2, "0")).join("");
          if (ticket !== loadTicket) return;
          sourceByVersion.current.set(hash, item.localHtml ? null : item.binding.source);
          if (sourceByVersion.current.size > 20) sourceByVersion.current.delete(sourceByVersion.current.keys().next().value);
          if (lastHash === hash) return;
          await preview.update(html, item.localHtml ? null : item.binding.source);
          lastHash = hash;
        };
        runtime.current.load = load;
        await load();
      })().catch((error) => {
        preview?.close();
        if (!controller.signal.aborted) setState({ url: "", error: uiError(error), loading: false });
      });
      return () => {
        controller.abort();
        preview?.close();
        runtime.current = null;
        sourceByVersion.current.clear();
      };
    }, [connection.session, connection.scope, connection.generation, binding.channel, allowed, available, retry]);
    R.useEffect(() => {
      if (typeof connection.session.subscribeLive !== "function") return;
      return connection.session.subscribeLive((batch) => {
        const id = latest.current.binding?.source?.message;
        if (id && batch.events?.some((e) => e.id === id || e.tags?.some((t) => t[0] === "e" && t[1] === id))) void runtime.current?.load?.().catch((error) => {
          runtime.current?.close();
          setState({ url: "", error: uiError(error), loading: false });
        });
      });
    }, [connection.session, binding.channel]);
    R.useEffect(() => {
      let alive = true;
      const run = async () => {
        try {
          await runtime.current?.load?.();
        } catch (error) {
          if (alive) setNotice(uiError(error));
        }
      };
      void run();
      return () => {
        alive = false;
      };
    }, [binding.revision, localHtml]);
    async function remove(ids) {
      guard();
      await store.current.preferences.update(preference, (old) => {
        guard();
        return { ...old, notes: (old?.notes || []).filter((n) => !ids.includes(n.id)) };
      });
    }
    async function sendBatch() {
      if (busy.current || !notes.length) return;
      busy.current = true;
      setSending(true);
      try {
        guard();
        const batch = notes.filter((n) => !transferred.current.has(n.id));
        if (!batch.length) return;
        const prompt2 = formatNotes(batch, binding.source);
        const id = await submitNotes(connection.session, binding.channel, prompt2, guard);
        batch.forEach((n) => transferred.current.add(n.id));
        setNotice("Submitted to the execution chat \xB7 " + id.slice(0, 8) + ". Delivery is shown in Buzz.");
        await remove(batch.map((n) => n.id));
      } catch (error) {
        setNotice(uiError(error));
      } finally {
        busy.current = false;
        setSending(false);
      }
    }
    if (!available) return h("div", { style: inset }, h("h2", null, "Embedded preview is unavailable"), h("p", { style: muted }, "This preview needs Mac Buzz and Python 3."));
    let prompt = "";
    try {
      if (notes.length) prompt = formatNotes(notes, binding.source);
    } catch (error) {
      prompt = uiError(error);
    }
    return h(
      "div",
      { style: { flex: 1, minHeight: 0, display: "flex", flexDirection: "column" } },
      state.url ? h("div", { className: "md-preview", style: { flex: 1, minHeight: 260, display: "flex" } }, h(ctx.browser.View, { url: state.url, label: "Live mobile design with annotations" })) : h("div", { style: inset, "aria-busy": state.loading }, h("h2", null, state.loading ? "Opening live preview" : "Could not open preview"), h("p", null, state.error), state.error && button("Try again", () => setRetry((n) => n + 1))),
      h("div", { style: { padding: "12px 16px", maxHeight: 260, overflow: "auto", borderTop: "1px solid var(--border-standard)", fontSize: 18 } }, notice && h("p", { role: "status" }, notice), notes.length > 0 && h(R.Fragment, null, h("div", { style: row }, h("strong", null, notes.length + " design notes"), button("Add batch to draft", () => {
        try {
          guard();
          const batch = notes.filter((n) => !transferred.current.has(n.id));
          if (!batch.length) return;
          appendToComposer(editors, connection, binding.channel, formatNotes(batch, binding.source));
          batch.forEach((n) => transferred.current.add(n.id));
          setNotice("Batch added to the execution chat draft");
          void remove(batch.map((n) => n.id)).catch((e) => setNotice("Draft added. " + uiError(e)));
        } catch (error) {
          setNotice(uiError(error));
        }
      }, { disabled: sending || notes.every((n) => transferred.current.has(n.id)) }), button(sending ? "Submitting\u2026" : "Confirm & send", () => void sendBatch(), { disabled: sending || notes.every((n) => transferred.current.has(n.id)) })), h("details", null, h("summary", null, "Review prompt and locations"), ...notes.map((n, i) => h("div", { key: n.id, style: { ...row, marginTop: 8 } }, h("span", null, `${i + 1}. ${n.page}: ${n.comment}`), button("Remove", () => void remove([n.id]).catch((e) => setNotice(uiError(e))), { disabled: sending }))), h("pre", { style: { whiteSpace: "pre-wrap", fontSize: 18 } }, prompt))))
    );
  }
  const StablePreview = typeof R.memo === "function" ? R.memo(Preview) : Preview;
  const skin = `.opcb-md{--md-paper:var(--bg-panel,var(--background-primary,#fefcfb));--md-ink:var(--text-primary,#202022);background:#0d0c0f;color:var(--md-ink);font-family:Nunito,"PingFang SC",sans-serif;padding:12px;gap:12px}.opcb-md .md-toolbar{height:52px;min-height:52px;display:flex;align-items:center;flex-wrap:nowrap!important;white-space:nowrap;overflow-x:auto;scrollbar-width:none;flex-shrink:0;background:#0d0c0f;color:#f7f5f3;border:0!important;padding:8px 0!important;gap:8px!important}.opcb-md button{border:0;border-radius:26px;min-height:46px;padding:10px 18px;font:inherit;font-size:18px;font-weight:600;background:#29272c;color:#e5e1e8;cursor:pointer}.opcb-md button[aria-pressed=true]{background:#f7f5f3;color:#19191b}.opcb-md button:focus-visible{outline:3px solid #fa543c;outline-offset:3px}.opcb-md .md-toolbar>button,.opcb-md .md-toolbar>select{min-height:36px;height:36px;padding:6px 12px;font-size:16px;flex:none}.opcb-md .md-toolbar .md-label{font-size:16px;margin-left:auto}.opcb-md .md-preview [role=toolbar][aria-label="Browser controls"]{display:none}.opcb-md .md-toolbar select{font:inherit;font-size:16px;min-height:36px;max-width:100%;padding:6px 12px;border:1px solid var(--border-standard,#555);border-radius:10px;background:#29272c;color:#e5e1e8}.opcb-md .md-surface{background:var(--md-paper);border-radius:22px;min-height:0;flex:1;overflow:hidden;display:flex;flex-direction:column}.opcb-md .md-plan{padding:32px;overflow:auto;flex:1}.opcb-md h2{font-size:30px;line-height:1.3;margin:0 0 24px;font-weight:800}.opcb-md .md-plan-row{display:flex;align-items:center;gap:20px;border-bottom:1px solid var(--border-standard,#e4e2e0);padding:24px 0}.opcb-md .md-plan-row strong{display:block;font-size:22px;font-weight:700}.opcb-md .md-plan-row p{font-size:20px;margin:10px 0 0;color:var(--text-subtle,#777)}.opcb-md .md-number{font-size:28px;color:var(--text-subtle,#888)}.opcb-md .md-plan-note{margin-top:32px;font-size:20px;line-height:1.6}.opcb-md .md-label{font-size:18px;color:#c1bbc6;margin-left:auto}@media(max-width:700px){.opcb-md{padding:8px}.opcb-md .md-plan{padding:24px}.opcb-md .md-label{display:none}.opcb-md .md-toolbar{flex-wrap:nowrap}.opcb-md .md-plan-row{gap:12px}}`;
  const changes = ["People, films and actions stay together", "Review materials and follow the job in chat", "Portrait deck, material rail and one create action", "Film first, save and publish at the bottom", "An image-led entry with a floating code field"];
  function Plan() {
    return h("div", { className: "md-plan" }, h("h2", null, "One reference system. Every screen."), ...MAPPINGS.map((m, i) => h("section", { key: m.reference, className: "md-plan-row" }, h("span", { className: "md-number" }, `0${i + 1}`), h("div", null, h("strong", null, `${m.reference} \u2192 ${m.target}`), h("p", null, changes[i])))), h("div", { className: "md-plan-note" }, h("strong", null, "R4 \xB7 Live review & annotations"), h("p", null, "Open Results for all 22 screens, original references and the corrected English flow.")));
  }
  function Content({ connection, binding, allowed, open, close, isOpen }) {
    const [mode, setMode] = R.useState("Results"), [resultView, setResultView] = R.useState("compare"), [noteMode, setNoteMode] = R.useState("batch"), [notice, setNotice] = R.useState(""), [localHtml, setLocalHtml] = R.useState(""), [control, setControl] = R.useState(null);
    const input = R.useRef(null);
    const key2 = binding ? `${binding.channel}` : "";
    const navigation = R.useRef({ open, close, isOpen });
    navigation.current = { open, close, isOpen };
    R.useEffect(() => {
      setLocalHtml("");
      setNotice("");
    }, [key2]);
    R.useEffect(() => {
      const nav = navigation.current;
      if (!binding || !allowed || !nav.open) return;
      const target = { channelId: binding.channel };
      if (!nav.isOpen?.(target) && nav.open(target) === false) setNotice("Buzz could not open the execution chat. Check membership.");
      return () => nav.close?.(target);
    }, [connection.session, connection.scope, connection.generation, key2, allowed]);
    async function importFile(file) {
      if (!file) return;
      try {
        check(connection);
        if (!/\.html?$/i.test(file.name) || file.size <= 0 || file.size > 50 * 1024 * 1024) throw Error("Choose an HTML file up to 50 MB");
        const html = await file.text();
        check(connection);
        setLocalHtml(html);
        setMode("Results");
      } catch (error) {
        setNotice(uiError(error));
      }
    }
    return h("section", { className: "opcb-md", style: { height: "100%", minHeight: 0, display: "flex", flexDirection: "column", minWidth: 0 } }, h("style", null, skin), h("div", { className: "md-toolbar", role: "toolbar", "aria-label": "Design controls" }, ...["Plan", "Results"].map((m) => button(m, () => setMode(m), { "aria-pressed": mode === m, key: m })), mode === "Results" && h("select", { value: resultView, onChange: (e) => {
      setResultView(e.target.value);
      setControl({ action: "view", value: e.target.value, id: crypto.randomUUID() });
    }, "aria-label": "Result view" }, h("option", { value: "compare" }, "Compare"), h("option", { value: "gallery" }, "All screens"), h("option", { value: "sources" }, "Originals")), mode === "Results" && button("Annotate", () => setControl({ action: "annotate", id: crypto.randomUUID() })), mode === "Results" && h("select", { value: noteMode, onChange: (e) => setNoteMode(e.target.value), "aria-label": "Annotation mode" }, h("option", { value: "batch" }, "Batch notes"), h("option", { value: "draft" }, "Add to draft")), h("span", { className: "md-label" }, binding?.label || "No chat"), h("select", { "aria-label": "More actions", value: "", onChange: (e) => {
      const a = e.target.value;
      if (a === "import") input.current?.click();
      else if (a === "chat") open?.({ channelId: binding.channel });
      else if (a) setControl({ action: a, id: crypto.randomUUID() });
    } }, h("option", { value: "" }, "More"), h("option", { value: "flow" }, "Try the flow"), h("option", { value: "theme" }, "Theme"), h("option", { value: "import" }, "Import HTML"), h("option", { value: "chat" }, "Open execution chat"))), h("input", { type: "file", accept: ".html,.htm,text/html", hidden: true, ref: input, onChange: (e) => {
      void importFile(e.target.files?.[0]);
      e.target.value = "";
    } }), notice && h("p", { role: "status", style: inset }, notice), h("div", { className: "md-surface" }, mode === "Plan" ? h(Plan) : h(StablePreview, { connection, binding, allowed, localHtml, mode: noteMode, control })));
  }
  function Workspace({ connection }) {
    const binding = useBinding(connection);
    const roster = R.useSyncExternalStore(connection.session.channels.subscribeList, connection.session.channels.list, connection.session.channels.list);
    const [selected, setSelected] = R.useState(""), [notice, setNotice] = R.useState("");
    R.useEffect(() => {
      connection.session.channels.ensureList();
    }, [connection.session]);
    const allowed = roster.status === "ready" && binding.binding && canBind(roster.channels.find((c) => c.id === binding.binding.channel), connection.session.viewer);
    const Tabs = ctx.conversation.ui.Tabs;
    const pane = !binding.loading && !allowed ? h("div", { style: inset }, h("h2", null, binding.binding ? "Execution chat is unavailable" : "Connect an execution chat"), h("p", { style: muted }, binding.error || "Connect an HTML result from the source chat, or select an existing conversation."), h("div", { style: row }, h("select", { value: selected, "aria-label": "Choose an execution chat", onChange: (e) => setSelected(e.target.value), style: { minHeight: 44, maxWidth: "100%" } }, h("option", { value: "" }, "Choose a conversation"), ...(roster.status === "ready" ? roster.channels.filter((c) => canBind(c, connection.session.viewer)) : []).map((c) => h("option", { key: c.id, value: c.id }, c.name || c.id))), button("Connect", () => {
      void binding.save(selected).catch((e) => setNotice(uiError(e)));
    }, { disabled: !selected })), notice && h("p", { role: "alert" }, notice), h(Plan)) : null;
    if (pane) return pane;
    if (binding.loading) return h("p", { style: inset, role: "status" }, "Loading your workspace\u2026");
    if (!Tabs) return h("div", { style: inset }, h("h2", null, "Enable Channels in Buzz"), h("p", { style: muted }, "The right panel uses the native Buzz conversation."));
    return h(Tabs, { id: "opcb-mobile-design", session: connection.session, scope: connection.scope, label: "Mobile Design & Results", children: (open, close, isOpen) => h(Content, { key: `${binding.binding.channel}`, connection, binding: binding.binding, allowed, open, close, isOpen }) });
  }
  function Page() {
    const connection = R.useSyncExternalStore(ctx.relay.subscribe, ctx.relay.snapshot, ctx.relay.snapshot);
    return connection.status === "ready" && !connection.cached && connection.session?.viewer ? h(Workspace, { key: JSON.stringify([connection.scope, connection.generation]), connection }) : h("p", { style: inset }, "Connect to your community and open with your own identity.");
  }
  ctx.pages.register({ id: "design", title: "OPCB Mobile Design & Results", primary: true, placement: "dock", icon: PHONE_ICON, layout: "workspace", component: Page });
  if (typeof ctx.agents.addInstructions === "function") ctx.agents.addInstructions({ id: "mobile-design-live-results", text: "When the owner asks to revise the bound mobile design, publish the revised self-contained HTML in that same execution conversation, then read opcb_mobile_design_context and call opcb_mobile_design_bind with its existing binding.request, the new source message and current revision. This updates the live preview without a manual refresh. Preserve the owner-scoped source. Design annotation prompts contain original page, element, normalized area and document version; recheck the current design before editing. Do not bind unrelated attachments or treat an automatic update as authorization to send messages." });
  ctx.agents.addTool({ name: "opcb_mobile_design_context", description: "Read the owner-scoped execution chat and HTML source binding for this mobile design workspace.", inputSchema: { type: "object", properties: {}, additionalProperties: false }, async call(client, context) {
    const { check: check2 } = agentContext(ctx, client, context);
    const store = ctx.artifactStorage.open(COLLECTION);
    try {
      const binding = validateBinding(await store.preferences.get(PREFERENCE), client.owner);
      check2();
      if (binding && binding.channel !== context.channel) throw Error("Read this binding in its original execution conversation");
      return JSON.stringify({ binding, revision: binding?.revision || 0, page: destination });
    } finally {
      store.close();
    }
  } });
  ctx.agents.addTool({ name: "opcb_mobile_design_bind", description: "Bind this conversation and its HTML result under the owner\u2019s explicit instruction. Stores personal references only; creates no chat and sends no messages.", inputSchema: { type: "object", properties: { request_id: { type: "string" }, source_message_id: { type: "string" }, attachment_url: { type: "string" }, label: { type: "string", maxLength: 100 }, expected_revision: { type: "integer", minimum: 0 } }, required: ["request_id", "source_message_id", "expected_revision"], additionalProperties: false }, async call(client, context, args) {
    return JSON.stringify(await bindFromAgent(ctx, client, context, args));
  } });
}
export {
  apply,
  inject
};
