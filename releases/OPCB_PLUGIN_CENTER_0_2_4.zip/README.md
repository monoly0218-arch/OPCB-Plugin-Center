# OPCB 插件中心 0.2.4 候选

修复社区头像显示为姓名首字：远程头像统一由当前 `session.media(url, "small")` 转换，使用宿主认证媒体通道，避免原图地址401。资料更新会立即重渲染；缓存清空或预算驱逐后重新请求仍可见的人，社区/身份切换与重连使用当前session。失败图片不会把旧session的失败状态带到新session。未增加网络权限、凭据或轮询。原生图片加载与实时资料行为仍需更新后实际验收。

依据：Buzz v1.0.2公开 [avatarMedia](https://github.com/block/buzz-app/blob/v1.0.2/src/shared/avatar-source.ts) 与 [ProfileQueries](https://github.com/block/buzz-app/blob/v1.0.2/src/features/relay/profile-directory.ts)。旧版浏览器预览只覆盖公开/内嵌头像，未覆盖需认证的社区媒体；本次补充401/认证媒体与真实当前照片验证，浏览器媒体通道仍为测试替身。

本版把卡片的「已安装／未安装」文字换为贡献者头像，并移除安装状态筛选。创建者始终在第一位，修改者和PR提供者随后排列；同一人只占一个头像。按可用宽度显示至多4个头像，其余用「+N」，点击可展开全部姓名、角色及来源；窄窗口自动换行，不截掉贡献者。

优先读取Buzz当前社区的公开个人头像；明确关联的GitHub身份用于补充头像，加载失败显示姓名首字。已确认的Agent实施归属合并到其所属人，避免同一个人因多个Agent或多次提交重复计数。当前13项有可追溯创建归属，内容工厂、上粮山资产库、电商看板3项创建归属待核对，保留问号占位，不虚构人名。种子记录在 `src/plugin-center/CONTRIBUTORS.json`。

刷新时读取最近30项PR及当前目录提交之前最近30项GitHub提交，只把修改到对应插件源码的作者计入；不把仅改总目录、发布包或第三方依赖作者当作该插件贡献者。新增记录与已核对历史按人合并，未变化PR与提交复用当前会话缓存。无法关联GitHub账号的旧git作者不猜测身份；超出扫描边界或接口失败时保留已核对署名，并在展开区域说明暂未刷新。PR头像表示提供过相关修改，不代表该PR已合并。

新增公开只读 `relay` 注入，用 `session.profiles` 获取和订阅头像，不读取聊天、不写用户资料；网络权限仍仅为既有 `api.github.com`。切换会话与停用时释放订阅，不轮询头像或贡献记录。

按 OPCB v3 共享界面重做插件目录。默认页只展示用途图标、插件名、目录版本、贡献者头像和操作；不显示说明小字。详情页以18px正文保留用途与实际依赖。中文标题沿用OPCB圆体，数字沿用Nunito；支持宿主深浅主题、窄窗口分类导航和键盘返回。

图标优先级为原生品牌/IP、已选Fluent立体图标、未知插件拼图回退。Muse使用官网IP玩偶，Grok Bot使用应用自带圆形双眼图标，Higgsfield使用官网Logo；其余通用插件沿用本人认可的Fluent立体图标。插件中心的包内icon.png、宿主导航icon和目录使用相同拼图。所有资源与字体本地内嵌，不从CDN加载。

品牌来源与摘要见 `src/plugin-center/assets/BRAND_ICONS.json`，使用说明见包内 `BRAND_ASSETS_NOTICE.md`；Fluent来源见 `MANIFEST.json`。目录支持可选 `icon` 内嵌图片，不接受远程图标URL。此次不更新Muse、Grok、号池等业务插件本体。

成果报告推荐项同步到已分发的 `2026-11-14-commercial`，名称为「OPCB 平台商业化计划与报告」，审核来源固定到已有提交 `bbc10c81776e438404f505950c89a4227eb14cef`；保留旧名称和历史包，不重写业务代码。

## 版本与状态

- 卡片显示 **目录目标版本**，不是当前设备已安装版本；日期快照显示为`2026.11.13`，不虚构成2.0升级。`rc`及历史版本标识保留。
- 状态接口仅用于选择「安装／查看更新」操作，不再展示已安装或未安装标签。同ID存在不代表版本、启用或业务权限已核验；公开接口不返回本机语义版本，最终进入原生审核核对。
- 插件中心自身版本为0.2.4，在侧栏显示；基础目录仍固定到同一main提交的REGISTRY。商业化报告已独立分发并在本机安装，目录若仍指向已知旧快照，则使用其固定发布提交补齐新名称与安装目标，不覆盖未来目录版本。报告源码和下载也直接指向该发布提交。

## 权限与审核

保持ID `opcb.plugin-center`、页面ID `catalog`，只申请现有 `https://api.github.com` 网络权限。安装仍由可选 `pluginInstaller` 发起宿主原生审核，固定分发来源与提交；取消或失败不显示为安装成功。不轮询、不批量静默安装，不读取账号配置、凭据或个人数据。

缺失宿主安装接口时保留源码和下载入口，给出实际错误；刷新失败保留旧目录并禁用安装。搜索、分类、历史版本及详情仍可使用。插件停用释放目录与安装状态订阅。

## 验证

参考官方Buzz v1.0.2，本机Buzz 1.0.2，apiVersion 1。构建 `node scripts/build_plugin_center.mjs`；完整仓库检查 `npm run ci`；打包 `python3 scripts/package_release.py`。EGO中的React预览使用真实目录及合成安装状态，不能代替原生宿主、Android或iOS验收。最终安装保留本人原生审核。

界面方法参考 Damir Sokolovsky / Unslop，CC BY 4.0：https://github.com/heydamir/unslop 。现有共享OPCB v3规范优先；实现：潘涛 Studio。Fluent Emoji MIT、Nunito和Resource Han Rounded OFL授权随包保留。
