# higgsfiled号池1.4 1.4-3dicons.1

本次更新将3dicons.co V1彩色立体图标随本插件包内嵌分发，导航、既有启动图标与包图标使用同一原图。更新插件即可获得图标，无需额外图标插件或运行时下载。

保留公开业务基线1.4、插件ID、全部权限、配置键、页面和工具。原源码SHA256：6b6de748177b74c383e880e87dfde1ee022fe0a68618ceba8a2f2daf2ce6b520。原功能、依赖与平台限制见BASE_README.md；原说明中的旧图标描述由本页取代；如基线来自早期图标包，早期业务说明见BUSINESS_README.md。号池1.3与1.4独立保留，图标更新不切换业务线。

官方与Studio参考Buzz1.0.2/API1；本地完整检查npm run ci，原生安装后与移动端业务另行验收。通过固定提交的Buzz原生审核卡安装，保留本人最终确认。

构建node scripts/build_identity_icons.mjs，统一图标与后续更新规则见docs/IDENTITY_ICONS.md。图标来源、许可与哈希见THREEDICONS_NOTICE.md及IDENTITY.json。
